import { DateRange } from '@mui/x-date-pickers-pro';
import {
  addDays,
  addMinutes,
  endOfMonth,
  format,
  startOfMonth,
} from 'date-fns';

export const getDateArrayInString = (start: Date, end: Date): string[] => {
  let startDate = start > end ? end : start;
  let endDate = start > end ? start : end;

  const dateArray: string[] = [];
  let currentDate = new Date(startDate);

  while (currentDate <= new Date(endDate)) {
    dateArray.push(formatDate(currentDate) || '');
    currentDate = addDays(currentDate, 1);
  }

  return dateArray;
};

export const getDateRangeOfCurMonth = () => {
  const today = new Date();
  return [startOfMonth(today), endOfMonth(today)] as DateRange<Date>;
};

export const formatDate = (date: Date | null): string | null => {
  return date
    ? format(addMinutes(date, date.getTimezoneOffset()), 'yyyy-MM-dd')
    : null;
};
