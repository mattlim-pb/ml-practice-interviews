export function capitalizeFirstLetter(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

export function limitText(text: string, limit: number) {
  if (text.length <= limit) {
    return text;
  } else {
    return text.substring(0, limit) + '...';
  }
}

export function removeGeneric(text: string) {
  return text.replace(/^generic/, '').toLowerCase();
}

export function getGenericType(text: string) {
  return text.match(/^generic/i) ? 'generic' : text;
}
