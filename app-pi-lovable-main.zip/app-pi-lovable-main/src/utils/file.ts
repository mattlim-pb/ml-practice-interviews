export function isYoutubeUrl(url: string) {
  return (
    url.indexOf('https://www.youtube.com') >= 0 ||
    url.indexOf('http://www.youtube.com') >= 0
  );
}

export function isGoogleDocUrl(url: string) {
  return (
    url.indexOf('https://docs.google.com') >= 0 ||
    url.indexOf('http://docs.google.com') >= 0
  );
}
