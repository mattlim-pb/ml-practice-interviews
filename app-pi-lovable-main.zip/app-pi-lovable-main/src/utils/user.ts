export function stripUsername(firstName: string, lastName?: string) {
  if (lastName != null) {
    return `${firstName[0]}${lastName[0]}`.toUpperCase();
  }

  return firstName.slice(0, 2).toUpperCase();
}
