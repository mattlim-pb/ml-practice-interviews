export function playAudioFromBlob(audioBlob: Blob) {
  const audioUrl = URL.createObjectURL(audioBlob);
  const audio = new Audio(audioUrl);
  audio
    .play()
    .then(() => {
      console.info('Audio was played successfully');
    })
    .catch(err => console.error('Playback error:', err));
}
