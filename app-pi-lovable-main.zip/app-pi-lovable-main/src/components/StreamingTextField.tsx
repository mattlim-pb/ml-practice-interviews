import { Box, TextField } from '@mui/material';
import { forwardRef, useCallback, useLayoutEffect, useRef } from 'react';
import { useWindowDimensions } from '../hooks/useWindowDimensions';
import { Loading } from './Loading';
import MarkdownView from './MarkdownView';

interface Props {
  value: string;
  isLoading?: boolean;
}

function StreamingTextField({ value = '', isLoading = false }: Props) {
  const textareaRef = useRef<HTMLDivElement>(null);
  const scrollTopRef = useRef<number>(0);
  const { getAppropriateHeight } = useWindowDimensions();

  const handleScroll = useCallback((event: any) => {
    if (event?.target) {
      scrollTopRef.current = event.target.scrollTop;
    }
  }, []);

  useLayoutEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.scrollTop = scrollTopRef.current;
    }
  });

  return (
    <TextField
      variant="outlined"
      placeholder=""
      fullWidth
      multiline
      rows={20}
      InputProps={{
        inputComponent: forwardRef(() => (
          <div
            ref={textareaRef}
            style={{
              ...styles.feedbackOutput,
              maxHeight: getAppropriateHeight(400),
              minHeight: getAppropriateHeight(400),
              width: '100%',
            }}
            onScroll={handleScroll}
          >
            {isLoading ? (
              <Box
                sx={{ width: '100%', minHeight: 'inherit' }}
                display="flex"
                justifyContent="center"
                alignItems="center"
              >
                <Loading className="none" />
              </Box>
            ) : (
              <MarkdownView>{value}</MarkdownView>
            )}
          </div>
        )),
        readOnly: true,
      }}
    />
  );
}

const styles: { [key: string]: any } = {
  feedbackOutput: {
    overflowY: 'auto',
  },
};

export default StreamingTextField;
