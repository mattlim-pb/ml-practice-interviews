import { CircularProgress, IconButton } from '@mui/material';
import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';

import PauseOutlinedIcon from '@mui/icons-material/PauseOutlined';
import PlayArrowOutlinedIcon from '@mui/icons-material/PlayArrowOutlined';
import { useSetRecoilState } from 'recoil';
import useOnInitialMount from '../hooks/useOnInitialMount';
import { useTextToSpeech } from '../middleware/useTextToSpeech';
import { audioState } from '../states/audioState';

interface Props {
  interviewQuestion: string;
  autoPlay?: boolean;
}

export const PlayQuestionButton = forwardRef(function Component(
  { interviewQuestion, autoPlay = false }: Props,
  ref
) {
  const audioRef = useRef(new Audio());
  const timeIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const setAudioState = useSetRecoilState(audioState);
  const {
    isSuccess,
    mutate: fetchSpeech,
    data: speechData,
    isLoading: fetchingSpeechFile,
  } = useTextToSpeech();

  audioRef.current.addEventListener('ended', () => {
    audioRef.current.currentTime = 0;
    setAudioState({
      currentTime: 0,
      duration: audioRef.current.duration,
    });
    setIsPlaying(false);
  });

  audioRef.current.addEventListener('pause', () => {
    setIsPlaying(false);
  });
  audioRef.current.addEventListener('play', () => {
    setIsPlaying(true);
  });

  useOnInitialMount(() => {
    audioRef.current.onplaying = () => {
      setIsPlaying(true);
    };

    if (autoPlay) {
      fetchSpeech({ interviewQuestion });
    }
    return () => {
      timeIntervalRef.current && clearInterval(timeIntervalRef.current);
    };
  });

  useEffect(() => {
    timeIntervalRef.current = setInterval(() => {
      isPlaying &&
        setAudioState({
          currentTime: audioRef.current.currentTime,
          duration: audioRef.current.duration,
        });
    }, 150);
    return () => {
      timeIntervalRef.current && clearInterval(timeIntervalRef.current);
    };
  });

  const onPauseQuestion = useCallback(() => {
    audioRef.current.pause();
  }, []);

  const onPlayQuestion = useCallback(() => {
    if (speechData && isSuccess) {
      audioRef.current.play().catch(console.error);
      return;
    }
    fetchSpeech({ interviewQuestion });
  }, [fetchSpeech, interviewQuestion, isSuccess, speechData]);

  useEffect(() => {
    try {
      if (speechData) {
        const audioData = (speechData as any).data;
        audioRef.current.src = audioData.data.fileUrl;
        audioRef.current.play().catch(console.error);
      }
    } catch (e) {
      console.error(e);
    }

    const pauseListening = () => audioRef.current?.pause();
    return () => {
      pauseListening();
    };
  }, [speechData]);

  useImperativeHandle(ref, (): { play(): void; stop(): void } => {
    return {
      play() {
        fetchSpeech({ interviewQuestion });
      },
      stop() {
        setAudioState({
          currentTime: 0,
          duration: audioRef.current.duration,
        });
        setIsPlaying(false);
        timeIntervalRef.current && clearInterval(timeIntervalRef.current);
      },
    };
  });

  return (
    <>
      <IconButton
        color="primary"
        onClick={isPlaying ? onPauseQuestion : onPlayQuestion}
        disabled={fetchingSpeechFile}
      >
        {fetchingSpeechFile ? (
          <CircularProgress size={20} color="primary" />
        ) : isPlaying ? (
          <PauseOutlinedIcon />
        ) : (
          <PlayArrowOutlinedIcon />
        )}
      </IconButton>
    </>
  );
});
