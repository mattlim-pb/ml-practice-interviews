import { Popover } from '@mui/material';
import { ReactNode } from 'react';

export default function Options({
  children,
  open,
  anchorEl,
  onClose,
}: {
  children: ReactNode;
  open: boolean;
  anchorEl: HTMLElement | null;
  onClose: () => void;
}) {
  return (
    <Popover
      id="mouse-over-popover"
      open={open}
      anchorEl={anchorEl}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'left',
      }}
      onClose={onClose}
      disableRestoreFocus
    >
      {children}
    </Popover>
  );
}
