import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { LoadingButton } from '@mui/lab';
import { Tooltip, Typography } from '@mui/material';
import { useCallback, useRef } from 'react';
import { useUploadResume } from '../middleware/useUploadResume';
import { VisuallyHiddenInput } from './VisuallyHiddenInput';

const ChooseQuestionButton = ({
  title,
  onClick,
  info,
  type,
  description,
  disabled,
  isSelected,
  hasResume,
}: {
  title: string;
  onClick: () => void;
  info?: string;
  type: string;
  disabled?: boolean;
  description: string;
  isSelected?: boolean;
  hasResume?: boolean;
}) => {
  const hiddenFileInputRef = useRef<HTMLInputElement>(null);
  const uploadResume = useUploadResume();

  const uploadFile = useCallback(
    (e: any) => {
      // e.preventDefaul();
      const file = e.target.files[0];
      if (file != null) {
        uploadResume.mutate({ resume: file });
        e.target.value = '';
      }
    },
    [uploadResume]
  );

  return (
    <button
      className={`group transition-colors h-60 border rounded-xl border-slate-600 p-6 !shadow-lg hover:!shadow-xl  flex-1 w-full ${
        isSelected
          ? 'bg-primary text-white hover:bg-primaryDark'
          : 'hover:bg-primary'
      }`}
      onClick={() => !disabled && onClick()}
    >
      <div className="flex flex-1 flex-col h-full ">
        <div
          className={`flex flex-row flex-1 ${disabled ? '!opacity-50' : ''} `}
        >
          <Typography
            variant="h5"
            className="!text-base sm:!text-base md:!text-xl lg:!text-2xl text-left group-hover:text-white"
          >
            <b>{title}</b>
          </Typography>
        </div>
        <div className="h-14"></div>

        <div
          className={`flex flex-row text-start ${
            disabled ? '!opacity-50' : ''
          }`}
        >
          <Typography
            variant="body1"
            className="!text-base group-hover:text-white"
          >
            {description}
          </Typography>
          {info && (
            <Tooltip title={info}>
              <InfoOutlinedIcon className="!stroke-white" />
            </Tooltip>
          )}
        </div>
        {type === 'common' && (
          <div className="flex flex-row text-start">
            <VisuallyHiddenInput
              ref={hiddenFileInputRef}
              type="file"
              accept="application/pdf"
              onChange={uploadFile}
            />
            <LoadingButton
              className={`!rounded-full !normal-case !w-full !mt-4 ${
                isSelected
                  ? '!bg-white !text-primary hover:!text-white hover:!bg-primary '
                  : '!bg-primary !text-white hover:!bg-primaryDark  '
              }`}
              variant="contained"
              onClick={() => hiddenFileInputRef.current?.click()}
              loading={uploadResume.isLoading}
            >
              {hasResume ? 'Change Resume' : 'Upload Resume'}
            </LoadingButton>
          </div>
        )}
      </div>
    </button>
  );
};

export default ChooseQuestionButton;
