import { Button, CircularProgress, Divider } from '@mui/material';
import { CardElement, useElements, useStripe } from '@stripe/react-stripe-js';
import { Fragment, useCallback, useState } from 'react';
import { Price } from '../data/price';
import { User } from '../data/user';
import { useCreateSubscription } from '../middleware/useCreateSubscription';

interface Props {
  user: User;
  price?: Price;
  promo?: any;
  onSucceeded: Function;
  onFailed?: Function;
}

const cardElementOptions = {
  style: {
    base: {
      fontSize: '16px',
      color: '#424770',
      '::placeholder': {
        color: '#d5d5d8',
      },
    },
    invalid: {
      color: '#9e2146',
    },
  },
  hidePostalCode: true,
};

export function CheckoutElement({
  user,
  promo,
  price,
  onSucceeded,
  onFailed,
}: Props) {
  const [isLoading, setIsLoading] = useState(false);
  const stripe = useStripe();
  const elements = useElements();
  const createSubscription = useCreateSubscription();

  const confirmPayment = useCallback(async () => {
    setIsLoading(true);
    try {
      let params: {
        priceId: string;
        couponId?: string;
      } = {
        priceId: price?.id!,
      };
      if (promo) params.couponId = promo?.coupon?.id;

      createSubscription.mutate(params, {
        onSuccess: async res => {
          const subscription = res?.data?.data?.subscription;
          const paymentIntent = res?.data?.data?.paymentIntent;
          const clientSecret = res?.data?.data?.client_secret;
          if (
            (subscription?.latest_invoice?.payment_intent || paymentIntent) &&
            clientSecret
          ) {
            const result = await stripe?.confirmCardPayment(clientSecret, {
              payment_method: {
                card: elements?.getElement(CardElement)!,
                billing_details: {
                  name: `${user.firstName} ${user.lastName} `,
                  email: user.email,
                },
              },
            });
            if (result?.paymentIntent?.status === 'succeeded') {
              onSucceeded();
            } else {
              console.log(`Payment Declined: ${result?.error?.message}`);
              onFailed && onFailed(result?.error);
            }
          } else {
            if (!subscription?.latest_invoice?.payment_intent) {
              onSucceeded();
            } else {
              onFailed &&
                onFailed('something went wrong while payment confirmation.');
            }
          }

          setIsLoading(false);
        },
        onError: err => {
          console.error(err);
          setIsLoading(false);
        },
      });
    } catch (err) {
      console.error(err);
      setIsLoading(false);
    }
  }, [
    createSubscription,
    setIsLoading,
    elements,
    onFailed,
    onSucceeded,
    price,
    promo,
    stripe,
    user,
  ]);

  return (
    <Fragment>
      <Divider sx={{ my: 2 }} />
      <CardElement options={cardElementOptions} onReady={e => e.focus()} />
      <Button
        variant="outlined"
        onClick={confirmPayment}
        disabled={!stripe || isLoading}
        sx={{
          my: 3,
          textTransform: 'none',
          minWidth: 160,
          position: 'relative',
        }}
      >
        {isLoading ? (
          <Fragment>
            Processing...
            <CircularProgress
              size={24}
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                marginTop: '-12px',
                marginLeft: '-12px',
              }}
            />
          </Fragment>
        ) : (
          'Subscribe'
        )}
      </Button>
    </Fragment>
  );
}
