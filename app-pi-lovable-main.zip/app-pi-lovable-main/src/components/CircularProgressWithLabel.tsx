import { Tooltip } from '@mui/material';
import Box from '@mui/material/Box';
import CircularProgress, {
  CircularProgressProps,
} from '@mui/material/CircularProgress';
import Typography from '@mui/material/Typography';
import { useCallback } from 'react';
import { ScoreResult } from '../data/scoreResult';
import { capitalizeFirstLetter } from '../utils/string';

export function CircularProgressWithLabel(
  props: CircularProgressProps & {
    score?: ScoreResult | null;
    defaultValue?: number;
    total?: number;
    type?: 'determinate' | 'indeterminate';
  }
) {
  const total = props.score?.total ?? props.total ?? props.defaultValue;

  const getColor = useCallback(() => {
    if (total != null) {
      if (total >= 75) {
        return 'primary';
      } else if (total > 25) {
        return 'warning';
      }
    }

    return 'error';
  }, [total]);

  return (
    <Box sx={styles.container}>
      <CircularProgress
        variant={props.type ?? 'determinate'}
        size={60}
        color={getColor()}
        value={total}
        {...props}
      />

      <Tooltip
        title={
          <Typography>
            {Object.keys(props.score ?? {}).map((key, index) =>
              key === 'total' ? null : (
                <span key={index}>
                  {capitalizeFirstLetter(key)}: {(props.score as any)[key]}
                  <br />
                </span>
              )
            )}
            {Object.keys(props.score ?? {}).length > 0 && <br />}
            Total: {total ?? 0}
          </Typography>
        }
      >
        <Box sx={styles.value}>
          <Typography
            variant={total === 0 ? 'h6' : 'h5'}
            component="div"
            color={getColor()}
          >
            {total === 0 ? 'N/A' : total}
          </Typography>
        </Box>
      </Tooltip>
    </Box>
  );
}

const styles: { [key: string]: any } = {
  container: {
    position: 'relative',
    display: 'inline-flex',
    height: 'fit-content',
    marginLeft: 2,
  },
  value: {
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    position: 'absolute',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
  },
};
