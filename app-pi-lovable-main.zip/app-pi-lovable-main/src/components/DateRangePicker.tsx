import { Stack, styled } from '@mui/material';
import { DateRange, PickersShortcutsItem } from '@mui/x-date-pickers-pro';
import {
  DateRangePickerProps,
  DateRangePicker as MUIDateRangerPicker,
} from '@mui/x-date-pickers-pro/DateRangePicker';
import {
  endOfMonth,
  endOfWeek,
  startOfMonth,
  startOfWeek,
  subDays,
  subMonths,
} from 'date-fns';

const DateRangeWrapper = styled(Stack)(`
	padding: 10px 0;
  `);

const shortcutsItems: PickersShortcutsItem<DateRange<Date>>[] = [
  {
    label: 'Last Month',
    getValue: () => {
      const today = new Date();
      const lastMonthDay = subMonths(today, 1);
      return [startOfMonth(lastMonthDay), endOfMonth(lastMonthDay)];
    },
  },
  {
    label: 'Last Week',
    getValue: () => {
      const today = new Date();
      const prevWeekDay = subDays(today, 7);
      return [startOfWeek(prevWeekDay), endOfWeek(prevWeekDay)];
    },
  },
  {
    label: 'Last 7 Days',
    getValue: () => {
      const today = new Date();
      return [subDays(today, 7), today];
    },
  },
  {
    label: 'This Week',
    getValue: () => {
      const today = new Date();
      return [startOfWeek(today), endOfWeek(today)];
    },
  },
  {
    label: 'Current Month',
    getValue: () => {
      const today = new Date();
      return [startOfMonth(today), endOfMonth(today)];
    },
  },
  { label: 'Reset', getValue: () => [null, null] },
];

interface DateRangerPickerInterface extends DateRangePickerProps<Date> {}

const DateRangePicker: React.FC<DateRangerPickerInterface> = props => {
  return (
    <DateRangeWrapper className="!ml-4 !mt-2" direction="row" spacing={3}>
      <MUIDateRangerPicker
        slotProps={{
          textField: { size: 'small' },
          fieldSeparator: { sx: { opacity: 0.5 } },
          shortcuts: {
            items: shortcutsItems,
          },
        }}
        {...props}
      />
    </DateRangeWrapper>
  );
};

export default DateRangePicker;
