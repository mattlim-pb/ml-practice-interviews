import { Typography } from '@mui/material';
import { CircularProgressWithLabel } from './CircularProgressWithLabel';

type CardProps = {
  title: string;
  value?: number | null;
  gauge?: boolean;
};

const Card = ({ title, value, gauge }: CardProps) => {
  const isValidNumber = typeof value === 'number' && !Number.isNaN(value);
  const formattedValue = isValidNumber ? Math.floor(value as number) : null;

  let content;

  if (formattedValue === null) {
    content = 'N/A';
  } else {
    if (gauge) {
      content = (
        <CircularProgressWithLabel
          total={100}
          score={{ total: formattedValue }}
          defaultValue={0}
        />
      );
    } else {
      content = formattedValue;
    }
  }

  return (
    <div className="flex justify-between items-center p-6 border bg-white rounded-xl mx-4 my-4 md:my-0">
      <Typography className="!text-sm !self-end !font-bold" variant="h6">
        {title}
      </Typography>
      <Typography className="!text-4xl !font-bold ">{content}</Typography>
    </div>
  );
};

export default Card;
