import { useTheme } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { APP_PATHS } from '../routes/paths';
import PIDialog from './PIDialog';

interface Props {
  dismissed: boolean;
}
export function UpdatePremiumDialog({ dismissed }: Props) {
  const theme = useTheme();
  const navigate = useNavigate();

  return (
    <PIDialog
      title="Free trial expired"
      description="Your 7 days free trial has expired. Upgrade to Premium today to continue practicing!"
      open={!dismissed}
      onClose={() => {}}
      buttons={[
        {
          text: 'Upgrade now',
          color: theme.palette.primary.main,
          onPress: () => navigate(APP_PATHS.account),
        },
      ]}
    />
  );
}
