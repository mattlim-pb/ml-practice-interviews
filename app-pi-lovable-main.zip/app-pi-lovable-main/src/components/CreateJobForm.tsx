import { Grid, SxProps, TextField, Theme } from '@mui/material';

export default function CreateJobForm({
  title,
  setTitle,
  description,
  setDescription,
}: {
  title: string;
  setTitle: (title: string) => void;
  description: string;
  setDescription: (description: string) => void;
}) {
  return (
    <Grid
      container
      alignItems="center"
      justifyContent="center"
      sx={styles.container}
    >
      <Grid item xs={12}>
        <TextField
          autoFocus
          id="title"
          label="Job title"
          type="text"
          fullWidth
          rows={1}
          variant="outlined"
          value={title}
          onChange={e => setTitle(e.target.value)}
          sx={styles.jobTitle}
        />
        <TextField
          id="description"
          label="Job Description + Additional Notes/Context"
          type="text"
          fullWidth
          multiline
          rows={15}
          variant="outlined"
          value={description}
          onChange={e => setDescription(e.target.value)}
        />
      </Grid>
    </Grid>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  jobTitle: {
    marginBottom: 4,
  },
  title: {
    my: 4,
  },
};
