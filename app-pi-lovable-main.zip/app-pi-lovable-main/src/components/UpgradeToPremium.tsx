import { useNavigate } from 'react-router-dom';
import { APP_PATHS } from '../routes/paths';
import UpgradeSVG from './UpgradeSVG';

export default function UpgradePremium() {
  const navigate = useNavigate();
  return (
    <div className="text-center justify-center ">
      <UpgradeSVG className="w-1/3 h-auto m-auto " />
      <h1
        onClick={() => navigate(APP_PATHS.account)}
        className="hover:underline cursor-pointer text-xl"
      >
        This is a premium feature!{' '}
        <span className="underline font-bold ">Upgrade now</span> to unlock
      </h1>
    </div>
  );
}
