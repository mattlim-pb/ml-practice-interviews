import { useState } from 'react';
import { useInterval } from '../hooks/useInterval';

export function AnimatedAudio({
  maxHeight,
  length,
  isPlaying,
}: {
  maxHeight: number;
  length: number;
  isPlaying?: boolean;
}) {
  const baseAry = new Array(length).fill(Math.random());
  const [ary, setAry] = useState<number[]>(baseAry);
  const randomNumber = () => Math.floor(Math.random() * maxHeight);

  useInterval({
    callback: () => {
      if (!isPlaying) return;
      setAry(new Array(length).fill(Math.random()));
    },
    interval: 200,
  });

  return (
    <div style={{ ...styles.waveContainer, height: maxHeight }}>
      {ary.map((_, index) => (
        <Line height={randomNumber()} key={index} />
      ))}
    </div>
  );
}

const Line = ({ height }: { height: number }) => (
  <div style={{ ...styles.line, height }} />
);

const styles = {
  line: {
    width: '3px',
    borderRadius: '5px',
    margin: '0 2px',
    backgroundColor: 'black',
    transition: 'height 1s',
  },
  waveContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
};
