import MicNoneOutlined from '@mui/icons-material/MicNoneOutlined';
import VideocamIcon from '@mui/icons-material/Videocam';
import { Button, SxProps, Theme } from '@mui/material';

interface Props {
  onStart: () => void;
  isVideo: boolean;
  isRecording: boolean;
  text: string;
  style?: SxProps<Theme>;
}

export function VideoControlButton({
  onStart,
  isVideo,
  text,
  isRecording,
}: Props) {
  return (
    <Button
      className={`
        !rounded-2xl
        !px-8
        !py-4
        !text-base
        !z-40
        !absolute
      `}
      onClick={onStart}
      variant="contained"
      disabled={isRecording}
      sx={{
        textTransform: 'capitalize',
        fontWeight: 'bold',
        opacity: isRecording ? 0 : 1,
        transition: 'opacity 0.5s',
      }}
      startIcon={
        isVideo ? (
          <VideocamIcon color="info" fontSize="large" />
        ) : (
          <MicNoneOutlined color="info" fontSize="large" />
        )
      }
    >
      {text}
    </Button>
  );
}
