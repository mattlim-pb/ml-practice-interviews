import { Typography } from '@mui/material';
import MuiMarkdown, { getOverrides } from 'mui-markdown';

type MarkdownViewProps = {
  children: string;
};

function MarkdownView({ children }: MarkdownViewProps) {
  return (
    <MuiMarkdown
      overrides={{
        ...getOverrides(), // This will keep the other default overrides.
        strong: {
          component: Typography,
          props: {
            variant: 'h2',
            className: '!font-bold',
            sx: { fontSize: 18, display: 'inline' },
          } as React.HTMLProps<HTMLHeadingElement>,
        },
        p: {
          component: Typography,
          props: {
            variant: 'body1',
            className: '!my-2',
          } as React.HTMLProps<HTMLParagraphElement>,
        },
        li: {
          component: 'li',
          props: {
            className: 'pl-4 my-2',
          } as React.HTMLProps<HTMLLIElement>,
        },
        ol: {
          component: 'ol',
          props: {
            className: 'list-decimal pl-6 my-2',
          } as React.HTMLProps<HTMLParagraphElement>,
        },
        h2: {
          component: Typography,
          props: {
            variant: 'h6',
            sx: { mt: 2, mb: 1 },
          } as React.HTMLProps<HTMLHeadingElement>,
        },
        h3: {
          component: Typography,
          props: {
            variant: 'h6',
            sx: { mt: 2, mb: 1 },
          } as React.HTMLProps<HTMLHeadingElement>,
        },
        h4: {
          component: Typography,
          props: {
            variant: 'h6',
            sx: { mt: 2, mb: 1 },
          } as React.HTMLProps<HTMLHeadingElement>,
        },
        h6: {
          component: Typography,
          props: {
            variant: 'h6',
            className: '!font-bold',
            sx: { mt: 2, mb: 1 },
          } as React.HTMLProps<HTMLHeadingElement>,
        },
      }}
    >
      {children.replace(/\n/gi, '\n\n')}
    </MuiMarkdown>
  );
}

export default MarkdownView;
