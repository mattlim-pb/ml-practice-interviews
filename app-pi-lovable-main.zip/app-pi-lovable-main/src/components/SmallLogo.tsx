import LogoImage from '../assets/images/app-icon.png';

export default function Logo(props: React.ComponentProps<'a'>) {
  return (
    <a
      href="https://www.practiceinterviews.com/"
      target="_blank"
      rel="noopener noreferrer"
      className={`py-1`}
      style={{
        display: 'inline-block',
      }}
      {...props}
    >
      <img src={LogoImage} width={24} height={36} alt="Practice Interviews" />
    </a>
  );
}
