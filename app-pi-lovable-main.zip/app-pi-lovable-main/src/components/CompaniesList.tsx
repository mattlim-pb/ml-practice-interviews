import { Box } from '@mui/material';
import { Dispatch, SetStateAction } from 'react';
import { useCompanies } from '../middleware/useCompanies';
import CompanyButton from './CompanyButton';
import { Loading } from './Loading';

const CompaniesList = ({
  presentational,
  selectedCompany,
  disabled,
  setSelectedCompany,
}: {
  disabled?: boolean;
  presentational?: boolean;
  selectedCompany?: any;
  setSelectedCompany?: Dispatch<SetStateAction<any>>;
}) => {
  const { data, isLoading } = useCompanies();
  return (
    <Box
      className={`!grid-cols-1 md:!grid-cols-2 lg:!grid-cols-3 !gap-4 !grid w-full transition-opacity duration-500
      ${disabled ? 'opacity-10' : ''}
    `}
    >
      {isLoading && <Loading />}
      {!isLoading &&
        data?.data.map(
          (company: { id: string; name: string; imageUrl: string }) => {
            const { name, imageUrl } = company;
            const isSelected = selectedCompany?.id === company.id;
            return (
              <CompanyButton
                isSelected={isSelected}
                name={name}
                imageUrl={imageUrl}
                onClick={() => {
                  if (!presentational && !disabled && setSelectedCompany) {
                    setSelectedCompany(company);
                  }
                }}
              />
            );
          }
        )}
    </Box>
  );
};

export default CompaniesList;
