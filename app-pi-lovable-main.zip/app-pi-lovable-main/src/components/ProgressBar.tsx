type ProgressBarProps = {
  status: string;
  totalDuration: number;
  currentPosition: number;
};

const ProgressBar = ({ totalDuration, currentPosition }: ProgressBarProps) => {
  const audioPercentage = Math.ceil((currentPosition / totalDuration) * 100);

  return (
    <div className="bg-coolGray-300 grow h-2 rounded-md flex flex-col justify-center mx-4 overflow-hidden">
      <div
        style={{ width: `${audioPercentage * 1.2}%` }}
        className={`bg-green-700 w-1 h-2 rounded-md block transition-all ease-linear `}
      ></div>
    </div>
  );
};

export default ProgressBar;
