import { PhotoCamera } from '@mui/icons-material';
import { Box, Button } from '@mui/material';
import { useCallback, useEffect, useRef, useState } from 'react';
import { toast } from 'react-toastify';

interface ImageCaptureProps {
  onCapture: (file: File) => void;
  showCamera: boolean;
  capturedImageUrl?: string;
}

export const ImageCapture = ({
  onCapture,
  showCamera = true,
  capturedImageUrl,
}: ImageCaptureProps) => {
  const videoPlayerRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [isInitializing, setIsInitializing] = useState(false);

  const startCamera = useCallback(async () => {
    // If already initializing or stream exists, don't try to start again
    if (isInitializing || streamRef.current) return;

    setIsInitializing(true);

    try {
      // Request camera access
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
      });

      streamRef.current = stream;

      if (videoPlayerRef.current) {
        videoPlayerRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera access error:', err);
      toast.error(
        'Practice Interviews needs access to your camera to use this feature. Please allow camera permissions in your browser settings.'
      );
    } finally {
      setIsInitializing(false);
    }
  }, [isInitializing]);

  const stopCamera = useCallback(() => {
    const stream = streamRef.current;
    if (stream) {
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      streamRef.current = null;

      if (videoPlayerRef.current) {
        videoPlayerRef.current.srcObject = null;
      }
    }
  }, []);

  // Effect to handle camera start/stop based on showCamera prop
  useEffect(() => {
    const handleCameraState = async () => {
      if (showCamera && !streamRef.current && !isInitializing) {
        await startCamera();
      } else if (!showCamera && streamRef.current) {
        stopCamera();
      }
    };

    // Add a small delay to ensure DOM is updated before starting camera
    const timerId = setTimeout(() => {
      handleCameraState();
    }, 50);

    return () => {
      clearTimeout(timerId);
    };
  }, [showCamera, startCamera, stopCamera, isInitializing]);

  // Cleanup on component unmount
  useEffect(() => {
    return () => {
      const stream = streamRef.current;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const captureImage = useCallback(() => {
    if (!videoPlayerRef.current || !canvasRef.current) return;

    const video = videoPlayerRef.current;
    const canvas = canvasRef.current;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const context = canvas.getContext('2d');
    if (!context) return;

    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(async blob => {
      if (!blob) return;
      const file = new File([blob], 'image.png', { type: 'image/png' });
      stopCamera();
      await onCapture(file);
    }, 'image/png');
  }, [onCapture, stopCamera]);

  return (
    <Box sx={{ position: 'relative', width: '100%', maxWidth: 640 }}>
      {showCamera ? (
        <>
          <video
            ref={videoPlayerRef}
            autoPlay
            muted
            playsInline
            style={{ width: '100%', borderRadius: 8 }}
          />
          <canvas ref={canvasRef} style={{ display: 'none' }} />
          <Box
            sx={{
              position: 'absolute',
              top: '80%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              zIndex: 1,
            }}
          >
            <Button
              variant="contained"
              startIcon={<PhotoCamera />}
              onClick={captureImage}
              sx={{
                backgroundColor: theme => theme.interviewAcademy.primaryDark,
                color: 'white',
                '&:hover': {
                  backgroundColor: theme => theme.interviewAcademy.primaryDark,
                  opacity: 0.9,
                },
              }}
            >
              Capture Setup
            </Button>
          </Box>
        </>
      ) : (
        capturedImageUrl && (
          <img
            src={capturedImageUrl}
            alt="Captured setup"
            style={{ width: '100%', borderRadius: 8 }}
          />
        )
      )}
    </Box>
  );
};
