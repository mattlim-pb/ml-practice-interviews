import { CircularProgress, Grid, Typography } from '@mui/material';
import { Gauge } from '@mui/x-charts';
import { gaugeClasses } from '@mui/x-charts/Gauge';
import { useCallback } from 'react';

const HeaderGauge = ({
  totalScoreValue,
  scoreLoading,
  isCommon,
}: {
  totalScoreValue: number;
  scoreLoading?: boolean;
  isCommon: boolean;
}) => {
  const getColor = useCallback(() => {
    if (totalScoreValue != null) {
      if (totalScoreValue >= 75) {
        return '#528075';
      } else if (totalScoreValue > 25) {
        return '#ed6c02';
      }
    }
    return '#d32f2f';
  }, [totalScoreValue]);

  return (
    <Grid item xs={2} sx={styles.gaugeContainer}>
      {!isCommon && (
        <div className="relative">
          <div
            className={`${
              !scoreLoading ? 'opacity-0' : 'opacity-100'
            } transition-opacity absolute bottom-2 left-4`}
          >
            <CircularProgress sx={{ mx: 'auto', mt: 2 }} />
          </div>
          <div
            className={`${
              scoreLoading ? 'opacity-0' : 'opacity-100'
            } transition-opacity flex items-center`}
          >
            <Gauge
              value={totalScoreValue}
              startAngle={0}
              endAngle={360}
              innerRadius="80%"
              outerRadius="100%"
              sx={() => ({
                maxWidth: 75,
                minWidth: 75,
                height: 80,
                display: 'inline-block',
                [`& .${gaugeClasses.valueArc}`]: {
                  fill: getColor(),
                },
              })}
              text={''} //Don't show text
            />
            <div className={`flex items-baseline`}>
              <Typography
                sx={{
                  ...styles.gaugeValue,
                  color: getColor(),
                }}
                fontWeight="bold"
                fontSize={30}
              >
                {totalScoreValue}
              </Typography>
              <Typography
                sx={{
                  ...styles.gaugeValue,
                  color: getColor(),
                }}
              >
                /{100}
              </Typography>
            </div>
          </div>
        </div>
      )}
    </Grid>
  );
};

export default HeaderGauge;

const styles: { [key: string]: any } = {
  gaugeContainer: {
    margin: 'auto',
    flex: 1,
    flexDirection: 'row',
    display: 'flex',
    alignItems: 'center',
  },
  gaugeValue: {
    display: 'inline-block',
  },
};
