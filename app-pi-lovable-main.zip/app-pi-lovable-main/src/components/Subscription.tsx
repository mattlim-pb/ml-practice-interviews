import { Button, CircularProgress, Grid, Typography } from '@mui/material';
import { loadStripe } from '@stripe/stripe-js';
import { format } from 'date-fns';
import { Fragment, useCallback, useMemo } from 'react';
import { Price } from '../data/price';

import { useFeatureFlagVariantKey } from 'posthog-js/react';
import { useRecoilState } from 'recoil';
import { Constants } from '../data/constants';
import useOnInitialMount from '../hooks/useOnInitialMount';
import { useCreateCheckoutSession } from '../middleware/useCreateCheckoutSession';
import { useCreateCustomerPortalSession } from '../middleware/useCreateCustomerPortalSession';
import { useCurrentSubscription } from '../middleware/useCurrentSubscription';
import { usePosthogCapture } from '../middleware/usePostHogCapture';
import { usePrices } from '../middleware/usePrices';
import { userState } from '../states/auth';
import { BASE_URL } from '../utils/env';
import { SubscriptionCard } from './SubscriptionCard';
import { SubscriptionEnterprisePlanCard } from './SubscriptionEnterprisePlanCard';

const subscribe_status = {
  free: 'You’re currently on the <b>FREE</b> plan. Upgrade to PREMIUM for unlimited interview practice, AI feedback, analytics, and resources!',
  premuim:
    'You’re currently on the <b>PREMIUM</b> plan which will renew on %endDate%. Select a longer plan to lock in a lower price upon renewal. You will only be charged when your current plan expires.',
  premium_canceled:
    'Your <b>PREMIUM</b> subscription has been canceled. The good news is that your account will be active until %endDate%.',
  premuim_lifetime:
    'You purchased the <b>PREMIUM LIFETIME</b> plan, which does not expire!',
  b2b: 'You’re currently on the <b>PREMIUM</b> plan courtesy of <b>%clientName%.</b>',
};

const stripePromise = loadStripe(
  process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY ?? ''
);

export function Subscription() {
  const [user] = useRecoilState(userState);
  const { captureEvent } = usePosthogCapture();
  const trialDaysFlagValue = useFeatureFlagVariantKey(
    Constants.POSTHOG_FEATURE_FLAG.trialDays
  );
  const subscriptionPricingFlagValue = useFeatureFlagVariantKey(
    Constants.POSTHOG_FEATURE_FLAG.trialDays
  );
  const getPrices = usePrices();
  const getCurSubscription = useCurrentSubscription();
  const createCheckoutSession = useCreateCheckoutSession();
  const createCustomerPortalSession = useCreateCustomerPortalSession();

  useOnInitialMount(() => {
    getPrices.mutate({});
    getCurSubscription.mutate({});
  });

  const curSubscription = useMemo(
    () => getCurSubscription.data?.data?.data?.subscription,
    [getCurSubscription.data]
  );

  const oneOffPayment = useMemo(
    () => getCurSubscription.data?.data?.data?.oneOffPayment,
    [getCurSubscription.data]
  );

  const prices = useMemo(
    () =>
      (getPrices.data?.data?.data ?? []).filter(
        data => data.interval_count !== 6 && data.interval_count != null
      ),
    [getPrices.data]
  );

  const getSubscribeStatus = useCallback(() => {
    if (user && user?.client && user?.client?.name && !user.isFree) {
      const text = subscribe_status.b2b.replace(
        '%clientName%',
        user.client.name
      );
      return text;
    }

    if (!curSubscription?.id && !oneOffPayment) return subscribe_status.free;

    let endDate;
    if (curSubscription && !user?.client?.name) {
      if (curSubscription?.cancel_at && curSubscription?.canceled_at) {
        endDate = format(
          new Date(curSubscription.cancel_at * 1000),
          'yyyy-MM-dd'
        );
        const text = subscribe_status.premium_canceled.replace(
          '%endDate%',
          endDate
        );
        return text;
      } else {
        if (curSubscription?.status === 'trialing') {
          endDate = format(
            new Date(curSubscription.trial_end * 1000),
            'yyyy-MM-dd'
          );
        } else {
          endDate = format(
            new Date(curSubscription.current_period_end * 1000),
            'yyyy-MM-dd'
          );
        }
        const text = subscribe_status.premuim.replace('%endDate%', endDate);
        return text;
      }
    }
    return subscribe_status.premuim_lifetime;
  }, [user, curSubscription, oneOffPayment]);

  const onManageSubscription = useCallback(async () => {
    createCustomerPortalSession.mutate(
      {
        returnUrl: `${BASE_URL}/account`,
      },
      {
        onSuccess: async data => {
          const sessionUrl = data?.data?.data?.sessionUrl;
          if (sessionUrl) {
            // Redirect the user to the Stripe customer portal
            window.location.href = sessionUrl;
          } else throw new Error('No session-url retrieved!');
        },
        onError: err => {
          console.error(err);
        },
      }
    );
  }, [createCustomerPortalSession]);

  const onSubscribePlan = useCallback(
    async (plan: Price) => {
      const stripe = await stripePromise;
      if (stripe && user) {
        captureEvent(
          {
            name: 'checkout-page-visited',
            params: {
              plan,
              'trial-days-flag':
                trialDaysFlagValue === '3' ? 'enabled' : 'disabled',
              'subscription-pricing-flag':
                subscriptionPricingFlagValue === '27' ? 'enabled' : 'disabled',
            },
          },
          user
        );
        createCheckoutSession.mutate(
          {
            priceId: plan?.id!,
            successUrl: `${BASE_URL}/account`,
            cancelUrl: `${BASE_URL}/account`,
          },
          {
            onSuccess: async data => {
              const sessionId = data?.data?.data?.sessionId;
              if (sessionId) {
                // Redirect to Stripe Checkout
                const { error } = await stripe.redirectToCheckout({
                  sessionId,
                });
                if (error) {
                  console.error('Stripe Checkout error:', error);
                  throw error;
                }
              } else throw new Error('No session-id retrieved!');
            },
            onError: err => {
              console.error(err);
            },
          }
        );
      }
    },
    [
      captureEvent,
      createCheckoutSession,
      subscriptionPricingFlagValue,
      trialDaysFlagValue,
      user,
    ]
  );

  return (
    <Fragment>
      <Grid container rowSpacing={2}>
        {getCurSubscription.isLoading && !getCurSubscription.data ? (
          <CircularProgress color="primary" className="!self-center !mt-8" />
        ) : (
          <>
            <Grid item xs={12}>
              <Typography variant="h5" gutterBottom>
                <b>Subscription Settings</b>
              </Typography>
              <Typography
                variant="subtitle1"
                dangerouslySetInnerHTML={{ __html: getSubscribeStatus() }}
              />
            </Grid>
            <Grid
              container
              item
              xs={12}
              columnSpacing={1}
              rowSpacing={2}
              alignItems={'stretch'}
            >
              {curSubscription && !user?.client ? (
                <Grid item xs={12}>
                  <Button
                    variant="contained"
                    onClick={() => onManageSubscription()}
                    sx={{
                      textTransform: 'none',
                      minWidth: 160,
                      mt: 2,
                    }}
                    color="primary"
                  >
                    Manage Subscription
                  </Button>
                </Grid>
              ) : (
                !oneOffPayment &&
                !user?.client && (
                  <Fragment>
                    {prices.map((plan, index) => (
                      <Grid item xs={6} md={4} key={index}>
                        <SubscriptionCard
                          plan={plan}
                          actionButton={
                            <Button
                              variant="outlined"
                              fullWidth
                              onClick={() => onSubscribePlan(plan)}
                              sx={{
                                textTransform: 'none',
                                borderRadius: 2,
                                mt: 2,
                              }}
                              color="primary"
                            >
                              Select
                            </Button>
                          }
                        />
                      </Grid>
                    ))}
                    <Grid item xs={6} md={4}>
                      <SubscriptionEnterprisePlanCard />
                    </Grid>
                  </Fragment>
                )
              )}
            </Grid>
          </>
        )}
      </Grid>
    </Fragment>
  );
}
