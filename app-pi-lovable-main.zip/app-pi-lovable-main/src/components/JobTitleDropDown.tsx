import { Autocomplete, TextField } from '@mui/material';
import { Job } from '../data/job';
import useOnInitialMount from '../hooks/useOnInitialMount';
import { useJobs } from '../middleware/useJobs';

interface Props {
  onSelect: (selectedJob?: Job | null) => void;
  isLoading: boolean;
}

export function JobTitleDropDown({ onSelect, isLoading }: Props) {
  const getJobs = useJobs();
  useOnInitialMount(() => {
    getJobs.mutate({});
  });
  const options = getJobs.data?.data?.data ?? [];

  return (
    <Autocomplete
      disablePortal
      disabled={isLoading}
      options={options}
      getOptionKey={(option: Job) => option.id}
      getOptionLabel={(option: Job) => option.title}
      fullWidth
      onChange={(_e, value) => {
        value && onSelect(value);
      }}
      renderInput={params => (
        <TextField
          {...params}
          label={!isLoading ? 'Select Job Title' : 'Please wait...'}
        />
      )}
    />
  );
}
