import { Typography } from '@mui/material';

const CompanyButton = ({
  name,
  imageUrl,
  isSelected,
  onClick,
}: {
  name: string;
  imageUrl: string;
  isSelected?: boolean;
  onClick: () => void;
}) => {
  return (
    <button
      className={` h-full  rounded-xl p-6 !shadow hover:!shadow-md hover:text-white flex-1 w-full bg-white transition-all hover:bg-primary
        ${isSelected && '!bg-primary !text-white'}
      `}
      onClick={onClick}
    >
      <div className="flex flex-1 flex-col h-full ">
        <div className="flex flex-row  justify-between items-baseline flex-1">
          <img src={imageUrl} alt={name} width={50} height={50} />
        </div>

        <div className="flex flex-row text-start mt-4 ">
          <Typography
            variant="h5"
            className="!text-base sm:!text-base md:!text-xl lg:!text-2xl !mt-10"
          >
            <b>{name}</b>
          </Typography>
        </div>
      </div>
    </button>
  );
};

export default CompanyButton;
