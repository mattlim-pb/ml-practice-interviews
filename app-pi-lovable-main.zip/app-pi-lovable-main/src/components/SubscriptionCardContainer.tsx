import { Card, styled } from '@mui/material';

export const SubscriptionCardContainer = styled(Card)<{
  popular?: number;
}>(props => {
  return {
    borderColor: props.theme.palette.primary.main,
    borderWidth: 2,
    borderRadius: 20,
    paddingTop: 45,
    backgroundColor: props.popular ? props.theme.palette.primary.main : '#fff',
    color: props.popular ? 'white' : 'rgba(0, 0, 0, 0.87)',
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    position: 'relative',
  };
});
