import { Typography } from '@mui/material';
import { BarChart } from '@mui/x-charts/BarChart';
import { AverageScore } from '../../middleware/useAnalytics';

export default function AverageChart({ data }: { data: AverageScore }) {
  const formatedData = Object.keys(data).map(key => {
    const typedKey = key as keyof AverageScore;
    return {
      label: key,
      yours: Math.floor(data[typedKey]?.you ?? 0),
      avarage: Math.floor(data[typedKey]?.everyone ?? 0),
    };
  });

  return (
    <div className="bg-fit bg-no-repeat bg-center w-full h-96 md:h-80 rounded-xl">
      <div className="flex items-baseline ">
        <div className="w-1/2">
          <Typography
            variant="h6"
            className="!font-bold !m-6 !mt-2 !mb-0 !inline-block !text-base md:!text-lg"
          >
            Average Score
            <Typography className="!ml-2 !inline-block !text-base">
              (last 4 weeks)
            </Typography>
          </Typography>
        </div>
        <div className="w-1/2 flex flex-row justify-end mr-4">
          <div className="flex flex-row ">
            <div className="bg-primary aspect-square h-4 rounded-md mx-2"></div>
            <Typography className="!text-sm">Your scores</Typography>
          </div>
          <div className="flex flex-row ">
            <div className="bg-gray-400 aspect-square h-4 rounded-md mx-2"></div>
            <Typography className="!text-sm">Average</Typography>
          </div>
        </div>
      </div>

      <BarChart
        sx={{
          width: '100%',
        }}
        height={280}
        barLabel={'value'}
        borderRadius={10}
        dataset={formatedData}
        yAxis={[
          {
            max: 100,
          },
        ]}
        xAxis={[
          {
            //@ts-expect-error categotyGapRatio is aparently not a valid prop, but is needed to meet design requirements
            categoryGapRatio: 0.5,
            dataKey: 'label',
            scaleType: 'band',
          },
        ]}
        series={[
          {
            dataKey: 'yours',
            color: '#528075',
          },
          {
            dataKey: 'avarage',
            color: '#CCCCCC',
          },
        ]}
      />
    </div>
  );
}
