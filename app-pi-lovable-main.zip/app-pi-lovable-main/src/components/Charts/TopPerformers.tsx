import { Typography } from '@mui/material';
import { PerformerType } from '../../middleware/useAnalytics';

const Icons = ['🥇', '🥈', '🥉', ''];

interface TopPerformersProps {
  data: PerformerType[];
}

export default function TopPerformers({ data }: TopPerformersProps) {
  return (
    <div className="bg-fit bg-no-repeat bg-center w-full h-96 md:h-80 rounded-xl p-4">
      <div className="flex items-baseline ">
        <div className="w-full">
          <Typography variant="h6" className="!font-bold !mb-4 !inline-block">
            Top 3 Performers
            <Typography className="!ml-2 !inline-block">
              (last 4 weeks)
            </Typography>
          </Typography>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3 mx-6">
        <>
          <div>{'Users'}</div>

          <div className="text-center">Qu's</div>
          <div className="text-center">Avg. Score</div>
        </>
      </div>
      {data.map(
        (
          {
            username,
            isCurrentUser,
            questionsAttempted,
            rank,
            averageScore,
          }: PerformerType,
          index: number
        ) => (
          <div
            key={index}
            className={`${
              isCurrentUser && 'border border-primary  rounded-lg'
            } grid grid-cols-3 gap-3 mx-4 p-2 cursor-pointer hover:bg-slate-50 transition-all `}
          >
            <div className="flex justify-between">
              <div className="mr-4">{rank}</div>
              <div className="flex-grow ">{username}</div>
              <div>{Icons[index]}</div>
            </div>
            <div className="text-center">{questionsAttempted}</div>
            <div className="text-center">{averageScore}</div>
          </div>
        )
      )}
    </div>
  );
}
