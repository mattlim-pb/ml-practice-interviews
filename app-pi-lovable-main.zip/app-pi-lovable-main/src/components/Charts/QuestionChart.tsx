import { Typography } from '@mui/material';
import { LineChart } from '@mui/x-charts';
import { QuestionsAttempted } from '../../middleware/useAnalytics';

export default function QuestionChart({ data }: { data: QuestionsAttempted }) {
  const dataSet = Object.keys(data).map(key => ({
    date: new Date(key),
    attempts: data[key],
  }));
  return (
    <div className="bg-fit bg-no-repeat bg-center w-full rounded-xl">
      <div className="bg-fit bg-no-repeat bg-center h-96 w-full rounded-xl">
        <Typography
          variant="h6"
          className="!font-bold !m-6 !mt-2 !mb-0 !inline-block"
        >
          Questions Attemped
          <Typography className="!ml-2 !inline-block">
            (last 4 weeks)
          </Typography>
        </Typography>
        <LineChart
          height={300}
          sx={{
            width: '100%',
          }}
          dataset={dataSet}
          xAxis={[{ dataKey: 'date', scaleType: 'utc' }]}
          series={[
            {
              dataKey: 'attempts',
            },
          ]}
        />
      </div>
    </div>
  );
}
