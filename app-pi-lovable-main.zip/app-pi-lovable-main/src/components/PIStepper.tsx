import { Button, CircularProgress, MobileStepper } from '@mui/material';

interface Props {
  activeStep: number;
  steps: number;
  onNext?: () => void;
  onBack?: () => void;
  nextButtonDisabled?: boolean;
  backButtonDisabled?: boolean;
  isLoading?: boolean;
}

export function PIStepper({
  activeStep,
  steps,
  onNext,
  onBack,
  nextButtonDisabled = false,
  backButtonDisabled = false,
  isLoading = false,
}: Props) {
  return (
    <MobileStepper
      variant="dots"
      steps={steps}
      position="static"
      activeStep={activeStep}
      sx={{
        flexGrow: 1,
        '& .MuiMobileStepper-dot': {
          backgroundColor: 'info.main',
          borderWidth: 1,
          borderColor: 'black',
          width: 12,
          height: 12,
          mx: 0.5,
        },
        '& .MuiMobileStepper-dotActive': {
          backgroundColor: 'primary.main',
          border: 'none',
        },
      }}
      className=""
      nextButton={
        <Button
          onClick={onNext}
          variant="contained"
          sx={{
            fontWeight: 'bold',
          }}
          disabled={nextButtonDisabled}
        >
          Next
          {isLoading && (
            <CircularProgress
              size={20}
              color="success"
              sx={{ mx: 'auto', my: 'auto', ml: 2 }}
            />
          )}
        </Button>
      }
      backButton={
        <Button
          onClick={onBack}
          variant="text"
          disabled={activeStep === 0 || backButtonDisabled}
          sx={{ fontWeight: 'bold' }}
        >
          Back
        </Button>
      }
    />
  );
}
