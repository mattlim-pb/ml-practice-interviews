import {
  Button,
  CardActions,
  CardContent,
  Typography,
  useTheme,
} from '@mui/material';
import { useState } from 'react';
import PIDialog from './PIDialog';
import { SubscriptionRibbon } from './SubscriptionCard';
import { SubscriptionCardContainer } from './SubscriptionCardContainer';

export function SubscriptionEnterprisePlanCard() {
  const theme = useTheme();
  const [emailDialogDismissed, setEmailDialogDismissed] =
    useState<boolean>(true);

  return (
    <SubscriptionCardContainer variant="outlined">
      <SubscriptionRibbon text="RECRUITING AGENCY, COLLEGE / UNIVERSITY" />
      <CardContent>
        <Typography variant="h5" gutterBottom>
          <b>Enterprise</b>
        </Typography>
        <Typography variant="body2" gutterBottom>
          Get in touch with our team to learn more.
        </Typography>
      </CardContent>
      <CardActions>
        <Button
          variant="outlined"
          fullWidth
          onClick={() => {
            setEmailDialogDismissed(false);
          }}
          sx={{
            textTransform: 'none',
            borderRadius: 2,
            mt: 2,
          }}
          color="primary"
        >
          Contact Us
        </Button>
      </CardActions>

      <PIDialog
        title="Contact us"
        description={
          <span>
            Want to learn about how Practice Interviews AI can help your
            organisation? Please feel free to contact us:{' '}
            <b>
              <a
                href="mailto: jeff@practiceinterviews.com"
                style={{
                  textDecoration: 'underline',
                  color: theme.palette.primary.main,
                }}
              >
                jeff@practiceinterviews.com
              </a>
            </b>
          </span>
        }
        open={!emailDialogDismissed}
        onClose={() => {
          setEmailDialogDismissed(true);
        }}
        buttons={[
          {
            text: 'Okay',
            color: theme.palette.primary.main,
          },
        ]}
      />
    </SubscriptionCardContainer>
  );
}
