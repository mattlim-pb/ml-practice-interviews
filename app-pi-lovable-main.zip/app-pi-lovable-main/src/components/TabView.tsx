import { Tabs, Typography } from '@mui/material';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import * as React from 'react';

interface Props {
  labels: string[];
  pages: React.ReactNode[];
}
function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function CustomTabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box>{children}</Box>}
    </div>
  );
}

export function TabView({ labels, pages }: Props) {
  const [value, setValue] = React.useState(0);

  const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <div>
      <div>
        <Tabs className="!mb-2" value={value} onChange={handleChange}>
          {labels.map((label, index) => {
            const selected = value === index;
            return (
              <Tab
                sx={{
                  flex: 1,
                }}
                key={index}
                label={
                  <Typography
                    sx={{
                      textTransform: 'none',
                      fontWeight: selected ? '600' : '400',
                    }}
                  >
                    {label}
                  </Typography>
                }
                {...a11yProps(index)}
              />
            );
          })}
        </Tabs>
      </div>
      {pages.map((page, index) => (
        <CustomTabPanel key={index} value={value} index={index}>
          {page}
        </CustomTabPanel>
      ))}
    </div>
  );
}
