import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { Tooltip, Typography } from '@mui/material';

const StartPracticingButton = ({
  title,
  onClick,
  info,
  icon,
  disabled,
  isSelected,
  nowrap,
}: {
  title: string;
  onClick: () => void;
  info?: string;
  disabled?: boolean;
  icon: React.ReactNode;
  isSelected?: boolean;
  nowrap?: boolean;
}) => {
  return (
    <button
      className={`transition-colors h-full border rounded-xl border-slate-600 p-6 !shadow-lg hover:!shadow-xl flex-1 w-full hover:bg-primary hover:text-white group :
      ${disabled ? 'opacity-50' : ''}
      ${isSelected ? 'bg-primary text-white' : ''}`}
      onClick={() => !disabled && onClick()}
    >
      <div className="flex flex-1 flex-col h-full ">
        <div className="flex flex-row  justify-between items-baseline flex-1">
          {icon}

          {info && (
            <Tooltip
              title={info.split('|').map(i => (
                <span className="!w-full !block" key={i}>
                  {i}
                </span>
              ))}
            >
              <InfoOutlinedIcon className="!stroke-white group-hover:!stroke-primary " />
            </Tooltip>
          )}
        </div>
        {nowrap && <div className="h-14" />}

        <div className="flex flex-row text-start mt-4 ">
          <Typography
            variant="h5"
            className={`
              !text-base sm:!text-base md:!text-xl lg:!text-2xl !mt-10
              ${nowrap ? 'w-full' : 'w-1/2 lg:w-1/3'}
            `}
          >
            <b>
              {title.split('|').map(i => (
                <span className="!w-full !block" key={i}>
                  {i}
                </span>
              ))}
            </b>
          </Typography>
        </div>
      </div>
    </button>
  );
};

export default StartPracticingButton;
