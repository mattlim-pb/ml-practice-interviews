import { Box, Typography } from '@mui/material';
import { ReactNode, useEffect, useRef, useState } from 'react';
import { TabView } from './TabView';

export interface TextItem {
  [key: string]: string;
}

export interface TwoColumnLayoutProps {
  title: string;
  duration?: string;
  leftContent: ReactNode;
  rightContent?: ReactNode;
  texts?: TextItem[];
}

export function TwoColumnLayout({
  title,
  duration,
  leftContent,
  rightContent,
  texts = [],
}: TwoColumnLayoutProps) {
  const leftColumnRef = useRef<HTMLDivElement>(null);
  const [columnHeight, setColumnHeight] = useState<number | null>(null);

  useEffect(() => {
    const updateHeight = () => {
      if (leftColumnRef.current) {
        const element = leftColumnRef.current.firstElementChild;
        if (element) {
          setColumnHeight(element.clientHeight);
        }
      }
    };

    // Initial update
    updateHeight();

    // Update on resize
    window.addEventListener('resize', updateHeight);

    // Update after content loads
    const timer = setTimeout(updateHeight, 1000);

    return () => {
      window.removeEventListener('resize', updateHeight);
      clearTimeout(timer);
    };
  }, []);

  // Process the texts array
  const hasMultipleTexts = texts.length > 1;
  const textLabels = texts.map(item => Object.keys(item)[0]);
  const textPages = texts.map(item => {
    const key = Object.keys(item)[0];
    const content = item[key];
    return (
      <Box
        sx={{
          p: 2,
          height: '100%',
          overflowY: 'auto',
        }}
      >
        <Typography
          variant="body2"
          sx={{
            whiteSpace: 'pre-line',
          }}
        >
          {content}
        </Typography>
      </Box>
    );
  });

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
      }}
    >
      {/* Row 1: Title */}
      <Box sx={{ mb: 1 }}>
        <Typography
          variant="subtitle1"
          sx={{
            fontWeight: 600,
            fontSize: '16px',
          }}
        >
          {title}
        </Typography>
      </Box>

      {/* Row 2: Duration */}
      {duration && (
        <Box sx={{ mb: 2 }}>
          <Typography
            variant="body2"
            sx={{
              fontWeight: 400,
              fontSize: '14px',
              color: 'text.secondary',
            }}
          >
            {duration}
          </Typography>
        </Box>
      )}

      {/* Row 3: Two-column layout */}
      <Box
        sx={{
          display: 'flex',
          flexGrow: 1,
          width: '100%',
        }}
      >
        {/* Left column - 60% width */}
        <Box
          ref={leftColumnRef}
          sx={{
            width: '60%',
            borderRadius: '8px',
            mr: 2,
          }}
        >
          {leftContent}
        </Box>

        {/* Right column - 40% width */}
        <Box
          sx={{
            width: '40%',
            borderRadius: '8px',
            border: '1px solid #e0e0e0',
            display: 'flex',
            flexDirection: 'column',
            height: columnHeight ? `${columnHeight}px` : 'auto',
            overflow: 'hidden',
          }}
        >
          {texts.length > 0 ? (
            hasMultipleTexts ? (
              <TabView labels={textLabels} pages={textPages} />
            ) : (
              textPages[0]
            )
          ) : rightContent ? (
            rightContent
          ) : (
            <Box
              sx={{
                p: 2,
                height: '100%',
                overflowY: 'auto',
              }}
            >
              <Typography variant="body2" sx={{ whiteSpace: 'pre-line' }}>
                No content available.
              </Typography>
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
}
