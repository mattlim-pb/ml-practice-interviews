import SvgIcon from '@mui/material/SvgIcon';
import * as React from 'react';

function Lightning(props: React.SVGProps<SVGSVGElement>) {
  return (
    <SvgIcon>
      <svg width="1em" height="1em" viewBox="0 0 22 32" fill="none" {...props}>
        <path
          d="M19.987 5.658c.066-.09.14-.175.215-.259 1.224-1.384.272-3.649-1.61-3.649H9.828c-.617 0-1.205.27-1.613.74l-6.42 9.865C.565 13.77 1.552 16 3.408 16h.403c1.763 0 2.76 2.026 1.76 3.456a1.275 1.275 0 00-.138.245l-3.3 8.04c-.072.174-.176.333-.261.5-.452.883.165 2.009 1.208 2.009.257 0 .508-.074.725-.215l13.226-10.622c1.537-.992.847-3.413-.973-3.413-1.608 0-2.412-1.959-1.32-3.122a1.35 1.35 0 00.108-.13l5.141-7.09z"
          stroke={'#000'}
          className={props.className}
          strokeWidth={2}
        />
      </svg>
    </SvgIcon>
  );
}

export default React.memo(Lightning);
