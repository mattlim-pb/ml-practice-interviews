import * as React from 'react';

function SearchIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg width="25" height="25" viewBox="0 0 30 30" fill="none" {...props}>
      <path
        d="M28.5 28.5l-6.62-6.607m0 0a11.905 11.905 0 003.505-8.45c0-6.596-5.347-11.943-11.943-11.943C6.847 1.5 1.5 6.847 1.5 13.442c0 6.596 5.347 11.943 11.942 11.943 3.295 0 6.278-1.335 8.439-3.492z"
        stroke={props.color ?? '#000'}
        strokeWidth={2}
        strokeLinecap="round"
        className={props.className}
      />
    </svg>
  );
}

export default React.memo(SearchIcon);
