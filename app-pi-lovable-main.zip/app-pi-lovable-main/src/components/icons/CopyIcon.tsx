import * as React from 'react';

function Copy(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg width="25" height="25" viewBox="0 0 26 32" fill="none" {...props}>
      <path
        d="M19.288 7.23h2.481a3 3 0 013 3v17.02a3 3 0 01-3 3H10.231a3 3 0 01-3-3v-2.48M9.423 2.845v6.577H2.846M1.75 8.028L7.94 1.75h8.348a3 3 0 013 3v17.02a3 3 0 01-3 3H4.75a3 3 0 01-3-3V8.027z"
        stroke={props.color ?? '#000'}
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
        className={props.className}
      />
    </svg>
  );
}

export default React.memo(Copy);
