import { Box } from '@mui/material';
import { useCallback, useEffect, useRef } from 'react';

interface Props {
  documentUrl: string;
}

export function GoogleDocThumbnail({ documentUrl }: Props) {
  const iFrameRef = useRef<HTMLIFrameElement>(null);
  const extractDocId = useCallback(() => {
    const match = documentUrl.match(/\/document\/d\/([^/]+)/);
    return match ? match[1] : null;
  }, [documentUrl]);

  const googleDocUrl = `https://docs.google.com/viewer?url=https://docs.google.com/document/d/${extractDocId()}/export?format=doc&embedded=true`;

  useEffect(() => {
    const interval = setInterval(() => {
      const hasDocLoadError =
        iFrameRef.current?.contentDocument?.referrer != null;
      if (hasDocLoadError) {
        // reload google doc manually
        iFrameRef.current!.src = googleDocUrl;
      } else {
        clearInterval(interval);
      }
    }, 1000);

    return () => {
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Box className="border-2 border-gray-200 p-4 rounded-lg w-60 min-w-min mx-2 ">
      <iframe ref={iFrameRef} title={extractDocId() ?? ''} src={googleDocUrl} />
    </Box>
  );
}
