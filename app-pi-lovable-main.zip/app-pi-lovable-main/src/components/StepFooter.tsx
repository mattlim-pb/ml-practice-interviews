import { Refresh } from '@mui/icons-material';
import { Box, Button, ButtonProps } from '@mui/material';

interface FooterButton {
  text: string;
  onClick: () => void;
  disabled?: boolean;
  variant?: ButtonProps['variant'];
  color?: ButtonProps['color'];
}

interface StepFooterProps {
  leftButton?: FooterButton;
  rightButtons?: FooterButton[];
}

export function StepFooter({ leftButton, rightButtons }: StepFooterProps) {
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-between',
        mt: 2,
      }}
    >
      {/* Left-aligned button */}
      <Box>
        {leftButton && (
          <Button
            variant="text"
            onClick={leftButton.onClick}
            disabled={leftButton.disabled}
            sx={{
              textTransform: 'none',
              fontWeight: 'normal',
              color: theme => theme.interviewAcademy.primaryDark,
            }}
          >
            {leftButton.text}
          </Button>
        )}
      </Box>

      {/* Right-aligned buttons */}
      <Box sx={{ display: 'flex', gap: 2 }}>
        {rightButtons?.map((button, index) => {
          const isLastButton = index === rightButtons.length - 1;

          return (
            <Button
              key={index}
              variant={isLastButton ? 'contained' : 'outlined'}
              onClick={button.onClick}
              disabled={button.disabled}
              sx={{
                textTransform: 'none',
                borderRadius: '8px',
                padding: '8px 16px',
                ...(isLastButton
                  ? {
                      bgcolor: theme => theme.interviewAcademy.primaryDark,
                      color: 'white',
                      '&:hover': {
                        bgcolor: theme => theme.interviewAcademy.primaryDark,
                        opacity: 0.9,
                      },
                    }
                  : {
                      bgcolor: 'white',
                      border: '1px solid #E0E0E0',
                      color: 'text.primary',
                    }),
                display: 'flex',
                alignItems: 'center',
                gap: 0.5,
              }}
            >
              {button.text === 'Try Again' && <Refresh />}
              {button.text}
            </Button>
          );
        })}
      </Box>
    </Box>
  );
}
