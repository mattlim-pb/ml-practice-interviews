import {
  CardActions,
  CardContent,
  Stack,
  styled,
  Typography,
} from '@mui/material';
import { addDays, addMonths, addWeeks, addYears, format } from 'date-fns';
import { ReactNode, useCallback } from 'react';
import { Price } from '../data/price';
import { SubscriptionCardContainer } from './SubscriptionCardContainer';

const MarkContainer = styled(Stack)`
  position: absolute;
  top: 20px;
  left: 10px;
  right: 10px;
`;

export const SubscriptionRibbon = ({ text }: { text: string }) => {
  return (
    <MarkContainer direction="row" alignItems="center" gap={1}>
      <Typography fontSize={12} fontWeight="bold">
        <b>{text}</b>
      </Typography>
    </MarkContainer>
  );
};

interface Props {
  plan: Price;
  actionButton?: ReactNode;
}

export function SubscriptionCard({ plan, actionButton }: Props) {
  const getAmount = useCallback(
    (amount: number, interval_count: number = 1) => {
      const value = amount / 100 / interval_count;
      if (Number.isInteger(value)) {
        return value;
      } else return value.toFixed(2);
    },
    []
  );

  const getPriceText = useCallback((price: Price): string => {
    let text = !price.interval
      ? `You will be charged $${price.amount / 100.0} today`
      : `You will be charged $${
          price.amount / 100.0
        } today with the next payment automatically taken on %endDate%`;
    const today = new Date();
    if (price.interval && price.interval_count) {
      const endDate =
        price.interval === 'month'
          ? addMonths(today, price.interval_count)
          : price.interval === 'year'
          ? addYears(today, price.interval_count)
          : price.interval === 'day'
          ? addDays(today, price.interval_count)
          : addWeeks(today, price.interval_count);
      const formattedEndDate = format(endDate, 'dd MMM yyyy');
      return text.replaceAll('%endDate%', formattedEndDate);
    }
    return text;
  }, []);

  return (
    <SubscriptionCardContainer variant="outlined">
      <SubscriptionRibbon
        text={
          plan.interval_count === 1
            ? "I'M INTERVIEWING NOW!"
            : "I'M INTERVIEWING SOON!"
        }
      />
      <CardContent>
        <Typography variant="h5" gutterBottom>
          <b>{plan.product?.name}</b>
        </Typography>
        <Typography variant="body2" gutterBottom>
          <b>${getAmount(plan.amount, plan.interval_count ?? 1)} per month</b>
        </Typography>
        <Typography variant="body2" gutterBottom>
          {getPriceText(plan)}
        </Typography>
      </CardContent>
      <CardActions>{actionButton}</CardActions>
    </SubscriptionCardContainer>
  );
}
