import * as amplitude from '@amplitude/analytics-browser';
import { Box, Grid, Typography } from '@mui/material';
import { useCallback } from 'react';
import { Job } from '../data/job';
import { useFormattedText } from '../hooks/useFormattedText';
import useOnInitialMount from '../hooks/useOnInitialMount';
import { useAnswerFeedback } from '../middleware/useAnswerFeedback';
import { useCurrentSubscription } from '../middleware/useCurrentSubscription';
import { useMe } from '../middleware/useMe';
import { JobTitleDropDown } from './JobTitleDropDown';
import { Subscription } from './Subscription';

export default function ChooseJobSelector({
  setSelectedJob,
  selectedJob,
}: {
  setSelectedJob: (job: Job | null | undefined) => void;
  selectedJob?: Job | null;
}) {
  const getCurSubscription = useCurrentSubscription();
  const { isLoading: isFetchingAnswerFeedbacks } = useAnswerFeedback(true);
  const { isLoading: isLoadingUser, canPractice } = useMe();

  const isLoading =
    getCurSubscription.isLoading || isFetchingAnswerFeedbacks || isLoadingUser;

  const formattedText = useFormattedText();

  const handleJobTitleClick = useCallback(
    (job: Job | null | undefined) => {
      setSelectedJob(job);
    },
    [setSelectedJob]
  );

  useOnInitialMount(() => {
    setSelectedJob(null);
    amplitude.track('Select Job Title');
    getCurSubscription.mutate({});
  });

  return (
    <Grid justifyContent="center" alignItems="top">
      <Grid item xs={12} className="pb-16">
        {canPractice ? (
          <Box
            display="flex"
            flexWrap="wrap"
            justifyContent="flex-start"
            gap={2}
            my={4}
          >
            <JobTitleDropDown
              isLoading={isLoading}
              onSelect={handleJobTitleClick}
            />
            {selectedJob != null && (
              <>
                <Typography mt={2}>
                  Here's your job description. Click <b>Confirm</b> to get
                  started. Ability to edit or add your own job description
                  coming soon!
                </Typography>

                <Box my={1}>
                  <Typography variant="subtitle1">
                    {formattedText(selectedJob.description)}
                  </Typography>
                </Box>
              </>
            )}
          </Box>
        ) : (
          <Subscription />
        )}
      </Grid>
    </Grid>
  );
}
