import { Box, Typography } from '@mui/material';
import { useCallback } from 'react';

interface Props {
  videoUrl: string;
  title?: string;
  description?: string;
  plain?: boolean;
}

export function YouTubeThumbnail({
  videoUrl,
  title,
  description,
  plain,
}: Props) {
  const getYouTubeVideoId = useCallback((url: string) => {
    var regex = /[?&]v=([^?]+)/;
    var match = url.match(regex);
    if (match && match[1]) {
      return match[1];
    } else {
      regex = /youtu\.be\/([^?]+)/;
      match = url.match(regex);
      if (match && match[1]) {
        return match[1];
      } else {
        return null;
      }
    }
  }, []);

  const videoId = getYouTubeVideoId(videoUrl);

  return (
    <Box
      className={`${
        !plain
          ? 'border border-textBorder p-4 rounded-lg w-60 min-w-min mx-2'
          : 'w-full'
      }`}
    >
      {title && (
        <Typography variant="h6" className="!font-bold pb-4">
          {title}
        </Typography>
      )}
      <iframe
        src={`https://www.youtube.com/embed/${videoId}?rel=0`}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        title="Preview"
        className={`w-full aspect-video ${plain && 'rounded-3xl'}`}
      />
      {description && <Typography className="pt-4">{description}</Typography>}
      {}
    </Box>
  );
}
