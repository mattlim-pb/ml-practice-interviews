import { Link, Paper, Typography, useTheme } from '@mui/material';
import { CSSProperties } from 'react';

interface Props {
  title: string;
  description: string;
  selected: boolean;
  onClick: (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
  onViewDetails?: () => void;
}

export function CategoryButton({
  onClick,
  selected,
  title,
  description,
  onViewDetails,
}: Props) {
  const theme = useTheme();
  return (
    <div style={styles.container} onClick={onClick}>
      <Paper
        style={{
          ...styles.paper,
          borderColor: theme.palette.primary.main,
          backgroundColor: selected
            ? theme.palette.primary.main
            : theme.palette.common.white,
        }}
      >
        <Typography
          fontWeight="bold"
          variant="h6"
          style={styles.title}
          sx={{
            color: selected
              ? theme.palette.common.white
              : theme.palette.common.black,
          }}
        >
          {title}
        </Typography>
        <Typography
          fontSize={16}
          sx={{
            color: selected
              ? theme.palette.common.white
              : theme.palette.common.black,
          }}
        >
          {description}
        </Typography>
        {onViewDetails && (
          <Link
            sx={{
              mt: 2,
              display: 'inline-block',
            }}
            style={{
              fontSize: 14,
              color: selected
                ? theme.palette.common.white
                : theme.palette.primary.main,
            }}
            onClick={onViewDetails}
            href="#"
            underline="always"
          >
            View details
          </Link>
        )}
      </Paper>
    </div>
  );
}

const styles: { [key: string]: CSSProperties } = {
  container: {
    marginTop: 16,
    marginBottom: 16,
    cursor: 'pointer',
    flexBasis: '100%',
  },
  paper: {
    padding: 16,
    borderWidth: 1,
    borderRadius: 10,
    height: '100%',
    transition: 'background-color 0.5s',
  },
  title: {
    marginBottom: 16,
  },
};
