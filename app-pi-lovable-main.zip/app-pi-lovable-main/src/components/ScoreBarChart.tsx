import { Popper, SxProps, Theme, styled } from '@mui/material';
import { BarChart, BarElement, BarPlot } from '@mui/x-charts/BarChart';

const getColor = (value: number) => {
  if (value >= 75) {
    return '#E3F7DA';
  } else if (value > 25) {
    return '#FFE2A9';
  } else {
    return '#FCDDDD';
  }
};

const ChartsTooltipRoot = styled(Popper, {
  name: 'MuiChartsTooltip',
  slot: 'Root',
  overridesResolver: (_, styles) => styles.root,
})<{
  bgcolor: string;
}>(({ theme, bgcolor }) => {
  return {
    pointerEvents: 'none',
    zIndex: theme.zIndex.modal,
    '& .MuiChartsTooltip-mark': {
      background: bgcolor,
    },
  };
});

interface Props {
  dataset: {
    label: string;
    value: number;
  }[];
  vertical?: boolean;
  legendLabel: string;
  style?: SxProps<Theme>;
}
export function ScoreBarChart({
  dataset,
  legendLabel,
  style,
  vertical,
}: Props) {
  const SlotBarElement = (props: any) => {
    if (props.ownerState.dataIndex >= 0) {
      const value = dataset[props.ownerState.dataIndex]?.value ?? 0;
      const color = getColor(value);
      // work around export of BarElement
      return (
        <BarElement
          {...props}
          style={{
            ...props.style,
            fill: color,
          }}
          dataIndex={props.ownerState.dataIndex}
          borderRadius={10}
        />
      );
    } else return <></>;
  };

  const CustomPopperRoot = (props: any) => {
    const dataIndex = props.children?.props?.axisData?.y?.index ?? 0;
    const value = dataset[dataIndex]?.value ?? 0;
    const color = getColor(value);
    return <ChartsTooltipRoot {...props} bgcolor={color} />;
  };

  return (
    <BarChart
      dataset={dataset}
      barLabel={'value'}
      yAxis={[{ dataKey: 'label', scaleType: 'band' }]}
      xAxis={[
        {
          max: 100,
        },
      ]}
      series={[{ dataKey: 'value', label: legendLabel }]}
      height={300}
      layout={vertical ? 'vertical' : 'horizontal'}
      slotProps={{
        legend: {
          itemMarkHeight: 0,
        },
      }}
      margin={{ left: 100 }}
      sx={style}
      slots={{ popper: CustomPopperRoot }}
      borderRadius={10}
    >
      <BarPlot
        barLabel={'value'}
        slots={{
          bar: SlotBarElement,
        }}
        borderRadius={10}
      />
    </BarChart>
  );
}
