import { Job } from './job';

export type QuestionType =
  | 'hypothetical'
  | 'behavioral'
  | 'both'
  | 'common'
  | 'generic';
export interface Question {
  id: string;
  questionType: QuestionType;
  idealAnswer?: string;
  questionTypeDetail: string;
  text: string;
  jobId: string;
  job: Job;
}
