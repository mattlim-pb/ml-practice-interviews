export interface Job {
  id: string;
  title: string;
  companyId: string;
  companyName: string;
  description: string;
  createdAt: string;
  userId?: string;
}
