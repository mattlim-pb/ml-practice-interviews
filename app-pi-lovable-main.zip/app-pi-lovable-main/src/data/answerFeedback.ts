import { ModularFeedbacksType } from '../states/modularFeedbacks';
import { Job } from './job';
import { Question } from './question';
import { ScoreResult } from './scoreResult';

export interface AnswerFeedback {
  job: Job;
  modularFeedbacks: ModularFeedbacksType;
  score?: number;
  feedback?: string;
  id: string;
  questionId: string;
  answer: string;
  videoUrl?: string;
  audioUrl?: string;
  question: Question;
  createdAt: string;
  recordingLength: number;
  scoreDetail?: ScoreResult;
}
