export enum MessageType {
  User = 'user',
  Assistant = 'assistant',
  System = 'system',
}

export enum MessageDataType {
  Images = 'images',
}

export interface Message {
  id: string;
  content: {
    text: string;
    audioUrl?: string;
    imageUrls?: string[];
    imageUrl?: string;
    buttons?: string[];
  };
  messageType: MessageType;
  createdAt: string;
  dataType?: MessageDataType;
  data?: string[];
  previousMessageId: string;
  isLastInThread: boolean;
}
