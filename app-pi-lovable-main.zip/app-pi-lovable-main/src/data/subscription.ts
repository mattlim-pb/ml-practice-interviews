export interface Subscription {
  id: string;
  userId: string;
  priceId: string;
  stripeId: string;
  startDate?: Date;
  endDate?: Date;
  active?: boolean;
}
