export const sectionsTitle: { [key: string]: { title: string } } = {
  quickWins: {
    title: 'Quick Wins',
  },
  framework: {
    title: 'Framework',
  },
  solution: {
    title: 'Solution',
  },
  assumptions: {
    title: 'Assumptions',
  },
  summary: {
    title: 'Summary',
  },
  results: {
    title: 'Result',
  },
  situation: {
    title: 'Situation',
  },
  task: {
    title: 'Task',
  },
  action: {
    title: 'Action',
  },
  result: {
    title: 'Result',
  },
  actions: {
    title: 'Actions',
  },
  clarify: {
    title: 'Clarify',
  },
  situationAndTask: {
    title: 'Situation & Task',
  },
};

export const behavioral = {
  summary: '0',
  situationAndTask: '25',
  actions: '50',
  results: '25',
};

export const hypothetical = {
  summary: '0',
  clarify: '20',
  framework: '20',
  assumptions: '20',
  solution: '40',
};
