import { Product } from './product';

export interface Price {
  id: string;
  amount: number;
  interval?: 'day' | 'week' | 'month' | 'year';
  interval_count?: number;
  stripeId: string;
  productId: string;
  product?: Product;
}
