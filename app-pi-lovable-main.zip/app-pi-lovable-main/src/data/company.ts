export type CompanyType = {
  id: string;
  name: string;
  imageUrl: string;
};
