import { Subscription } from './subscription';

export interface User {
  id: string;
  client: {
    id: string;
    name: string;
  };
  firstName: string;
  lastName?: string;
  email: string;
  latitude: number | null;
  longitude: number | null;
  timezone: string | null;
  note: string | null;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
  subscriptions: Array<Subscription>;
  isFree: boolean;
  metadata?: {
    resume?: { url: string; filename: string; uploaded_at: string };
    jobSearch?: string;
    joinedWaitlist?: boolean;
  };
  role: {
    id: string;
    permissions: Array<string>;
  };
  trialExpiresAt: string;
}
