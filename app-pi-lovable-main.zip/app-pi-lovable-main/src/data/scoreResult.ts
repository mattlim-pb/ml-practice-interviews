export type ScoreResult = {
  assumptions?: number;
  clarify?: number;
  framework?: number;
  solution?: number;
  situationAndTask?: number;
  actions?: number;
  results?: number;
  total?: number;
};
