export interface Promo {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  expires: string;
  createdAt: string;
}
