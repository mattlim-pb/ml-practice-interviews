declare module '*.ttf' {
  const src: string;
  export default src;
}
declare module '*.png';
declare module '*.json';
