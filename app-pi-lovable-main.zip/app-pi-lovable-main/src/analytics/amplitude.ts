import * as amplitude from '@amplitude/analytics-browser';
import { isLocalhost } from '../utils/env';

if (!isLocalhost()) {
  amplitude.init('971791c6a5e4d511de5501b18076ebf0', {
    defaultTracking: true,
  });
}
