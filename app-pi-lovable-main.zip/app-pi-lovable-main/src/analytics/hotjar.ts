import { hotjar } from 'react-hotjar';
import { isProduction } from '../utils/env';

const hjid = 3782607;
const hjsv = 6;

if (isProduction()) {
  hotjar.initialize(hjid, hjsv);
}
