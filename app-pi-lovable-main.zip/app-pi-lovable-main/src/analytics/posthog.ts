import posthog from 'posthog-js';

const apiKey = process.env.REACT_APP_POSTHOG_PROJECT_API_KEY || '';

posthog.init(apiKey, {
  api_host: 'https://us.i.posthog.com',
});

export default posthog;
