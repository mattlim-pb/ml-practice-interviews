import { useMutation } from 'react-query'; // Ensure this is the correct import for your React Query version
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

export function useDeleteAccount() {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 2,
    })
  );

  return useMutation(async () => {
    const response = await client.get('/deleteAccount');
    return response.data;
  });
}
