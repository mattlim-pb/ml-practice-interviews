import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilState, useRecoilValue } from 'recoil';
import { clientState, userState } from '../states/auth';

interface Params {
  firstName: string;
  appName: 'PracticeInterviews';
}

export function useUpdateAccount(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );
  const [user, setUser] = useRecoilState(userState);

  return useMutation<unknown, AxiosError, Params>(
    variables =>
      client.patch(`/users/${user?.id}`, { ...variables, email: user?.email }),
    {
      ...options,
      onSuccess(res: any) {
        setUser(res.data?.data);
      },
    }
  );
}
