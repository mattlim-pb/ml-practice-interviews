import { AxiosError } from 'axios';
import { useCallback, useMemo } from 'react';
import { UseMutationOptions, useMutation } from 'react-query';
import { useRecoilValue } from 'recoil';
import { AnswerFeedback } from '../data/answerFeedback';
import useOnInitialMount from '../hooks/useOnInitialMount';
import { clientState } from '../states/auth';

interface Params {}

export function useFetchFeedback(
  options?: UseMutationOptions<
    { data: { success: boolean; data: Array<AnswerFeedback> } },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 1,
    })
  );

  return useMutation<
    { data: { success: boolean; data: Array<AnswerFeedback> } },
    AxiosError,
    Params
  >(() => client.get('/answers'), {
    ...options,
  });
}

export function useAnswerFeedback(willFetchOnMount: boolean) {
  const fetchFeedback = useFetchFeedback();

  useOnInitialMount(() => {
    if (willFetchOnMount) {
      fetchFeedback.mutate({});
    }
  });

  const feedbackCount = useMemo(() => {
    return fetchFeedback.data?.data.data.length ?? 0;
  }, [fetchFeedback.data]);

  const feedbacks = useMemo(() => {
    return fetchFeedback.data?.data.data ?? [];
  }, [fetchFeedback.data]);

  const refetch = useCallback(() => {
    fetchFeedback.mutate({});
  }, [fetchFeedback]);

  return {
    feedbackCount,
    feedbacks,
    refetch,
    isLoading: fetchFeedback.isLoading,
  };
}
