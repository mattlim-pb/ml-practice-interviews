import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

interface Params {
  returnUrl: string;
}

export function useCreateCustomerPortalSession(
  options?: UseMutationOptions<
    {
      data: {
        data: any;
      };
    },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 2,
    })
  );

  return useMutation<
    {
      data: {
        data: any;
      };
    },
    AxiosError,
    Params
  >(params => client.post(`/users/create-customer-portal-session`, params), {
    ...options,
  });
}
