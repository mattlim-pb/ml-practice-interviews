import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import {
  clientState,
  refreshTokenState,
  tokenState,
  userState,
} from '../states/auth';

interface Params {
  email: string;
  password: string;
  appName: 'PracticeInterviews';
}

export function useSignIn(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );
  const setToken = useSetRecoilState(tokenState);
  const setRefreshToken = useSetRecoilState(refreshTokenState);
  const setUser = useSetRecoilState(userState);

  return useMutation<unknown, AxiosError, Params>(
    variables => client.post('/signIn', variables),
    {
      ...options,
      onSuccess(res: any) {
        if (res.data.data?.user) {
          setToken(res.data.data.token);
          setRefreshToken(res.data.data.refreshToken);
          setUser(res.data.data.user);
        }
      },
    }
  );
}
