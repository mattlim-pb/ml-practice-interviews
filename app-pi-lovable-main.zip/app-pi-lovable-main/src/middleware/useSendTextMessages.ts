import { useCallback, useState } from 'react';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

export function useSendTextMessage() {
  const apiClient = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const sendTextMessage = useCallback(
    async (text: string, useLanguageModel: string = 'gpt-3.5-turbo') => {
      setIsLoading(true);
      const requestBody = {
        text,
        useLanguageModel,
        appName: 'PracticeInterviews',
      };

      try {
        const response = await apiClient.post('/text', requestBody);
        return response.data;
      } catch (error) {
        console.error('Error sending text message:', error);
      }
      setIsLoading(false);
    },
    [apiClient]
  );

  return {
    isLoading,
    sendTextMessage,
  };
}
