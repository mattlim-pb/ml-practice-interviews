import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { Price } from '../data/price';
import { clientState } from '../states/auth';

interface Params {}
export function usePrices(
  options?: UseMutationOptions<
    {
      data: {
        success: boolean;
        data: Array<Price>;
      };
    },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 2,
    })
  );

  return useMutation<
    {
      data: {
        success: boolean;
        data: Array<Price>;
      };
    },
    AxiosError,
    Params
  >(() => client.get(`/prices`), {
    ...options,
  });
}
