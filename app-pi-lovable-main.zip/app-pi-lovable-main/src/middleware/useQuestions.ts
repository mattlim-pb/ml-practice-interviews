import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { CompanyType } from '../data/company';
import { Question, QuestionType } from '../data/question';
import { clientState } from '../states/auth';
import { getGenericType } from '../utils/string';

interface Params {
  jobId: string;
  questionType: QuestionType;
  currentQuestionId: string | null | undefined;
  selectedCompany: CompanyType;
}

export function useQuestions(
  options?: UseMutationOptions<
    { data: { success: boolean; data: Question } },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 1,
    })
  );

  const getNextQuestion = async (params: Params) => {
    const questionType = getGenericType(params.questionType);
    const selectedCompany = params.selectedCompany;

    let url = `/questions/next?`;
    if (params.jobId != null && params.jobId !== '') {
      url += `jobId=${params.jobId}`;
    }
    if (params.currentQuestionId != null) {
      url += `&currentQuestionId=${params.currentQuestionId}`;
    }
    if (questionType != null) {
      url += `&questionType=${questionType}`;
    }
    if (selectedCompany?.id) {
      url += `&companyId=${selectedCompany.id}`;
    }
    return client.get(url);
  };

  return useMutation<
    { data: { success: boolean; data: Question } },
    AxiosError,
    Params
  >(getNextQuestion, {
    ...options,
  });
}
