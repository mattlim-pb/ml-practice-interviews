import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { toast } from 'react-toastify';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

interface Params {
  code: string;
}

export function useGetPromoByCode(
  options?: UseMutationOptions<
    {
      data: any;
    },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 2,
    })
  );

  return useMutation<
    {
      data: any;
    },
    AxiosError,
    Params
  >(params => client.get(`/promos?code=${params.code}`), {
    ...options,
    onError: e => {
      console.error(e);
      toast.error('Invalid promo code');
    },
  });
}
