import { fetchEventSource } from '@microsoft/fetch-event-source';
import { useCallback, useState } from 'react';
import { useRecoilValue } from 'recoil';
import { tokenState } from '../states/auth';
import { getAPIBaseURL } from '../utils/env';

export function useGetIdealAnswer() {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [idealAnswer, setIdealAnswer] = useState<string>('');
  const token = useRecoilValue(tokenState);

  const getIdealAnswer = useCallback(
    async (questionId: string) => {
      try {
        setIsLoading(true);
        const headers: Record<string, string> = {
          Authorization: `Bearer ${token}`,
          Accept: 'text/event-stream',
          'Content-Type': 'application/json',
        };

        await fetchEventSource(
          `${getAPIBaseURL(1)}/questions/${questionId}/idealAnswer`,
          {
            method: 'GET',
            headers,
            async onopen(res) {
              if (res.ok && res.status === 200) {
                setIsLoading(false);
                console.log('Connection made to server');
              } else if (
                res.status >= 400 &&
                res.status < 500 &&
                res.status !== 429
              ) {
                console.error('Client side error ', res);
              }
            },
            onmessage(event) {
              if (event.data && event.data.length > 0) {
                const parsedData = JSON.parse(event.data);
                if (parsedData.chunkedFeedback) {
                  setIdealAnswer(prev => prev + parsedData.chunkedFeedback);
                }
              }
            },
            onclose() {
              console.error('Connection closed by the server');
            },
            onerror(err) {
              console.error('There was an error from server', err);
              setIsLoading(false);
            },
            openWhenHidden: true,
          }
        );
      } catch (e) {
        setIsLoading(false);
      }
    },
    [token]
  );

  return {
    getIdealAnswer,
    isLoading,
    idealAnswer,
  };
}
