import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

interface Params {
  paymentMethodId: string;
}

export function useChangeBillingInfo(
  options?: UseMutationOptions<
    {
      data: {
        data: any;
      };
    },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 2,
    })
  );

  return useMutation<
    {
      data: {
        data: any;
      };
    },
    AxiosError,
    Params
  >(params => client.post(`/users/change-billing-info`, params), {
    ...options,
  });
}
