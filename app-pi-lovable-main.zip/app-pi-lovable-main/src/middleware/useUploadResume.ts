import { AxiosError } from 'axios';
import { UseMutationOptions, useMutation } from 'react-query';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import { clientState, userState } from '../states/auth';

interface Params {
  resume: File;
}

export function useUploadResume(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const setUser = useSetRecoilState(userState);
  const client = useRecoilValue(
    clientState({
      contentType: 'multipart/form-data',
    })
  );

  return useMutation<unknown, AxiosError, Params>(
    variables => {
      const body = new FormData();
      body.append('appName', 'PracticeInterviews');
      body.append('resume', variables.resume);
      return client.post('/users/resume', body);
    },
    {
      ...options,
      onError(error, variables, context) {
        options?.onError?.(error, variables, context);
      },
      onSuccess(res: any) {
        setUser(res.data.data);
      },
    }
  );
}
