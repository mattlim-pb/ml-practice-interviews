import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

interface Params {
  interviewQuestion: string;
}

export function useTextToSpeech(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );

  return useMutation<unknown, AxiosError, Params>(
    variables =>
      client.post(`/textToSpeech`, {
        appName: 'PracticeInterviews',
        text: variables.interviewQuestion,
        streamResponse: false,
      }),
    {
      ...options,
    }
  );
}
