import { fetchEventSource } from '@microsoft/fetch-event-source';
import { useCallback, useRef, useState } from 'react';
import { useRecoilValue } from 'recoil';
import { tokenState } from '../states/auth';
import { getAPIBaseURL } from '../utils/env';

export function useImageFeedback() {
  const [feedback, setFeedback] = useState<string>('');
  const token = useRecoilValue(tokenState);
  const abortControllerRef = useRef<AbortController | null>(null);

  const cancelFeedbackGeneration = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setFeedback('');
  }, []);

  const getImageFeedback = useCallback(
    async (file: File) => {
      // Cancel any ongoing feedback generation
      cancelFeedbackGeneration();

      // Create a new AbortController for this request
      abortControllerRef.current = new AbortController();

      setFeedback('');
      const createFormData = (file: File) => {
        const formData = new FormData();
        formData.append('imageData', file);
        return formData;
      };

      const getHeaders = (token: string): Record<string, string> => ({
        Authorization: `Bearer ${token}`,
        Accept: 'text/event-stream',
      });

      const handleResponse = async (res: Response) => {
        if (!res.ok) {
          if (res.status >= 400 && res.status < 500 && res.status !== 429) {
            throw new Error(`Client error: ${res.status}`);
          }
          throw new Error(`Server error: ${res.status}`);
        }
      };

      const handleMessage = (event: { data: string }) => {
        if (event.data && event.data.length > 0) {
          const parsedData = JSON.parse(event.data);
          if (parsedData.chunkedFeedback) {
            setFeedback(prev => {
              const newFeedback = parsedData.chunkedFeedback || '';
              return prev + newFeedback;
            });
          }
        }
      };

      try {
        await fetchEventSource(`${getAPIBaseURL(1)}/feedback/image`, {
          method: 'POST',
          headers: getHeaders(token),
          body: createFormData(file),
          onopen: handleResponse,
          onmessage: handleMessage,
          onclose: () => console.error('Connection closed by the server'),
          onerror: err => console.error('There was an error from server', err),
          openWhenHidden: true,
          signal: abortControllerRef.current.signal,
        });
      } catch (e: unknown) {
        // Only log error if it's not an abort error
        if (e instanceof Error && e.name !== 'AbortError') {
          console.error('There was an error from server', e);
        }
      }
    },
    [token, cancelFeedbackGeneration]
  );

  return {
    getImageFeedback,
    feedback,
    cancelFeedbackGeneration,
  };
}
