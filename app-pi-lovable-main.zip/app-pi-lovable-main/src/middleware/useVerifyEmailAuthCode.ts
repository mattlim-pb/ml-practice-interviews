import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import {
  clientState,
  refreshTokenState,
  tokenState,
  userState,
} from '../states/auth';

interface Params {
  email: string;
  appName: 'PracticeInterviews';
  code?: string;
  when?: 'auth' | 'forgot';
}

export function useVerifyEmailAuthCode(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );
  const setToken = useSetRecoilState(tokenState);
  const setRefreshToken = useSetRecoilState(refreshTokenState);
  const setUser = useSetRecoilState(userState);

  return useMutation<unknown, AxiosError, Params>(
    variables =>
      client.post('/verifyEmail', {
        ...variables,
        appName: 'PracticeInterviews',
      }),
    {
      ...options,
      onError(error, variables, context) {
        options?.onError?.(error, variables, context);
      },
      onSuccess(res: any) {
        setToken(res.data.data.token);
        setRefreshToken(res.data.data.refreshToken);
        setUser(res.data.data.user);
      },
    }
  );
}
