import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import { clientState } from '../states/auth';
import { threadState } from '../states/recording';

interface Params {
  title: string;
}

export function useCreateThread(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );
  const setThreadUUID = useSetRecoilState(threadState);

  return useMutation<unknown, AxiosError, Params>(
    variables => client.post('/threads', variables),
    {
      ...options,
      onSuccess(res: any) {
        setThreadUUID(res.data.id);
      },
    }
  );
}
