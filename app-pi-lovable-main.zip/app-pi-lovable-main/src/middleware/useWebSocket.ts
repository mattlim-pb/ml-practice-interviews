import { useEffect } from 'react';
import { useRecoilValue } from 'recoil';
import { io } from 'socket.io-client';
import { tokenState } from '../states/auth';
import { getSocketBaseURL } from '../utils/env';

export function useWebSocket(
  onSocketMessage: (data: any) => void,
  onSocketError: (data: any) => void
) {
  const token = useRecoilValue(tokenState);

  useEffect(() => {
    const socketURL = getSocketBaseURL();

    const socket = io(socketURL, {
      secure: true,
      auth: { token: `Bearer ${token}` },
    });

    socket.on('connect', () => {
      console.log('🔌 Connected to server');
    });

    socket.on('socketMessage', onSocketMessage);

    socket.on('socketError', onSocketError);

    socket.on('disconnect', () => {
      console.log('🔌 Disconnected from server');
    });

    return () => {
      socket.disconnect();
    };
  }, [onSocketMessage, onSocketError, token]);
}
