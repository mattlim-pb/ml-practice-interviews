import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

type AnalyticsPair = Record<string, number>;

export type QuestionsAttempted = {
  [key: string]: number | string;
};

interface Params {
  filter: {
    dateRange: Array<any>;
  };
}

export type AverageScore = {
  behavioral?: {
    everyone: number;
    you: number;
  };
  hypothetical?: {
    everyone: number;
    you: number;
  };
};

export type PerformerType = {
  averageScore: number;
  username: string;
  rank: number;
  questionsAttempted: number;
  isCurrentUser: boolean;
};
interface Analytics {
  overall: Array<AnalyticsPair>;
  behavioral: Array<AnalyticsPair>;
  hypothetical: Array<AnalyticsPair>;
  averageScore: AverageScore;
  questionsAttempted: QuestionsAttempted;
  leaderboard: PerformerType[];
}

interface SimpleAnalytics {
  questionsAttempted: string;
  averageScore: string;
  rank: string;
}

export function useSimpleAnalytics(
  options?: UseMutationOptions<
    {
      data: {
        data: SimpleAnalytics;
      };
    },
    AxiosError
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 1,
    })
  );

  return useMutation<
    {
      data: {
        data: SimpleAnalytics;
      };
    },
    AxiosError
  >(() => client.get(`/analytics/simple`), {
    ...options,
  });
}

export function useAnalytics(
  options?: UseMutationOptions<
    {
      data: {
        data: Analytics;
      };
    },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 1,
    })
  );

  return useMutation<
    {
      data: {
        data: Analytics;
      };
    },
    AxiosError,
    Params
  >(params => client.post(`/analytics`, params), {
    ...options,
  });
}
