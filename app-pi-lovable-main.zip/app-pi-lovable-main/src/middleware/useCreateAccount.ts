import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilState, useRecoilValue } from 'recoil';
import { affiliateSourceState, clientState } from '../states/auth';

interface Params {
  email: string;
  password: string;
  firstName: string;
  appName: 'PracticeInterviews';
}

export function useCreateAccount(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const [affiliateSource, setAffiliateSource] =
    useRecoilState(affiliateSourceState);
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );

  return useMutation<unknown, AxiosError, Params>(
    variables =>
      client.post(
        '/registerAccount',
        affiliateSource != null
          ? {
              ...variables,
              source: affiliateSource,
            }
          : variables
      ),
    {
      ...options,
      onSuccess() {
        setAffiliateSource(null);
      },
    }
  );
}
