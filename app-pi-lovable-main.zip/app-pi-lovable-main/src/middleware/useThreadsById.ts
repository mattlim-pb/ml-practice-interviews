import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { AnswerFeedback } from '../data/answerFeedback';
import { clientState } from '../states/auth';

interface Params {
  threadId: string;
}

export function useThreadsById(
  options?: UseMutationOptions<
    {
      data: { practiceAttempts: Array<AnswerFeedback> };
    },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );

  return useMutation<
    { data: { practiceAttempts: Array<AnswerFeedback> } },
    AxiosError,
    Params
  >(variables => client.get(`/threads/${variables.threadId}/summary`), {
    ...options,
  });
}
