import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

interface Params {}

export function useCancelSubscription(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 2,
    })
  );

  return useMutation<unknown, AxiosError, Params>(
    () => client.get(`/users/cancel-subscription`),
    {
      ...options,
    }
  );
}
