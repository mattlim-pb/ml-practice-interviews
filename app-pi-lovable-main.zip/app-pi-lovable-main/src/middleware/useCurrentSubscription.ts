import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

interface Params {}

export function useCurrentSubscription(
  options?: UseMutationOptions<
    {
      data: {
        data: {
          subscription: any;
          oneOffPayment: any;
        };
      };
    },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 2,
    })
  );

  return useMutation<
    {
      data: {
        data: any;
      };
    },
    AxiosError,
    Params
  >(() => client.get(`/users/get-current-subscription`), {
    ...options,
  });
}
