import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

interface Params {
  isPositive: boolean;
  messageId: string;
  comment?: string;
}

export function useSubmitFeedback(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );

  return useMutation<unknown, AxiosError, Params>(
    variables => client.post('/feedbacks', variables),
    {
      ...options,
      onSuccess(res: any) {
        console.log(res);
      },
      onError(error: Error) {
        console.error(error.message);
      },
    }
  );
}
