import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

interface Params {
  email: string;
  appName: 'PracticeInterviews';
}

export function useVerifyEmail(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );

  return useMutation<unknown, AxiosError, Params>(
    variables =>
      client.post('/enterEmail', {
        ...variables,
        appName: 'PracticeInterviews',
      }),
    {
      ...options,
      onError(error, variables, context) {
        options?.onError?.(error, variables, context);
      },
    }
  );
}
