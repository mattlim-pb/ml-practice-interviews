import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import { clientState, userState } from '../states/auth';

interface Params {}

export function useDeleteResume(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const setUser = useSetRecoilState(userState);

  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );

  return useMutation<unknown, AxiosError, Params>(
    () => client.delete(`/users/resume`),
    {
      ...options,
      onSuccess(res: any) {
        setUser(res.data.data);
      },
      onError(error: Error) {
        console.error(error.message);
      },
    }
  );
}
