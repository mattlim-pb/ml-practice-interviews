import { useMutation } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

export function useGetNotionPage() {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 1,
    })
  );

  return useMutation((pageId: string) => client.get(`/notion/${pageId}`));
}
