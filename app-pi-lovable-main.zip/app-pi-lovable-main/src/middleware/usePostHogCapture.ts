import { usePostHog } from 'posthog-js/react';
import { useCallback, useEffect, useRef } from 'react';
import { User } from '../data/user';

export function usePosthogCapture() {
  const posthog = usePostHog();
  const timeoutRef = useRef<NodeJS.Timeout>(null);

  const captureEvent = useCallback(
    (
      event: {
        name: string;
        params: {
          [key: string]: any;
        };
      },
      user?: User
    ) => {
      if (user) {
        posthog?.identify(user.id, {
          email: user.email,
          name: `${user.firstName} ${user.lastName} `,
        });
      }
      timeoutRef.current = setTimeout(() => {
        posthog?.capture(event.name, event.params);
      }, 100);
    },
    [posthog]
  );

  useEffect(() => {
    return () => {
      timeoutRef.current && clearTimeout(timeoutRef.current);
    };
  }, []);

  return { captureEvent };
}
