import { AxiosError } from 'axios';
import { useQuery } from 'react-query';
import { useRecoilValue } from 'recoil';
import { clientState } from '../states/auth';

export function useCompanies() {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 1,
    })
  );

  return useQuery<{ data: any; success: boolean }, AxiosError>(
    ['/companies'],
    async () => {
      const response = await client.get('/companies');
      return response.data;
    }
  );
}
