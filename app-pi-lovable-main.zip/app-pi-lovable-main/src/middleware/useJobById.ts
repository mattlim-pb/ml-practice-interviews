import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue } from 'recoil';
import { Job } from '../data/job';
import { clientState } from '../states/auth';

interface Params {
  id: string;
}

export function useJobById(
  options?: UseMutationOptions<
    { data: { success: boolean; data: Job } },
    AxiosError,
    Params
  >
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
      apiVersion: 1,
    })
  );

  return useMutation<
    { data: { success: boolean; data: Job } },
    AxiosError,
    Params
  >(params => client.get(`/jobs/${params.id}`), {
    ...options,
  });
}
