import { AxiosError } from 'axios';
import { useMutation, UseMutationOptions } from 'react-query';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import {
  clientState,
  refreshTokenState,
  tokenState,
  userState,
} from '../states/auth';

interface Params {
  email: string;
  password: string;
}

export function useUpdatePassword(
  options?: UseMutationOptions<unknown, AxiosError, Params>
) {
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );
  const setToken = useSetRecoilState(tokenState);
  const setRefreshToken = useSetRecoilState(refreshTokenState);
  const setUser = useSetRecoilState(userState);

  return useMutation<unknown, AxiosError, Params>(
    variables =>
      client.post('/updatePassword', {
        ...variables,
        appName: 'PracticeInterviews',
      }),
    {
      ...options,
      onSuccess: (res: any) => {
        console.log(res);
        if (res.data.data?.user) {
          setToken(res.data.data.token);
          setRefreshToken(res.data.data.refreshToken);
          setUser(res.data.data.user);
        }
      },
    }
  );
}
