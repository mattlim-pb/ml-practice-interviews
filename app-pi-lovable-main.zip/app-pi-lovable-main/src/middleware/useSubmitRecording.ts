import { fetchEventSource } from '@microsoft/fetch-event-source';
import { useCallback, useState } from 'react';
import { useRecoilValue } from 'recoil';

import { Message } from '../data/message';
import { ScoreResult } from '../data/scoreResult';
import { tokenState } from '../states/auth';

import { NetworkStatus } from '../data/networkStatus';
import { ModularFeedbacksType } from '../states/modularFeedbacks';
import { ScoresType } from '../states/score';
import { getAPIBaseURL, isSafari } from '../utils/env';

interface Params {
  threadId: string;
  jobId: string;
  questionId: string;
  interviewAnswer?: string;
  type: 'text' | 'audio' | 'video';
  file?: Blob;
}

export function useSubmitRecording() {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [transcription, setTranscription] = useState<string>('');
  const [feedback, setFeedback] = useState<string>('');
  const [message, setMessage] = useState<Message | null>(null);
  const [scores, setScores] = useState<ScoreResult | null>(null);
  const [s3Url, setS3Url] = useState<string | null>(null);
  const [modularFeedbacks, setModularFeedbacks] =
    useState<ModularFeedbacksType>({});
  const token = useRecoilValue(tokenState);

  const getAnswerById = useCallback(
    async (answerId: string) => {
      setIsLoading(true);
      try {
        const res = await fetch(`${getAPIBaseURL(1)}/answers/${answerId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const { data } = await res.json();
        try {
          const { modularFeedbacks, feedback, score, answer } = data;
          const scores = modularFeedbacks?.scores;
          const modularFeedbacksData = !!Object.keys(
            data?.modularFeedbacks ?? {}
          ).length;

          if (scores) {
            setScores(scores);
          } else if (score) {
            //Old score data
            setScores({
              total: score,
            });
          }

          if (modularFeedbacksData) {
            setModularFeedbacks(modularFeedbacks);
          } else {
            //Old feedback data
            setFeedback(feedback);
          }
          setTranscription(answer);
          if (data?.videoUrl) {
            setS3Url(data?.videoUrl);
          } else if (data?.audioUrl) {
            setS3Url(data?.audioUrl);
          }
        } catch (error) {
          console.error('❌ Error getting answer by id:', error);
        }
      } catch (error) {
        console.error('❌ Error getting answer by id:', error);
      } finally {
        setIsLoading(false);
      }
    },
    [token]
  );

  const submitRecording = useCallback(
    async ({
      threadId,
      file,
      type,
      interviewAnswer,
      questionId,
      jobId,
    }: Params) => {
      try {
        setIsLoading(true);
        const headers: Record<string, string> = {
          Authorization: `Bearer ${token}`,
          Accept: 'text/event-stream',
          'Content-Type': 'application/json',
        };

        let body = null;
        if (type === 'text') {
          const payload: { [key: string]: string | undefined } = {
            interviewAnswer,
            questionId,
            threadId,
          };
          if (jobId && jobId !== '') {
            payload.jobId = jobId;
          }
          body = JSON.stringify(payload);
        } else {
          const formData = new FormData();
          formData.append('threadId', threadId);
          jobId && formData.append('jobId', jobId);
          formData.append('useTranscriptionService', 'deepgram');
          if (type === 'audio') {
            formData.append('audioData', file!, 'audio.wav');
          } else if (type === 'video') {
            formData.append(
              'videoData',
              file!,
              `audio.${isSafari() ? 'webm' : 'mp4'}`
            );
          }
          formData.append('questionId', questionId);

          body = formData;
          delete headers['Content-Type'];
        }
        await fetchEventSource(`${getAPIBaseURL(1)}/answers/${type}`, {
          method: 'POST',
          headers,
          body,
          async onopen(res) {
            if (res.ok && res.status === 200) {
              console.log('Connection made to server');
              setIsLoading(false);
            } else if (
              res.status >= NetworkStatus.BAD_REQUEST &&
              res.status < NetworkStatus.INTERNAL_SERVER_ERROR &&
              res.status !== NetworkStatus.TOO_MANY_REQUESTS
            ) {
              console.error('Client side error ', res);
            }
          },
          onmessage(event) {
            if (event.data && event.data.length > 0) {
              const parsedData = JSON.parse(event.data);
              if (parsedData.interviewAnswer) {
                setTranscription(parsedData.interviewAnswer);
              } else if (parsedData.result) {
                setScores(parsedData.result.nonStreamingFeedback.scores);
              }
              if (parsedData.userMessage) {
                setMessage(parsedData.userMessage);
              }
              if (parsedData.videoUrl) {
                setS3Url(parsedData.videoUrl);
              } else if (parsedData.audioUrl) {
                setS3Url(parsedData.audioUrl);
              }

              const options = [
                'situationAndTask',
                'actions',
                'results',
                'summary',
                'clarify',
                'framework',
                'assumptions',
                'solution',
              ];

              const currentKey = Object.keys(parsedData)?.[0] ?? '';
              if (parsedData.feedback || parsedData.chunkedFeedback) {
                setFeedback(
                  (prev: string) =>
                    prev + (parsedData.chunkedFeedback ?? parsedData.feedback)
                );
              }
              if (options.includes(currentKey)) {
                setModularFeedbacks((prev: ModularFeedbacksType) => {
                  return {
                    ...prev,
                    [currentKey]: parsedData[currentKey],
                  };
                });
              }

              if (
                parsedData?.scores &&
                Object.keys(parsedData?.scores).length > 0
              ) {
                setScores((prev: ScoresType) => {
                  return {
                    ...prev,
                    ...parsedData?.scores,
                  };
                });
              }
            }
          },
          onclose() {
            console.error('Connection closed by the server');
          },
          onerror(err) {
            console.error('There was an error from server', err);
          },
          openWhenHidden: true,
        });
      } catch (error) {
        console.error('❌ Error uploading audio file:', error);
        setIsLoading(false);
      }
    },
    [setTranscription, setIsLoading, setFeedback, setMessage, token]
  );

  return {
    getAnswerById,
    submitRecording,
    transcription,
    feedback,
    message,
    isLoading,
    scores,
    s3Url,
    modularFeedbacks,
  };
}
