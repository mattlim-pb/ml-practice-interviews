import { atom } from 'recoil';

export type AnswerAnalysisType = {
  feedback?: string;
  transcription?: string;
  s3Url?: string;
} | null;

export const answerAnalysisState = atom<AnswerAnalysisType>({
  key: 'answerAnalysis',
  default: null,
});
