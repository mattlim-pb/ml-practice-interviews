import { Button, Grid, Paper, SxProps, Theme, Typography } from '@mui/material';
import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '../../components/MainLayout';
import { useCreateUserAction } from '../../middleware/useCreateUserAction';
import { APP_PATHS } from '../../routes/paths';

export default function OnboardingResultPage() {
  const createUserAction = useCreateUserAction();
  const navigate = useNavigate();

  const finishOnboarding = useCallback(() => {
    createUserAction.mutate({ actionName: 'onboardingComplete' });
    navigate(APP_PATHS.home);
  }, [navigate, createUserAction]);

  return (
    <MainLayout
      showHeaderButtons={false}
      showSubscriptionBanner={false}
      hideMenu={true}
    >
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        sx={styles.container}
      >
        <Grid item xs={12} sm={10} xl={8} sx={{ m: "auto" }}>
          <Paper
            sx={{
              backgroundColor: "#F2F2F2",
              textAlign: "center",
              p: 4,
            }}
          >
            <Typography variant="h6" sx={{ mb: 4 }}>
              <b>Practice Interviews AI</b> will provide the most accurate and
              actionable feedback of any tool on the market.
            </Typography>
            <Button variant="contained" onClick={finishOnboarding}>
              Start practicing now!
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  container: {
    padding: 4,
    minHeight: 'calc(100vh - 136px)',
  },
};
