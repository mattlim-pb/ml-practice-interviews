import { Box, Grid, Typography } from '@mui/material';
import { CSSProperties } from 'react';
import { useNavigate } from 'react-router-dom';
import OnboardingImage from '../../assets/images/onboarding2.png';
import { MainLayout } from '../../components/MainLayout';
import { PIStepper } from '../../components/PIStepper';
import { APP_PATHS } from '../../routes/paths';

export default function OnboardingFeedbackPage() {
  const navigate = useNavigate();

  return (
    <MainLayout
      showHeaderButtons={false}
      showSubscriptionBanner={false}
      hideMenu={true}
    >
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        sx={styles.container}
      >
        <Grid item xs={12} sm={10} xl={8}>
          <Typography variant="h6" textAlign="center">
            Get actionable feedback on your responses
          </Typography>
          <Grid container justifyContent="center" alignItems="center">
            <Grid item xs={12} sm={10} xl={8}>
              <img
                src={OnboardingImage}
                alt="onboarding"
                style={styles.image}
              />
            </Grid>
          </Grid>

          <Box sx={{ position: 'absolute', bottom: 50, left: 0, right: 0 }}>
            <Grid item xs={12} sm={10} xl={8} sx={{ m: 'auto' }}>
              <PIStepper
                activeStep={2}
                steps={3}
                onBack={() => navigate(APP_PATHS.onboardingJobDescription)}
                onNext={() => navigate(APP_PATHS.onboardingResult)}
              />
            </Grid>
          </Box>
        </Grid>
      </Grid>
    </MainLayout>
  );
}

const styles: { [key: string]: CSSProperties } = {
  container: {
    padding: 4,
    minHeight: 'calc(100vh - 136px)',
  },
  image: {
    marginTop: 40,
    marginBottom: 40,
  },
};
