import {
  Box,
  FormControl,
  FormControlLabel,
  Grid,
  Radio,
  RadioGroup,
  SxProps,
  Theme,
  Typography,
} from '@mui/material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useRecoilValue } from 'recoil';
import { MainLayout } from '../../components/MainLayout';
import { PIStepper } from '../../components/PIStepper';
import { useOnChange } from '../../hooks/useOnChange';
import { useMe } from '../../middleware/useMe';
import { APP_PATHS } from '../../routes/paths';
import { clientState } from '../../states/auth';

const SEARCH_JOB_OPTIONS = [
  {
    value: 'Not Looking',
    label: "I'm not currently searching for a job.",
  },
  {
    value: 'Casually Looking',
    label: "I'm open to opportunities but not actively searching.",
  },
  {
    value: 'Actively Looking',
    label: "I'm actively submitting applications and networking.",
  },
  {
    value: 'Urgently Looking',
    label: "I'm not currently employed and urgently seeking employment.",
  },
];

export default function OnboardingJobSearchPage() {
  const navigate = useNavigate();
  const [selectedOption, setSelectedOption] = useState<number>(-1);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const client = useRecoilValue(
    clientState({
      contentType: 'application/json',
    })
  );
  const { user } = useMe();

  useOnChange({
    value: user?.metadata?.jobSearch,
    defaultValue: null,
    onChange: () => {
      if (user?.metadata?.jobSearch) {
        const index = SEARCH_JOB_OPTIONS.findIndex(
          option => option.value === user.metadata?.jobSearch
        );
        setSelectedOption(index);
      }
    },
  });

  return (
    <MainLayout
      showHeaderButtons={false}
      showSubscriptionBanner={false}
      hideMenu={true}
    >
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        sx={styles.container}
      >
        <Grid item xs={12} sm={10} xl={8} sx={{ m: 'auto' }}>
          <Typography variant="h5" textAlign="center">
            <b>Welcome to Practice Interviews AI!</b>
          </Typography>
          <Typography textAlign="center" sx={{ my: 3 }}>
            Where are you currently in your job search?
          </Typography>
          <FormControl sx={{ my: 4, mb: 10, display: 'flex' }}>
            <RadioGroup
              defaultValue={selectedOption}
              name="radio-buttons-group"
              onChange={e => {
                setSelectedOption(parseInt(e.target.value));
              }}
            >
              {SEARCH_JOB_OPTIONS.map(({ value, label }, index) => (
                <FormControlLabel
                  key={index}
                  value={index}
                  control={<Radio checked={selectedOption === index} />}
                  sx={{
                    p: 1,
                    backgroundColor:
                      selectedOption === index
                        ? 'rgba(189,189,189,0.2)'
                        : 'transparent',
                    borderRadius: 2,
                  }}
                  label={
                    <Typography>
                      <b>{value}</b> - {label}
                    </Typography>
                  }
                />
              ))}
            </RadioGroup>
          </FormControl>

          <Box sx={{ position: 'absolute', bottom: 50, left: 0, right: 0 }}>
            <Grid item xs={12} sm={10} xl={8} sx={{ m: 'auto' }}>
              <PIStepper
                activeStep={0}
                steps={3}
                onNext={async () => {
                  setIsLoading(true);
                  await client.patch(`/users/${user?.id ?? ''}`, {
                    metadata: {
                      jobSearch: SEARCH_JOB_OPTIONS[selectedOption].value,
                    },
                  });
                  setIsLoading(false);
                  navigate(APP_PATHS.onboardingJobDescription);
                }}
                nextButtonDisabled={selectedOption === -1 || isLoading}
                isLoading={isLoading}
              />
            </Grid>
          </Box>
        </Grid>
      </Grid>
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  container: {
    padding: 4,
    minHeight: 'calc(100vh - 136px)',
  },
};
