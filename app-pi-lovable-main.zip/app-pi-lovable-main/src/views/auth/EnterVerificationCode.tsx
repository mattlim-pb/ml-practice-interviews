import * as amplitude from '@amplitude/analytics-browser';
import VpnKeyIcon from '@mui/icons-material/VpnKey';
import {
  Box,
  Button,
  CircularProgress,
  Grid,
  InputAdornment,
  TextField,
  Typography,
} from '@mui/material';
import { useCallback, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import LogoImage from '../../assets/images/logo.png';
import { useExpirationTimer } from '../../hooks/useExpirationTimer';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useGetUserAction } from '../../middleware/useGetUserAction';
import { useSendVerificationEmail } from '../../middleware/useSendVerificationEmail';
import { useVerifyEmailAuthCode } from '../../middleware/useVerifyEmailAuthCode';
import { APP_PATHS } from '../../routes/paths';

export default function EnterVerificationCode() {
  const location = useLocation();
  const navigate = useNavigate();
  const { email, onComplete } = location.state;
  const verifyEmailAuthCode = useVerifyEmailAuthCode();
  const sendVerificationEmail = useSendVerificationEmail();
  const getUserAction = useGetUserAction();

  const {
    start: startExpirationTimer,
    isExpired,
    secondsLeft,
  } = useExpirationTimer({
    key: 'resend_auth_code',
  });

  const [verificationCode, setVerificationCode] = useState<string>('');
  const verificationCodeRef = useRef<HTMLInputElement>(null);

  const handleSubmit = useCallback(() => {
    verifyEmailAuthCode.mutate({
      email,
      code: verificationCode,
      when: 'auth',
      appName: 'PracticeInterviews',
    });
  }, [verifyEmailAuthCode, email, verificationCode]);

  const resendVerificationCode = useCallback(() => {
    startExpirationTimer();
    sendVerificationEmail.mutate({ email });
  }, [sendVerificationEmail, email, startExpirationTimer]);

  useOnChange({
    value: {
      isSuccess: getUserAction.isSuccess,
      isError: getUserAction.isError,
    },
    defaultValue: null,
    onChange: () => {
      if (getUserAction.isSuccess) {
        const isOnboardingCompleted = getUserAction.data.data.isCompleted;
        if (!isOnboardingCompleted) {
          navigate(APP_PATHS.onboardingJobSearch);
        } else {
          navigate(APP_PATHS.home);
        }
      } else if (getUserAction.isError) {
        navigate(APP_PATHS.home);
      }
    },
  });

  useOnChange({
    value: {
      isSuccess: verifyEmailAuthCode.isSuccess,
      isError: verifyEmailAuthCode.isError,
    },
    defaultValue: null,
    onChange: () => {
      if (verifyEmailAuthCode.isSuccess) {
        if (onComplete) {
          onComplete();
        } else {
          getUserAction.mutate({ actionName: 'onboardingComplete' });
        }
      } else if (verifyEmailAuthCode.isError && verifyEmailAuthCode.error) {
        const response = JSON.parse(verifyEmailAuthCode.error.request.response);
        toast.error(response.message);
      }
    },
  });

  useOnInitialMount(() => {
    amplitude.track('Enter Verification Code');
  });

  useOnChange({
    value: sendVerificationEmail.isSuccess,
    defaultValue: false,
    skipDefaultCheck: true,
    onChange: () => {
      toast.success('Verification code was sent successfully');
    },
  });

  return (
    <Grid
      container
      className="h-screen"
      justifyContent="center"
      alignItems="center"
    >
      <Grid item xs={12} sm={4} sx={{ my: 'auto', mx: 2 }}>
        <img src={LogoImage} alt="logo" className="my-4" />

        <TextField
          inputRef={verificationCodeRef}
          id="verification-code"
          label="Verification code"
          variant="outlined"
          fullWidth
          sx={{ my: 4 }}
          value={verificationCode}
          type="text"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <VpnKeyIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setVerificationCode(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              handleSubmit();
            }
          }}
        />

        <Button variant="contained" fullWidth onClick={handleSubmit}>
          Continue
        </Button>

        {sendVerificationEmail.isLoading ? (
          <Box display="flex" justifyContent="center" sx={{ mt: 3 }}>
            <CircularProgress />
          </Box>
        ) : (
          <Button
            variant="text"
            sx={{ textTransform: 'none', color: 'black', mt: 3 }}
            fullWidth
            onClick={resendVerificationCode}
            disabled={!isExpired}
          >
            {isExpired ? (
              <Typography textAlign="center">
                Didn’t receive your code?{' '}
                <b style={{ textDecoration: 'underline' }}>Resend now.</b>
              </Typography>
            ) : (
              <Typography textAlign="center">
                {secondsLeft}s remaining.
              </Typography>
            )}
          </Button>
        )}
      </Grid>
    </Grid>
  );
}
