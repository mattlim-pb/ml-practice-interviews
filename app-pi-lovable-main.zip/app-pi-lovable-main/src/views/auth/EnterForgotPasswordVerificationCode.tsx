import * as amplitude from '@amplitude/analytics-browser';
import VpnKeyIcon from '@mui/icons-material/VpnKey';
import {
  Button,
  Grid,
  InputAdornment,
  TextField,
  Typography,
} from '@mui/material';
import { useCallback, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import LogoImage from '../../assets/images/logo.png';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useVerifyEmailAuthCode } from '../../middleware/useVerifyEmailAuthCode';
import { APP_PATHS } from '../../routes/paths';

export default function EnterForgotPasswordVerificationCode() {
  const location = useLocation();
  const navigate = useNavigate();
  const email = location.state.email;
  const verifyEmailAuthCode = useVerifyEmailAuthCode();

  const [verificationCode, setVerificationCode] = useState<string>('');
  const verificationCodeRef = useRef<HTMLInputElement>(null);

  const handleSubmit = useCallback(() => {
    verifyEmailAuthCode.mutate({
      email,
      code: verificationCode,
      when: 'forgot',
      appName: 'PracticeInterviews',
    });
  }, [verifyEmailAuthCode, email, verificationCode]);

  useOnChange({
    value: {
      isSuccess: verifyEmailAuthCode.isSuccess,
      isError: verifyEmailAuthCode.isError,
    },
    defaultValue: null,
    onChange: () => {
      if (verifyEmailAuthCode.isSuccess) {
        navigate(APP_PATHS.createNewPassword, { state: { email } });
      } else if (verifyEmailAuthCode.isError && verifyEmailAuthCode.error) {
        const response = JSON.parse(verifyEmailAuthCode.error.request.response);
        toast.error(response.message);
      }
    },
  });

  useOnInitialMount(() => {
    amplitude.track('Enter Verification Code');
  });

  return (
    <Grid
      container
      className="h-screen"
      justifyContent="center"
      alignItems="center"
    >
      <Grid item xs={12} sm={4} sx={{ my: 'auto', mx: 2 }}>
        <img src={LogoImage} alt="logo" className="my-4" />

        <Typography>
          Please enter the verification code you've received at <b>{email}</b>{' '}
          to reset your password.
        </Typography>
        <TextField
          inputRef={verificationCodeRef}
          id="verification-code"
          label="Verification code"
          variant="outlined"
          fullWidth
          sx={{ my: 4 }}
          value={verificationCode}
          type="text"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <VpnKeyIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setVerificationCode(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              handleSubmit();
            }
          }}
        />

        <Button variant="contained" fullWidth onClick={handleSubmit}>
          Continue
        </Button>
      </Grid>
    </Grid>
  );
}
