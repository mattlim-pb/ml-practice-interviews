import * as amplitude from '@amplitude/analytics-browser';
import LockIcon from '@mui/icons-material/Lock';
import { Button, Grid, InputAdornment, TextField } from '@mui/material';
import { useCallback, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import LogoImage from '../../assets/images/logo.png';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useUpdatePassword } from '../../middleware/useUpdatePassword';
import { APP_PATHS } from '../../routes/paths';

export default function CreateAccount() {
  const location = useLocation();
  const updatePassword = useUpdatePassword();
  const navigate = useNavigate();

  const newPasswordRef = useRef<HTMLInputElement>(null);

  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');

  const email = location.state.email;

  const handleSubmit = useCallback(() => {
    if (
      email.trim() === '' ||
      password.trim() === '' ||
      confirmPassword.trim() === ''
    ) {
      toast.error('Please fill out all fields to create your account');
      return;
    }

    if (password !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    updatePassword.mutate({
      email,
      password,
    });
  }, [confirmPassword, updatePassword, email, password]);

  useOnChange({
    value: {
      isSuccess: updatePassword.isSuccess,
      isError: updatePassword.isError,
    },
    defaultValue: null,
    onChange: () => {
      try {
        if (updatePassword.isSuccess) {
          navigate(APP_PATHS.home);
        } else if (updatePassword.isError && updatePassword.error) {
          const response = JSON.parse(updatePassword.error.request.response);
          toast.error(response.message);
        }
      } catch (e) {
        console.error(e);
      }
    },
  });

  useOnInitialMount(() => {
    if (newPasswordRef.current) {
      newPasswordRef.current.focus();
    }
    amplitude.track('Create Account');
  });

  return (
    <Grid
      container
      className="h-screen"
      justifyContent="center"
      alignItems="center"
    >
      <Grid item xs={12} sm={4} sx={{ my: 'auto', mx: 2 }}>
        <img src={LogoImage} alt="logo" className="my-4" />

        <TextField
          id="new-password"
          label="Create password"
          variant="outlined"
          fullWidth
          sx={{ mb: 2 }}
          value={password}
          type="password"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LockIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setPassword(e.target.value)}
        />

        <TextField
          id="confirm-password"
          label="Confirm password"
          variant="outlined"
          fullWidth
          sx={{ mb: 2 }}
          value={confirmPassword}
          type="password"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LockIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setConfirmPassword(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              handleSubmit();
            }
          }}
        />

        <Button variant="contained" fullWidth onClick={handleSubmit}>
          Continue
        </Button>
      </Grid>
    </Grid>
  );
}
