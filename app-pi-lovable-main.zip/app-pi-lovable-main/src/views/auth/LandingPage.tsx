import { Button, Grid, SxProps, Theme, Typography } from '@mui/material';

import { useNavigate } from 'react-router-dom';

import AIImage from '../../assets/images/AI.png';
import AmazonImage from '../../assets/images/amazon.png';
import AppleImage from '../../assets/images/apple.png';
import GoogleImage from '../../assets/images/google.png';
import MetaImage from '../../assets/images/meta.png';
import { MainLayout } from '../../components/MainLayout';
import { APP_PATHS } from '../../routes/paths';

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <MainLayout>
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        sx={styles.container}
      >
        <Grid item xs={12} sm={10} xl={8} sx={{ my: 'auto', mx: 2 }}>
          <Grid container justifyContent="center" alignItems="center">
            <Grid item xs={12} md={6}>
              <Typography fontSize={32} gutterBottom>
                <b>Elevate Your Interview Performance with AI</b>
              </Typography>
              <Typography fontSize={16} sx={{ my: 4 }}>
                Boost Your Confidence and Secure Your Dream Job.
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Button
                    fullWidth
                    variant="contained"
                    style={{ textTransform: 'none' }}
                    onClick={() => {
                      navigate(APP_PATHS.enterEmail);
                    }}
                  >
                    Sign up for free!
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    style={{ textTransform: 'none' }}
                    onClick={() => {
                      window.open(
                        'https://www.youtube.com/watch?v=jNBd7WAJnIQ',
                        '_blank'
                      );
                    }}
                  >
                    How does it work?
                  </Button>
                </Grid>
                <Grid item xs={12}>
                  <Typography fontSize={16} color="#999" sx={{ my: 3 }}>
                    Just a few companies that Practice Interview Clients have
                    landed jobs at:
                  </Typography>
                </Grid>
                {[MetaImage, GoogleImage, AppleImage, AmazonImage].map(
                  (src, index) => (
                    <Grid
                      key={index}
                      item
                      xs={3}
                      display="flex"
                      justifyContent="center"
                      alignItems="center"
                    >
                      <img
                        src={src}
                        style={{ maxHeight: 50 }}
                        alt={`logo${index}`}
                      />
                    </Grid>
                  )
                )}
              </Grid>
            </Grid>
            <Grid item xs={12} md={6}>
              <img src={AIImage} alt="ai" />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  container: {
    padding: 4,
    minHeight: 'calc(100vh - 136px)',
  },
};
