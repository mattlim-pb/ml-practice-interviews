import * as amplitude from '@amplitude/analytics-browser';
import LockIcon from '@mui/icons-material/Lock';
import { Button, Grid, InputAdornment, TextField } from '@mui/material';
import { useCallback, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import LogoImage from '../../assets/images/logo.png';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useSendVerificationEmail } from '../../middleware/useSendVerificationEmail';
import { useSignIn } from '../../middleware/useSignIn';
import { APP_PATHS } from '../../routes/paths';

export default function EnterPassword() {
  const location = useLocation();
  const signIn = useSignIn();
  const sendVerificationEmail = useSendVerificationEmail();
  const navigate = useNavigate();

  const [password, setPassword] = useState<string>('');
  const passwordRef = useRef<HTMLInputElement>(null);

  const email = location.state.email;

  const handleSubmit = useCallback(() => {
    signIn.mutate({
      password,
      email,
      appName: 'PracticeInterviews',
    });
  }, [signIn, password, email]);

  const handleForgotPassword = useCallback(() => {
    sendVerificationEmail.mutate({ email });
    navigate(APP_PATHS.enterForgotPasswordVerificationCode, {
      state: { email },
    });
  }, [sendVerificationEmail, email, navigate]);

  useOnInitialMount(() => {
    passwordRef.current?.focus();
  });

  useOnChange({
    value: {
      isSuccess: signIn.isSuccess,
      isError: signIn.isError,
    },
    defaultValue: null,
    onChange: () => {
      if (signIn.isSuccess) {
        const data: any = signIn.data;
        if (data.data.data?.user) {
          navigate(APP_PATHS.home);
        } else {
          toast.success(
            'Verification code has been sent to your email address.'
          );
          navigate(APP_PATHS.enterVerificationCode, { state: { email } });
        }
      } else if (signIn.isError && signIn.error) {
        const response = JSON.parse(signIn.error.request.response);
        toast.error(response.message);
      }
    },
  });

  useOnInitialMount(() => {
    amplitude.track('Enter Password');
  });

  return (
    <Grid
      container
      className="h-screen"
      justifyContent="center"
      alignItems="center"
    >
      <Grid item xs={12} sm={4} sx={{ my: 'auto', mx: 2 }}>
        <img src={LogoImage} alt="logo" className="my-4" />

        <TextField
          inputRef={passwordRef}
          id="outlined-basic"
          label="Password"
          variant="outlined"
          fullWidth
          sx={{ my: 4 }}
          value={password}
          type="password"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LockIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setPassword(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              handleSubmit();
            }
          }}
        />

        <Button variant="contained" fullWidth onClick={handleSubmit}>
          Sign In
        </Button>
        <Button
          variant="text"
          onClick={handleForgotPassword}
          sx={{
            mt: 2,
            color: 'black',
            textTransform: 'none',
            fontWeight: 500,
          }}
        >
          Forgot your password?
        </Button>
      </Grid>
    </Grid>
  );
}
