import * as amplitude from '@amplitude/analytics-browser';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import LockIcon from '@mui/icons-material/Lock';
import {
  Button,
  Grid,
  InputAdornment,
  Link,
  TextField,
  Typography,
} from '@mui/material';
import { useCallback, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import LogoImage from '../../assets/images/logo.png';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useCreateAccount } from '../../middleware/useCreateAccount';
import { APP_PATHS } from '../../routes/paths';

export default function CreateAccount() {
  const location = useLocation();
  const createAccount = useCreateAccount();
  const navigate = useNavigate();

  const [firstName, setFirstName] = useState<string>('');
  const firstNameRef = useRef<HTMLInputElement>(null);

  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');

  const { email } = location.state;

  const handleSubmit = useCallback(() => {
    if (
      firstName.trim() === '' ||
      email.trim() === '' ||
      password.trim() === '' ||
      confirmPassword.trim() === ''
    ) {
      toast.error('Please fill out all fields to create your account');
      return;
    }

    if (password !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    createAccount.mutate({
      email,
      password,
      firstName,
      appName: 'PracticeInterviews',
    });
  }, [confirmPassword, createAccount, email, firstName, password]);

  useOnChange({
    value: {
      isSuccess: createAccount.isSuccess,
      isError: createAccount.isError,
    },
    defaultValue: null,
    onChange: () => {
      try {
        if (createAccount.isSuccess) {
          toast.success(
            'Verification code has been sent to your email address.'
          );
          navigate(APP_PATHS.enterVerificationCode, { state: { email } });
        } else if (createAccount.isError && createAccount.error) {
          const response = JSON.parse(createAccount.error.request.response);
          toast.error(response.message);
        }
      } catch (e) {
        console.error(e);
      }
    },
  });

  useOnInitialMount(() => {
    if (firstNameRef.current) {
      firstNameRef.current.focus();
    }
    amplitude.track('Create Account');
  });

  return (
    <Grid
      container
      className="h-screen"
      justifyContent="center"
      alignItems="center"
    >
      <Grid item xs={12} sm={4} sx={{ my: 'auto', mx: 2 }}>
        <img src={LogoImage} alt="logo" className="my-4" />

        <TextField
          inputRef={firstNameRef}
          id="firstname"
          label="First name"
          variant="outlined"
          fullWidth
          sx={{ mt: 4, mb: 2 }}
          value={firstName}
          autoComplete="off"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <AccountCircleIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setFirstName(e.target.value)}
        />

        <TextField
          id="new-password"
          label="Create password"
          variant="outlined"
          fullWidth
          sx={{ mb: 2 }}
          value={password}
          type="password"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LockIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setPassword(e.target.value)}
        />

        <TextField
          id="confirm-password"
          label="Confirm password"
          variant="outlined"
          fullWidth
          sx={{ mb: 2 }}
          value={confirmPassword}
          type="password"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LockIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setConfirmPassword(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              handleSubmit();
            }
          }}
        />

        <Button variant="contained" fullWidth onClick={handleSubmit}>
          Sign Up
        </Button>

        <Typography
          variant="body2"
          align="center"
          color="text.secondary"
          sx={{ mt: 2 }}
        >
          By signing up you agree to our{' '}
          <Link
            href="https://res.cloudinary.com/oblaka/image/upload/v1742415829/PI/App_-_Terms_Conditions.pdf"
            target="_blank"
            rel="noopener"
          >
            Terms & Conditions
          </Link>{' '}
          and{' '}
          <Link
            href="https://res.cloudinary.com/oblaka/image/upload/v1742415829/PI/App_-_Privacy_Policy.pdf"
            target="_blank"
            rel="noopener"
          >
            Privacy Policy
          </Link>
        </Typography>
      </Grid>
    </Grid>
  );
}
