import * as amplitude from '@amplitude/analytics-browser';
import EmailIcon from '@mui/icons-material/Email';
import { Button, Grid, InputAdornment, TextField } from '@mui/material';
import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

import LogoImage from '../../assets/images/logo.png';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useVerifyEmail } from '../../middleware/useVerifyEmail';
import { APP_PATHS } from '../../routes/paths';
import { validateEmail } from '../../utils/email';

export default function EnterEmail() {
  const navigate = useNavigate();
  const verifyEmail = useVerifyEmail();
  const [email, setEmail] = useState<string>('');

  const handleSubmit = useCallback(() => {
    if (validateEmail(email)) {
      verifyEmail.mutate({ email, appName: 'PracticeInterviews' });
    } else {
      toast.error('Please enter a valid email address');
    }
  }, [email, verifyEmail]);

  useOnChange({
    value: { isSuccess: verifyEmail.isSuccess, isError: verifyEmail.isError },
    defaultValue: null,
    onChange: () => {
      if (verifyEmail.isSuccess) {
        navigate(APP_PATHS.enterPassword, { state: { email } });
      } else if (verifyEmail.isError && verifyEmail.error.status === 404) {
        navigate(APP_PATHS.createAccount, { state: { email } });
      } else if (
        verifyEmail.isError &&
        ((verifyEmail.error.status ?? 0) >= 500 ||
          verifyEmail.error.code === 'ERR_NETWORK')
      ) {
        toast.error('Something went wrong. Please try again later.');
      }
    },
  });

  useOnInitialMount(() => {
    amplitude.track('Enter Email');
  });

  return (
    <Grid
      container
      className="h-screen"
      justifyContent="center"
      alignItems="center"
    >
      <Grid item xs={12} sm={4} sx={{ my: 'auto', mx: 2 }}>
        <img src={LogoImage} alt="logo" className="my-4" />

        <TextField
          id="outlined-basic"
          label="Email address"
          variant="outlined"
          fullWidth
          sx={{ my: 4 }}
          value={email}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <EmailIcon />
              </InputAdornment>
            ),
          }}
          onChange={e => setEmail(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              handleSubmit();
            }
          }}
        />

        <Button variant="contained" fullWidth onClick={handleSubmit}>
          Continue
        </Button>
      </Grid>
    </Grid>
  );
}
