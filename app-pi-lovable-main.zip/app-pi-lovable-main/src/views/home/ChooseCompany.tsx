import { Box, Button, Grid, SxProps, Theme, Typography } from '@mui/material';
import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import CompaniesList from '../../components/CompaniesList';
import { MainLayout } from '../../components/MainLayout';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useJobs } from '../../middleware/useJobs';

export default function ChooseCompanyPage() {
  const getJobs = useJobs();
  const navigate = useNavigate();
  const [selectedCompany, setSelectedCompany] = useState<any>();
  const [companyName, setCompanyName] = useState<string>('');

  const {
    state: { step, stepsAry, selectedJob },
  } = useLocation();

  const currentMenuStep = stepsAry[step] ?? {};

  useOnInitialMount(() => {
    getJobs.mutate({});
  });

  useOnChange({
    value: selectedCompany,
    defaultValue: undefined,
    onChange: () => {
      setCompanyName('');
    },
  });

  useOnChange({
    value: companyName,
    defaultValue: '',
    onChange: () => {
      setSelectedCompany('');
    },
  });

  const footer = (
    <Box display="flex" justifyContent="flex-end" className="px-4 py-2 ">
      <Button
        disabled={!selectedCompany && !companyName}
        variant="contained"
        color="primary"
        style={{ textTransform: 'none' }}
        onClick={() => {
          navigate(stepsAry[step + 1].path, {
            state: {
              step: step + 1,
              selectedJob,
              selectedCompany: selectedCompany ?? { name: companyName },
              stepsAry,
            },
          });
        }}
        className="!rounded-full !normal-case !ml-3"
      >
        Confirm
      </Button>
    </Box>
  );

  return (
    <MainLayout footer={footer}>
      <Grid
        alignItems="center"
        justifyContent="center"
        className={'!py-2 !mb-24'}
      >
        <Grid item xs={12} sm={10}>
          <Box className="flex flex-1 flex-row justify-between my-8 ">
            <Typography
              variant="body1"
              className="!font-bold !text-sm cursor-pointer hover:underline"
              onClick={() => {
                navigate(-1);
              }}
            >
              Back
            </Typography>
            {currentMenuStep?.canSkip && (
              <Typography
                variant="body1"
                className="!font-bold !text-sm cursor-pointer hover:underline"
                onClick={() => {
                  navigate(stepsAry[step + 1].path, {
                    state: {
                      step: step + 1,
                      stepsAry,
                      selectedJob,
                    },
                  });
                }}
              >
                Skip
              </Typography>
            )}
          </Box>
          <Typography variant="h4" fontWeight="bold" sx={styles.title}>
            {`Step ${step + 1}: Choose your company `}
            <span className="font-light">(optional)</span>
          </Typography>
          {/*
            Below code will be used soon...
            <Typography
              variant="h6"
              fontWeight="bold"
              className="!text-lg !my-16"
            >
              Insert the company where you would like to interview?
            </Typography>
            <CompanySearchInput value={companyName} onChange={setCompanyName} /> */}
          <CompaniesList
            disabled={companyName.length > 0}
            setSelectedCompany={setSelectedCompany}
            selectedCompany={selectedCompany}
          />
        </Grid>
      </Grid>
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  title: {
    mt: 4,
    mb: 8,
  },
};
