import CallMadeIcon from '@mui/icons-material/CallMade';
import CheckOutlinedIcon from '@mui/icons-material/CheckOutlined';
import {
  Box,
  Button,
  Container,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
} from '@mui/material';
import moment from 'moment';
import { useCallback, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useRecoilValue } from 'recoil';

import { Loading } from '../../components/Loading';
import { MainLayout } from '../../components/MainLayout';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useThreadsById } from '../../middleware/useThreadsById';
import { APP_PATHS } from '../../routes/paths';
import { threadState } from '../../states/recording';

interface Column {
  id: 'no' | 'question' | 'type' | 'createdAt';
  label: string;
  minWidth?: number;
  align?: 'left' | 'center' | 'right';
  format?: (value: number) => string;
}

const columns: readonly Column[] = [
  { id: 'no', label: 'No', minWidth: 70, align: 'center' },
  { id: 'question', label: 'Question', minWidth: 270 },
  {
    id: 'type',
    label: 'Type',
    minWidth: 100,
    format: (value: number) => value.toLocaleString('en-US'),
  },
  {
    id: 'createdAt',
    label: 'Created At',
    minWidth: 170,
    format: (value: number) => value.toLocaleString('en-US'),
  },
];

export default function Summary() {
  const navigate = useNavigate();

  const threadId = useRecoilValue(threadState);
  const {
    mutate: getThreadsById,
    data: threadsResponse,
    isLoading,
  } = useThreadsById();
  const practiceAttempts = useMemo(() => {
    return threadsResponse?.data?.practiceAttempts ?? [];
  }, [threadsResponse]);

  const [page, setPage] = useState<number>(0);
  const [rowsPerPage, setRowsPerPage] = useState<number>(10);

  const handleChangePage = useCallback(
    (_event: unknown, newPage: number) => {
      setPage(newPage);
    },
    [setPage]
  );

  const handleChangeRowsPerPage = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setRowsPerPage(+event.target.value);
      setPage(0);
    },
    [setPage, setRowsPerPage]
  );

  const onDone = useCallback(() => {
    navigate('/');
  }, [navigate]);

  const showSummaryDetail = useCallback(
    (index: number) => {
      if (practiceAttempts.length > 0) {
        const practice = practiceAttempts[index];
        navigate(APP_PATHS.feedback, {
          state: {
            interviewQuestion: practice.question,
            transcription: practice.answer,
            feedback: practice.feedback,
            type: practice.question.questionType,
            screenType: 'summary-detail',
            scoreResult: practice.scoreDetail,
          },
        });
      }
    },
    [navigate, practiceAttempts]
  );

  const rows = useMemo(() => {
    return practiceAttempts.map((attempt, index) => {
      return {
        no: index + 1,
        question: attempt.question.text,
        type:
          attempt.question.questionType === 'hypothetical'
            ? 'Hypothetical'
            : 'Behavioral',
        createdAt: moment(attempt.createdAt).format('hh:mm A, DD MMM'),
      };
    });
  }, [practiceAttempts]);

  useOnInitialMount(() => {
    getThreadsById({ threadId });
  });

  return isLoading ? (
    <Loading title="Loading threads in this session..." />
  ) : (
    <MainLayout
      footer={
        <Box display="flex" justifyContent="flex-end" my={2}>
          <Button
            variant="outlined"
            color="primary"
            onClick={onDone}
            startIcon={<CheckOutlinedIcon />}
            sx={styles.doneButton}
            className="!rounded-full !normal-case"
          >
            I'm done reviewing my session
          </Button>
        </Box>
      }
    >
      <Container component="main" maxWidth="lg" sx={styles.container}>
        <Typography variant="h4" gutterBottom>
          Summary
        </Typography>

        <Paper sx={styles.paper}>
          <TableContainer sx={styles.tableContainer}>
            <Table stickyHeader aria-label="sticky table">
              <TableHead>
                <TableRow>
                  {columns.map(column => (
                    <TableCell
                      key={column.id}
                      align={column.align}
                      style={{ minWidth: column.minWidth }}
                    >
                      {column.label}
                    </TableCell>
                  ))}
                  <TableCell key="nav" align="center" />
                </TableRow>
              </TableHead>
              <TableBody>
                {rows
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((row, index) => {
                    return (
                      <TableRow
                        hover
                        role="checkbox"
                        tabIndex={-1}
                        key={row.no}
                      >
                        {columns.map(column => {
                          const value = row[column.id];
                          return (
                            <TableCell key={column.id} align={column.align}>
                              {column.format && typeof value === 'number'
                                ? column.format(value)
                                : value}
                            </TableCell>
                          );
                        })}
                        <TableCell key="nav">
                          <IconButton
                            onClick={() =>
                              showSummaryDetail(page * rowsPerPage + index)
                            }
                          >
                            <CallMadeIcon color="action" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[10, 25, 100]}
            component="div"
            count={rows.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      </Container>
    </MainLayout>
  );
}

const styles: { [key: string]: any } = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'top',
    px: 3,
    paddingTop: 4,
  },
  doneButton: {
    height: 40,
  },
  paper: {
    borderWidth: 20,
    borderColor: '#F5F5F5',
    borderRadius: 5,
    overflow: 'hidden',
    width: '100%',
  },
  tableContainer: {
    maxHeight: 440,
  },
};
