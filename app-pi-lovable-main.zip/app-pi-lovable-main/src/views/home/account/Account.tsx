import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import EmailIcon from '@mui/icons-material/Email';
import {
  Button,
  Divider,
  Grid,
  InputAdornment,
  SxProps,
  TextField,
  Theme,
  Typography,
  useTheme,
} from '@mui/material';
import { useFeatureFlagVariantKey } from 'posthog-js/react';
import { useCallback, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useRecoilState, useSetRecoilState } from 'recoil';
import { MainLayout } from '../../../components/MainLayout';
import PIDialog from '../../../components/PIDialog';
import { Subscription } from '../../../components/Subscription';
import { Constants } from '../../../data/constants';
import { useOnChange } from '../../../hooks/useOnChange';
import { useDeleteAccount } from '../../../middleware/useDeleteAccount';
import { usePosthogCapture } from '../../../middleware/usePostHogCapture';
import { useUpdateAccount } from '../../../middleware/useUpdateAccount';
import { refreshTokenState, tokenState, userState } from '../../../states/auth';
import { Resume } from './Resume';

export default function Account() {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const checkoutSessionId = queryParams.get('session_id');
  const { captureEvent } = usePosthogCapture();
  const trialDaysFlagValue = useFeatureFlagVariantKey(
    Constants.POSTHOG_FEATURE_FLAG.trialDays
  );
  const subscriptionPricingFlagValue = useFeatureFlagVariantKey(
    Constants.POSTHOG_FEATURE_FLAG.trialDays
  );
  const theme = useTheme();
  const updateAccount = useUpdateAccount();

  const setToken = useSetRecoilState(tokenState);
  const [user, setUser] = useRecoilState(userState);
  const setRefreshToken = useSetRecoilState(refreshTokenState);

  const [firstName, setFirstName] = useState<string>(user?.firstName ?? '');
  const [email, setEmail] = useState<string>(user?.email ?? '');
  const [logoutDialogDismissed, setLogoutDialogDismissed] =
    useState<boolean>(true);
  const [changeEmailDialogDismissed, setChangeEmailDialogDismissed] =
    useState<boolean>(true);
  const [deleteAccountDialogDismissed, setDeleteAccountDialogDismissed] =
    useState<boolean>(true);
  const [confirmEmail, setConfirmEmail] = useState<string>('');

  const { mutate: deleteAccountMutation, isLoading: isDeleting } =
    useDeleteAccount();

  const save = useCallback(() => {
    updateAccount.mutate({
      firstName: firstName,
      appName: 'PracticeInterviews',
    });
  }, [updateAccount, firstName]);

  const changeEmail = useCallback(() => {
    console.info('change email');
  }, []);

  const logout = useCallback(() => {
    setToken('');
    setRefreshToken('');
    setUser(null);
  }, [setToken, setRefreshToken, setUser]);

  const deleteAccount = useCallback(() => {
    if (confirmEmail === user?.email) {
      deleteAccountMutation(undefined, {
        onSuccess: () => {
          toast.success('Your account has been successfully deleted.');
          logout();
        },
        onError: (error: unknown) => {
          console.error('Failed to delete account:', error);
          toast.error('Failed to delete account. Please try again.');
        },
      });
    }
  }, [confirmEmail, user, deleteAccountMutation, logout]);

  useOnChange({
    value: user,
    defaultValue: null,
    onChange: () => {
      if (user?.id) {
        captureEvent(
          {
            name: checkoutSessionId
              ? 'subscription-completed'
              : 'subscription-page-visited',
            params: {
              'trial-days-flag':
                trialDaysFlagValue === '3' ? 'enabled' : 'disabled',
              'subscription-pricing-flag':
                subscriptionPricingFlagValue === '27' ? 'enabled' : 'disabled',
            },
          },
          user
        );
      }
    },
  });

  useOnChange({
    value: {
      isSuccess: updateAccount.isSuccess,
      isError: updateAccount.isError,
    },
    defaultValue: null,
    onChange: () => {
      if (updateAccount.isSuccess) {
        toast.success(
          'Your account information has been successfully updated.'
        );
      } else if (updateAccount.isError) {
        toast.error(
          'Apologies, but there seems to be an issue while updating the account information.'
        );
      }
    },
  });

  let dialogTitle = '';
  let dialogDescription = null;
  let dialogButtons: {
    text: string;
    color: string;
    onPress: () => void;
    disabled?: boolean;
    sx?: SxProps<Theme>;
  }[] = [];

  if (!logoutDialogDismissed) {
    dialogTitle = 'Sign out';
    dialogDescription = 'Are you sure you want to sign out?';
    dialogButtons = [
      {
        text: 'Cancel',
        color: theme.palette.grey.A700,
        onPress: () => setLogoutDialogDismissed(true),
      },
      {
        text: 'Sign out',
        color: theme.palette.error.main,
        onPress: logout,
      },
    ];
  } else if (!changeEmailDialogDismissed) {
    dialogTitle = 'Change email';
    dialogDescription = (
      <span>
        Are you sure you want to change your email from <b>{user?.email}</b> to{' '}
        <b>{email}</b>
      </span>
    );
    dialogButtons = [
      {
        text: 'Cancel',
        color: theme.palette.grey.A700,
        onPress: () => setChangeEmailDialogDismissed(true),
      },
      {
        text: 'Change',
        color: theme.palette.error.main,
        onPress: changeEmail,
      },
    ];
  } else if (!deleteAccountDialogDismissed) {
    dialogTitle = 'Delete account';
    dialogDescription = (
      <div>
        <Typography>
          Are you sure you want to delete your account? This action will erase
          all data, including all saved answers, feedback, job descriptions.
          This action cannot be undone. Type your email below and hit confirm to
          proceed.
        </Typography>
        <TextField
          label="Type your email to confirm"
          variant="outlined"
          fullWidth
          value={confirmEmail}
          onChange={e => setConfirmEmail(e.target.value)}
          sx={{ mt: 2 }}
        />
      </div>
    );
    dialogButtons = [
      {
        text: 'Cancel',
        color: theme.palette.grey.A700,
        onPress: () => setDeleteAccountDialogDismissed(true),
      },
      {
        text: 'Delete account',
        color: theme.palette.error.main,
        onPress: deleteAccount,
        disabled: confirmEmail !== user?.email || isDeleting, // Disable if email doesn't match or deletion is in progress
        sx: {
          '&.Mui-disabled': {
            backgroundColor: '#616161',
            color: '#e0e0e0',
          },
        },
      },
    ];
  }

  return (
    <MainLayout>
      <Grid
        container
        justifyContent="center"
        alignItems="top"
        sx={styles.container}
      >
        <Grid item xs={10} sm={8} md={6}>
          <Typography variant="h5" gutterBottom>
            <b>Account</b>
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <TextField
                id="firstname"
                label="First name"
                variant="outlined"
                sx={{ mt: 4, mb: 2, minWidth: '100%' }}
                value={firstName}
                autoComplete="off"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <AccountCircleIcon />
                    </InputAdornment>
                  ),
                }}
                onChange={e => setFirstName(e.target.value)}
              />
              <br />
              <Button
                variant="contained"
                sx={{ textTransform: 'none', minWidth: 160 }}
                onClick={save}
                disabled={firstName === user?.firstName}
              >
                Save
              </Button>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                id="email"
                label="Email address"
                variant="outlined"
                sx={{ mt: 4, mb: 2, minWidth: '100%' }}
                value={email}
                autoComplete="off"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <EmailIcon />
                    </InputAdornment>
                  ),
                }}
                onChange={e => setEmail(e.target.value)}
                disabled={true}
              />
              {/* <Button
                variant="contained"
                sx={{ textTransform: "none", minWidth: 160 }}
                onClick={() => setChangeEmailDialogDismissed(false)}
              >
                Change
              </Button> */}
            </Grid>
          </Grid>
          <br />
          <Grid container spacing={2} sx={{ mt: 2 }}>
            <Grid item>
              <Button
                variant="contained"
                sx={{
                  textTransform: 'none',
                  backgroundColor: '#d32f2f',
                  color: '#ffffff',
                  minWidth: 160,
                  '&:hover': {
                    backgroundColor: '#ffffff',
                    color: '#d32f2f',
                  },
                }}
                onClick={() => setLogoutDialogDismissed(false)}
              >
                Sign out
              </Button>
            </Grid>
          </Grid>
          <Divider sx={{ my: 2 }} />
          <Resume />
          <Divider sx={{ my: 2 }} />
          <Subscription />
          <Divider sx={{ my: 2 }} />
          <Typography variant="h5" gutterBottom>
            <b>Account Management</b>
          </Typography>
          <Grid container spacing={2} sx={{ mt: 2 }}>
            <Grid item>
              <Button
                variant="contained"
                sx={{
                  textTransform: 'none',
                  backgroundColor: '#ffffff',
                  color: '#d32f2f',
                  minWidth: 160,
                  '&:hover': {
                    backgroundColor: '#e4e4e4',
                    color: '#d32f2f',
                  },
                }}
                onClick={() => {
                  setDeleteAccountDialogDismissed(false);
                  setConfirmEmail('');
                }}
              >
                Delete account
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <PIDialog
        title={dialogTitle}
        description={dialogDescription}
        open={
          !logoutDialogDismissed ||
          !changeEmailDialogDismissed ||
          !deleteAccountDialogDismissed
        }
        onClose={() => {
          setLogoutDialogDismissed(true);
          setChangeEmailDialogDismissed(true);
          setDeleteAccountDialogDismissed(true);
        }}
        buttons={dialogButtons}
      />
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  container: {
    padding: 4,
  },
};
