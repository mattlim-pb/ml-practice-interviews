import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { LoadingButton } from '@mui/lab';
import { Box, Button, Typography } from '@mui/material';
import moment from 'moment';
import { useCallback, useMemo } from 'react';
import { useRecoilValue } from 'recoil';
import { VisuallyHiddenInput } from '../../../components/VisuallyHiddenInput';
import { useDeleteResume } from '../../../middleware/useDeleteResume';
import { useUploadResume } from '../../../middleware/useUploadResume';
import { userState } from '../../../states/auth';

export function Resume() {
  const uploadResume = useUploadResume();
  const deleteResume = useDeleteResume();
  const user = useRecoilValue(userState);

  const resumeExists = useMemo(() => {
    return user?.metadata?.resume?.url != null;
  }, [user]);

  const uploadFile = useCallback(
    (e: any) => {
      const file = e.target.files[0];
      if (file != null) {
        uploadResume.mutate({ resume: file });
        e.target.value = '';
      }
    },
    [uploadResume]
  );

  return (
    <Box>
      <Typography variant="h5" fontWeight="bold">
        Your Resume
      </Typography>
      <Typography sx={{ mt: 2 }}>
        Upload your resume to get tailored feedback on your common and
        behavioral questions. This doesn’t have to be tailored for a specific
        role, our AI will determine the relevant parts from your generic resume.
      </Typography>
      {resumeExists && (
        <Button
          variant="outlined"
          sx={{ mt: 2, textTransform: 'none', textAlign: 'left' }}
          startIcon={<FileDownloadIcon />}
          href={user?.metadata?.resume?.url ?? ''}
          download={true}
        >
          <Box>
            <Typography fontSize={18} fontWeight="bold">
              {user?.metadata?.resume?.filename}
            </Typography>
            <Typography fontSize={12} color="gray">
              Uploaded on{' '}
              {moment(user?.metadata?.resume?.uploaded_at ?? 0).format(
                'MMMM DD YYYY'
              )}
            </Typography>
          </Box>
        </Button>
      )}
      <Box display="flex" columnGap={1} sx={{ mt: 2 }}>
        <LoadingButton
          variant="contained"
          component="label"
          loading={uploadResume.isLoading}
          role={undefined}
          tabIndex={-1}
          sx={{ textTransform: 'none' }}
        >
          <span>{resumeExists ? 'Replace' : 'Upload'}</span>
          <VisuallyHiddenInput
            type="file"
            accept="application/pdf"
            onChange={uploadFile}
          />
        </LoadingButton>
        <LoadingButton
          variant="contained"
          color="error"
          disabled={!resumeExists}
          loading={deleteResume.isLoading}
          sx={{ textTransform: 'none' }}
          onClick={() => {
            deleteResume.mutate({});
          }}
        >
          <span>Delete</span>
        </LoadingButton>
      </Box>
    </Box>
  );
}
