import { Box, Button, Typography, useTheme } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useSetRecoilState } from 'recoil';
import quickLink1 from '../../assets/images/quick-links-1.png';
import quickLink2 from '../../assets/images/quick-links-2.png';
import { MainLayout } from '../../components/MainLayout';
import { useMe } from '../../middleware/useMe';
import { APP_PATHS } from '../../routes/paths';
import { questionTypeState } from '../../states/recording';
import { InterviewAcademyOverview } from './InterviewAcademy/InterviewAcademyOverview';

const INTERVIEW_CUSTOMIZATION_STEPS = [
  {
    path: APP_PATHS.chooseCompany,
    canSkip: true,
  },
  {
    path: APP_PATHS.jobCategories,
  },
  {
    path: APP_PATHS.selectQuestionType,
  },
  {
    path: APP_PATHS.confirmInterview,
  },
] as const;

const GENERIC_INTERVIEW_STATE = {
  selectedJob: {
    id: '',
  },
} as const;

const CUSTOMIZE_INTERVIEW_STATE = {
  step: 0,
  stepsAry: INTERVIEW_CUSTOMIZATION_STEPS,
} as const;

const overlayStyles = {
  position: 'absolute',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: 'rgba(0, 0, 0, 0.5)',
  borderRadius: '12px',
  zIndex: 1,
} as const;

export default function HomePage() {
  const navigate = useNavigate();
  const { canPractice, isFree } = useMe();
  const setQuestionType = useSetRecoilState(questionTypeState);
  const theme = useTheme();

  const continueButtonStyles = {
    backgroundColor: theme.interviewAcademy.secondaryDark,
    textTransform: 'none',
    maxWidth: { xs: '100%', sm: 300 },
    width: '100%',
    p: { xs: '8px 16px', md: '10px 20px' },
    justifyContent: 'center',
    fontSize: { xs: 11, sm: 12 },
    fontWeight: 700,
    '&:hover': {
      backgroundColor: theme.interviewAcademy.primaryDark,
    },
  } as const;

  return (
    <MainLayout backgroundColor={theme.interviewAcademy.grayLight}>
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          pt: { xs: 2, md: 4 },
          px: { xs: 2, md: 4, lg: 0 },
          maxWidth: '100%',
          overflow: 'hidden',
          transition: 'all 0.3s',
        }}
      >
        {/* Interview Academy Overview */}
        <InterviewAcademyOverview />

        {/* INTERVIEWS */}
        <div className="mt-[16px] md:mt-[24px] mb-[16px] md:mb-[24px]">
          <Typography
            variant="h6"
            className="!text-[12px] md:!text-[14px] !font-normal !text-[#7b7b7b]"
          >
            INTERVIEWS
          </Typography>
        </div>

        <Box className="flex flex-col md:flex-row gap-4 mb-0">
          <Box
            className="flex-1 p-3 md:p-4 rounded-[12px] flex flex-col items-center text-center relative"
            sx={{ backgroundColor: theme.interviewAcademy.white }}
          >
            {!canPractice && <Box sx={overlayStyles} />}
            <Typography
              className="!text-[20px] md:!text-[24px] !font-bold relative"
              sx={{ zIndex: 0 }}
            >
              Start interviewing now
            </Typography>
            <span className="mb-2 md:mb-3 !text-[11px] md:!text-[12px] !font-normal">
              Get commonly asked questions straight away
            </span>
            <Box
              sx={{
                height: { xs: '90px', md: '110px' },
                display: 'flex',
                alignItems: 'center',
                mb: { xs: 2, md: 3 },
              }}
            >
              <img
                src={require('../../assets/images/start-interviewing-now.png')}
                alt="Start interviewing now"
                className="max-h-full w-auto"
              />
            </Box>
            <Button
              variant="contained"
              sx={continueButtonStyles}
              onClick={() => {
                setQuestionType('generic');
                navigate(APP_PATHS.startAnswering, {
                  state: GENERIC_INTERVIEW_STATE,
                });
              }}
            >
              Continue
            </Button>
          </Box>
          <Box
            className="flex-1 p-3 md:p-4 rounded-[12px] flex flex-col items-center text-center relative"
            sx={{ backgroundColor: theme.interviewAcademy.white }}
          >
            {!(canPractice && !isFree) && <Box sx={overlayStyles} />}
            <Typography
              className="!text-[20px] md:!text-[24px] !font-bold relative"
              sx={{ zIndex: 0 }}
            >
              Customize your interview
            </Typography>
            <span className="mb-2 md:mb-3 !text-[11px] md:!text-[12px] !font-normal">
              Questions specifically tailored to your job search
            </span>
            <Box
              sx={{
                height: { xs: '90px', md: '110px' },
                display: 'flex',
                alignItems: 'center',
                mb: { xs: 2, md: 3 },
              }}
            >
              <img
                src={require('../../assets/images/customize-your-interview.png')}
                alt="Customize your interview"
                className="max-h-full w-auto"
              />
            </Box>
            <Button
              variant="contained"
              sx={continueButtonStyles}
              onClick={() => {
                navigate(APP_PATHS.chooseCompany, {
                  state: CUSTOMIZE_INTERVIEW_STATE,
                });
              }}
            >
              Continue
            </Button>
          </Box>
        </Box>

        {/* QUICK LINKS */}
        <div className="my-[16px] md:my-[24px]">
          <Typography
            variant="h6"
            className="!text-[12px] md:!text-[14px] !font-normal !text-[#7b7b7b]"
          >
            QUICK LINKS
          </Typography>
        </div>

        <Box className="flex flex-col md:flex-row gap-3 md:gap-4 mb-[24px] md:mb-[32px]">
          <Box
            className="flex-1 rounded-[12px] overflow-hidden relative"
            onClick={() => canPractice && navigate('/resources')}
            sx={{
              cursor: canPractice ? 'pointer' : 'default',
              backgroundColor: theme.interviewAcademy.white,
              maxHeight: '200px',
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            {!canPractice && <Box sx={overlayStyles} />}
            <img
              src={quickLink2}
              alt="Resources"
              className="object-cover h-full w-full"
            />
          </Box>
          <Box
            className="flex-1 rounded-[12px] overflow-hidden"
            sx={{
              backgroundColor: theme.interviewAcademy.white,
              maxHeight: '200px',
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <img
              src={quickLink1}
              alt="Story Bank"
              className="object-cover h-full w-full"
            />
          </Box>
        </Box>

        {/* Footer */}
        <Typography
          variant="body2"
          className="text-center !text-[12px] md:!text-[14px] !font-normal !text-[#7b7b7b] pb-[24px] md:pb-[32px]"
        >
          Practice Interviews. All Rights Reserved 2024.
        </Typography>
      </Box>
    </MainLayout>
  );
}
