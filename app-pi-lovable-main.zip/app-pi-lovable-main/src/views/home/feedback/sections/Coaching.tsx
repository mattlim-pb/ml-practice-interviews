import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  CircularProgress,
  Typography,
} from '@mui/material';
import Button from '@mui/material/Button';
import { useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useRecoilValue } from 'recoil';
import MarkdownView from '../../../../components/MarkdownView';
import {
  behavioral,
  hypothetical,
  sectionsTitle,
} from '../../../../data/coaching';
import { answerAnalysisState } from '../../../../states/AnswerAnalysis';
import { modularFeedbacksState } from '../../../../states/modularFeedbacks';
import { scoresState } from '../../../../states/score';
import { removeGeneric } from '../../../../utils/string';

export default function Coaching({ loading }: { loading: boolean }) {
  const { state } = useLocation();
  const accordionRef = useRef<HTMLDivElement>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(
    'summary'
  );

  const modularFeedbacks = useRecoilValue(modularFeedbacksState);
  const answerAnalysis = useRecoilValue(answerAnalysisState);
  const scores = useRecoilValue(scoresState);

  const dataSections = Object.keys(modularFeedbacks ?? {});
  const questionType =
    state?.interviewQuestion?.questionType &&
    removeGeneric(state?.interviewQuestion?.questionType);

  const activeSections =
    questionType === 'behavioral'
      ? Object.keys(behavioral)
      : questionType === 'hypothetical'
      ? Object.keys(hypothetical)
      : ['summary'];

  const selectedDenominator: { [key: string]: string } =
    questionType === 'behavioral' ? behavioral : hypothetical;

  if (questionType === 'common' || dataSections.length === 0) {
    if ((!answerAnalysis?.feedback && !modularFeedbacks) || loading) {
      return (
        <div className="w-full animate-pulse my-4">
          <div className="h-80 w-full bg-textBorder rounded my-2"></div>
        </div>
      );
    } else {
      return (
        <div className="border border-textBorder rounded-lg p-3">
          <MarkdownView>{answerAnalysis?.feedback ?? ''}</MarkdownView>
        </div>
      );
    }
  }

  return (
    <div className="scroll-smooth !mb-40 sm:!mb-32">
      <Box className="py-4 ">
        {activeSections.map((option, i) => {
          const title = sectionsTitle[option]?.title ?? '';
          return (
            <Button
              component="button"
              onClick={() => {
                // ensure there is a parent element already
                if (!accordionRef.current) return;
                const element = document.getElementById(option);
                // ensure the element is in the dom
                if (!element) return;
                element.scrollIntoView({
                  behavior: 'smooth',
                  block: 'start',
                });
                setSelectedOption(option);
              }}
              key={i}
              sx={{
                textTransform: 'capitalize',
                borderRadius: 2,
                fontWeight: 'bold',
                marginRight: 1,
              }}
              variant={selectedOption === option ? 'contained' : 'outlined'}
            >
              {title}
            </Button>
          );
        })}
      </Box>
      <Box ref={accordionRef}>
        {activeSections.map((option, i) => {
          // if (!dataSections.includes(option)) return null;
          const isLoaded = dataSections.includes(option);
          const title = sectionsTitle[option]?.title ?? '';
          return (
            <Accordion
              expanded={isLoaded && selectedOption === option}
              key={i}
              sx={{
                border: 'none',
                boxShadow: 'none',
                '& .MuiAccordionSummary-root': {
                  marginBottom: 0,
                },
              }}
            >
              <AccordionSummary
                id={option}
                expandIcon={
                  isLoaded ? (
                    <ExpandMoreIcon />
                  ) : (
                    <CircularProgress
                      color="primary"
                      size={14}
                      sx={{ mx: 'auto', mr: 2 }}
                    />
                  )
                }
                aria-controls={`"panel1-content"`}
                onClick={() => setSelectedOption(option)}
              >
                <Box className="flex justify-between w-full">
                  <Typography className="!font-bold">{title}</Typography>
                  <Typography
                    sx={{
                      color: 'primary.main',
                      fontWeight: 'bold',
                      marginRight: 1,
                      transition: 'all 0.3s ease-in-out',
                      opacity: 0,
                    }}
                    style={{
                      opacity:
                        scores?.total && selectedDenominator[option] !== '0'
                          ? 1
                          : 0,
                    }}
                  >
                    {scores?.[option] ?? 0}/{selectedDenominator[option]}
                  </Typography>
                </Box>
              </AccordionSummary>
              {modularFeedbacks?.[option] && (
                <AccordionDetails className="!py-0 !pl-2">
                  <Box className="border border-textBorder rounded-lg p-3">
                    <MarkdownView>{modularFeedbacks?.[option]}</MarkdownView>
                  </Box>
                </AccordionDetails>
              )}
            </Accordion>
          );
        })}
      </Box>
    </div>
  );
}
