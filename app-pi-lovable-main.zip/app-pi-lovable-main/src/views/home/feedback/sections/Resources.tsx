import { useEffect, useState } from 'react';
import 'react-multi-carousel/lib/styles.css';
import { NotionRenderer } from 'react-notion-x';
import 'react-notion-x/src/styles.css';
import { useLocation, useParams } from 'react-router-dom';
import { Loading } from '../../../../components/Loading';
import { Subscription } from '../../../../components/Subscription';
import { useGetNotionPage } from '../../../../middleware/useGetNotionPage';
import { useMe } from '../../../../middleware/useMe';

interface ResourcesProps {
  feedback?: boolean;
}

export const STATIC_RESOURCES_DATA: Array<{
  title: string;

  type: string;
  resources: { title: string; video: string; description: string }[];
}> = [
  {
    title: 'Tool Overview',
    type: 'tool-overview',
    resources: [
      {
        title: 'How to use Practice Interviews AI',
        video: 'https://www.youtube.com/watch?v=YqHDtKx4vDc',
        description:
          'Learn how to start practicing right away with this short overview!',
      },
    ],
  },
];

export default function Resources({ feedback }: ResourcesProps) {
  const { pageId } = useParams<{ pageId: string }>();

  const { isLoading, user } = useMe();

  const { state } = useLocation();

  const questionType = state?.interviewQuestion?.questionType ?? 'common';
  const shouldFilterResources = feedback && questionType !== 'common';

  const [recordMap, setRecordMap] = useState<any>(undefined);
  const { mutate } = useGetNotionPage();

  useEffect(() => {
    mutate(pageId || '', {
      onSuccess: ({ data }) => {
        console.log('render: ', data);
        setRecordMap(data.data);
      },
    });
  }, [pageId, mutate]);

  return isLoading ? (
    <Loading />
  ) : user?.isFree && !shouldFilterResources ? (
    <Subscription />
  ) : (
    <NotionRenderer
      recordMap={recordMap}
      fullPage={true}
      darkMode={false}
      mapPageUrl={(pageId: string) => `/resources/${pageId}`}
    />
  );
}
