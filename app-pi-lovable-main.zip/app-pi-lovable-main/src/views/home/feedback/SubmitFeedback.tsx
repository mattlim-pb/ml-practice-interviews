import ThumbDownOffAltOutlinedIcon from '@mui/icons-material/ThumbDownOffAltOutlined';
import ThumbUpAltOutlinedIcon from '@mui/icons-material/ThumbUpAltOutlined';
import { Box, IconButton } from '@mui/material';
import { useCallback } from 'react';
import { useSubmitFeedback } from '../../../middleware/useSubmitFeedback';

interface Props {
  messageId: string;
}

export function SubmitFeedback({ messageId }: Props) {
  const submitFeedback = useSubmitFeedback();
  const isPositive = (submitFeedback.data as any)?.data?.isPositive;

  const onSubmitFeedback = useCallback(
    (isPositive: boolean) => {
      submitFeedback.mutate({
        isPositive,
        messageId,
      });
    },
    [submitFeedback, messageId]
  );
  return (
    <Box sx={styles.feedbackRow}>
      <IconButton onClick={() => onSubmitFeedback(true)}>
        <ThumbUpAltOutlinedIcon
          color={submitFeedback.isSuccess && isPositive ? 'primary' : 'inherit'}
        />
      </IconButton>
      <IconButton onClick={() => onSubmitFeedback(false)}>
        <ThumbDownOffAltOutlinedIcon
          color={
            submitFeedback.isSuccess && !isPositive ? 'primary' : 'inherit'
          }
        />
      </IconButton>
    </Box>
  );
}

const styles: { [key: string]: any } = {
  feedbackRow: {
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'row',
  },
};
