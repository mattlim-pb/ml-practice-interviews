import StreamingTextField from '../../../components/StreamingTextField';
import { Question } from '../../../data/question';
import useOnInitialMount from '../../../hooks/useOnInitialMount';
import { useGetIdealAnswer } from '../../../middleware/useGetIdealAnswer';

export function IdealAnswer({
  selectedQuestion,
}: {
  selectedQuestion: Question;
}) {
  const { getIdealAnswer, isLoading, idealAnswer } = useGetIdealAnswer();

  useOnInitialMount(() => {
    if (selectedQuestion != null) {
      getIdealAnswer(selectedQuestion.id);
    }
  });

  return <StreamingTextField value={idealAnswer} isLoading={isLoading} />;
}
