import { Grid, TextField } from '@mui/material';
import { useMemo } from 'react';
import { useRecoilValue } from 'recoil';
import { Loading } from '../../../components/Loading';
import { ScoreBarChart } from '../../../components/ScoreBarChart';
import { TabView } from '../../../components/TabView';
import UpgradeToPremium from '../../../components/UpgradeToPremium';
import { Constants } from '../../../data/constants';
import { ScoreResult } from '../../../data/scoreResult';
import { useWindowDimensions } from '../../../hooks/useWindowDimensions';
import { useMe } from '../../../middleware/useMe';
import { answerAnalysisState } from '../../../states/AnswerAnalysis';

import { Question } from '../../../data/question';
import { scoresState } from '../../../states/score';
import { capitalizeFirstLetter } from '../../../utils/string';
import { IdealAnswer } from './IdealAnswer';
import { MediaPlayer } from './MediaPlayer';
import Coaching from './sections/Coaching';
import Resources from './sections/Resources';

interface Props {
  selectedQuestion: Question;
  type: 'video' | 'audio' | 'text';
  loading: boolean;
}

const HEIGHT_LIMIT = 400;

export function AnswerAnalysis({ type, loading, selectedQuestion }: Props) {
  const { windowHeight, getAppropriateHeight } = useWindowDimensions();
  const scores = useRecoilValue(scoresState);

  const transcription = useRecoilValue(answerAnalysisState)?.transcription;
  const s3Url = useRecoilValue(answerAnalysisState)?.s3Url;
  const rowCount = Math.ceil(
    (windowHeight - HEIGHT_LIMIT) / Constants.TEXTFIELD_ONE_ROW_HEIGHT
  );
  const height =
    getAppropriateHeight(HEIGHT_LIMIT) + Constants.TEXTFIELD_ONE_ROW_HEIGHT + 8;
  const style = {
    minHeight: height,
    maxHeight: height,
    height,
  };
  const { isFree } = useMe();

  const isText = type === 'text' || s3Url == null;

  const hideAnalytics = true;
  const hideIdealAnswer = selectedQuestion?.questionType === 'common';

  const dataset = useMemo(() => {
    if (scores == null) return null;
    return Object.keys(scores).map((key: string) => {
      // TODO @Austin move this transformation to backend
      let value;
      switch (key) {
        case 'clarify':
          value = scores[key] * (100 / 20);
          break;
        case 'framework':
          value = scores[key] * (100 / 20);
          break;
        case 'assumptions':
          value = scores[key] * (100 / 20);
          break;
        case 'solution':
          value = scores[key] * (100 / 40);
          break;
        case 'situationAndTask':
          value = scores[key] * (100 / 25);
          break;
        case 'actions':
          value = scores[key] * (100 / 50);
          break;
        case 'results':
          value = scores[key] * (100 / 25);
          break;
        default:
          value = scores[key as keyof ScoreResult];
      }

      return {
        label:
          key === 'situationAndTask'
            ? 'Situation & Task'
            : capitalizeFirstLetter(key),
        value: value,
      };
    });
  }, [scores]);

  return (
    <TabView
      labels={
        [
          'Coaching',
          'Your answer',
          hideIdealAnswer ? null : 'Ideal Answer',
          hideAnalytics ? null : 'Analytics',
          'Resources',
        ].filter(Boolean) as string[]
      }
      pages={[
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Coaching loading={loading} />
          </Grid>
        </Grid>,
        <Grid container spacing={2}>
          <Grid className={`${isText && 'hidden'}`} item xs={6}>
            {loading ? (
              <Loading title={`Transcribing ${type}...`} className="h-96" />
            ) : (
              <MediaPlayer type={type} s3Url={s3Url} />
            )}
          </Grid>
          <Grid item xs={isText ? 12 : 6}>
            <TextField
              variant="outlined"
              InputProps={{ readOnly: true }}
              placeholder=""
              fullWidth
              multiline
              rows={rowCount - 1}
              value={transcription ?? ''}
            />
          </Grid>
        </Grid>,
        hideIdealAnswer ? null : (
          <Grid item xs={12}>
            {isFree ? (
              <UpgradeToPremium />
            ) : (
              <IdealAnswer selectedQuestion={selectedQuestion} />
            )}
          </Grid>
        ),
        hideAnalytics ? null : (
          <div style={{ ...style, ...styles.box, ...styles.chart }}>
            {isFree ? (
              <UpgradeToPremium />
            ) : (
              <ScoreBarChart
                legendLabel="Interview Score"
                dataset={dataset ?? []}
              />
            )}
          </div>
        ),
        <div className="w-screen-1/2">
          {isFree ? <UpgradeToPremium /> : <Resources feedback />}
        </div>,
      ].filter(Boolean)}
    />
  );
}

const styles = {
  box: {
    borderWidth: 1,
    borderRadius: 5,
    padding: 8,
  },
  recording: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'flex-start',
    height: '100%',
  },
  chart: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
  },
};
