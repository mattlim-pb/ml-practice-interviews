import { Container, Grid, Typography } from '@mui/material';
import { Question } from '../../../data/question';
import { AnswerAnalysis } from '../../../views/home/feedback/AnswerAnalysis';

interface Props {
  selectedQuestion: Question;
  interviewQuestion: string;
  isLoading?: boolean;
  type?: 'audio' | 'video' | 'text';
}

export function AnswerResult({
  selectedQuestion,
  interviewQuestion,
  isLoading = false,
  type = 'text',
}: Props) {
  return (
    <Container component="main" maxWidth="xl" sx={styles.container}>
      <Grid container rowSpacing={2} columnSpacing={1} alignItems="center">
        <Grid
          item
          xs={12}
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          {interviewQuestion ?? (
            <>
              <Typography variant="h5" gutterBottom flex={1}>
                <b>{interviewQuestion}</b>
              </Typography>
            </>
          )}
        </Grid>
        <Grid item xs={12}>
          <AnswerAnalysis
            selectedQuestion={selectedQuestion}
            loading={isLoading}
            type={type}
          />
        </Grid>
      </Grid>
    </Container>
  );
}

const styles: { [key: string]: any } = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'top',
    px: 3,
    paddingTop: 4,
  },
  feedbackRow: {
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'start',
    paddingLeft: `0 !important`,
    my: 1,
  },
  answerLabel: {
    mb: 1,
  },
};
