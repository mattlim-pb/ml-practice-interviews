import PauseOutlinedIcon from '@mui/icons-material/PauseOutlined';
import PlayArrowOutlinedIcon from '@mui/icons-material/PlayArrowOutlined';
import { Box, IconButton, Typography } from '@mui/material';
import Button from '@mui/material/Button';
import moment from 'moment';
import { useCallback, useEffect, useRef, useState } from 'react';
import 'react-h5-audio-player/lib/styles.css';
import { AnimatedAudio } from '../../../components/AnimatedAudio';
import { useOnChange } from '../../../hooks/useOnChange';
import { theme } from '../../../styles/theme';

interface Props {
  type: 'video' | 'audio' | 'text';
  s3Url?: string;
}

export function MediaPlayer({ type, s3Url }: Props) {
  const audioPlayerRef = useRef(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const [audioPlayer, setAudioPlayer] = useState<HTMLAudioElement | null>(null);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [videoUrl, setVideoUrl] = useState<string>();

  useOnChange({
    value: s3Url,
    defaultValue: null,
    onChange: () => {
      if (s3Url != null) {
        if (type === 'video') {
          setVideoUrl(s3Url);
        } else {
          setAudioPlayer(
            document.getElementById('audio-player') as HTMLAudioElement
          );
        }
      }
    },
  });

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      if (audioPlayer) {
        if (audioPlayer?.currentTime >= audioPlayer?.duration) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current);
            setIsPlaying(false);
            setCurrentTime(0);
            return;
          }
        }
        setCurrentTime(Math.floor(audioPlayer?.currentTime));
      }
    }, 1000) as unknown as NodeJS.Timeout;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying]);

  const playStop = useCallback(() => {
    if (audioPlayer) {
      if (isPlaying) {
        setIsPlaying(false);
        audioPlayer?.pause();
      } else {
        setIsPlaying(true);
        audioPlayer?.play();
      }
    }
  }, [isPlaying, audioPlayer]);

  return type === 'video' ? (
    <Box
      className={`border !border-textBorder rounded-md p-2 h-full flex flex-col align-middle justify-center relative`}
    >
      <video
        controls
        src={videoUrl}
        autoPlay
        muted
        playsInline
        style={{
          width: '100%',
          objectFit: 'contain',
          objectPosition: '50% 50%',
          height: `100%`,
        }}
      />
    </Box>
  ) : (
    <Box
      className={`border !border-textBorder rounded-md p-2 h-full flex flex-col align-middle justify-center relative`}
    >
      <Button
        variant="contained"
        className="w-1/2 self-center !mb-2 !capitalize"
        startIcon={
          isPlaying ? <PauseOutlinedIcon /> : <PlayArrowOutlinedIcon />
        }
        onClick={playStop}
      >
        Play recording
      </Button>
      <AnimatedAudio maxHeight={50} length={20} />
      <audio id="audio-player" ref={audioPlayerRef} src={`${s3Url}`} />
      <Box
        sx={{
          backgroundColor: 'rgba(255, 255, 255, 1)',
          padding: 1,
          position: 'absolute',
          bottom: 0,
          opacity: 1,
          transition: 'all 0.5s',
          width: '90%',
        }}
      >
        <Typography
          sx={{
            display: 'inline-block',
            color: theme.palette.primary.dark,
          }}
        >
          {moment(currentTime).format('mm:ss')}
        </Typography>
        <IconButton onClick={playStop}>
          {isPlaying ? (
            <PauseOutlinedIcon color="primary" />
          ) : (
            <PlayArrowOutlinedIcon color="primary" />
          )}
        </IconButton>
      </Box>
    </Box>
  );
}
