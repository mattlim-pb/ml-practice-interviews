import * as amplitude from '@amplitude/analytics-browser';
import ArrowRightAltOutlinedIcon from '@mui/icons-material/ArrowRightAltOutlined';
import CheckOutlinedIcon from '@mui/icons-material/CheckOutlined';
import ReplayOutlinedIcon from '@mui/icons-material/ReplayOutlined';
import { Box, Button, Container, Grid, Typography } from '@mui/material';
import { useCallback } from 'react';
import { useRecoilState, useRecoilValue, useSetRecoilState } from 'recoil';

import { useLocation, useNavigate } from 'react-router-dom';
import HeaderGauge from '../../../components/HeaderGauge';
import { MainLayout } from '../../../components/MainLayout';
import { useNextQuestion } from '../../../hooks/useNextQuestion';
import { useOnChange } from '../../../hooks/useOnChange';
import useOnInitialMount from '../../../hooks/useOnInitialMount';
import { useSubmitRecording } from '../../../middleware/useSubmitRecording';
import { APP_PATHS } from '../../../routes/paths';
import {
  answerAnalysisState,
  AnswerAnalysisType,
} from '../../../states/AnswerAnalysis';
import { modularFeedbacksState } from '../../../states/modularFeedbacks';
import { questionState, threadState } from '../../../states/recording';
import { scoresState } from '../../../states/score';
import { getGenericType, removeGeneric } from '../../../utils/string';
import { AnswerResult } from './AnswerResult';

export default function Feedback() {
  const navigate = useNavigate();
  const location = useLocation();

  const {
    blob,
    interviewQuestion,
    selectedJob,
    answer,
    type,
    screenType,
    answerId,
  } = location.state;
  const {
    getAnswerById,
    submitRecording,
    transcription: apiTranscription,
    feedback: apiFeedback,
    s3Url: apiS3Url,
    scores: apiScores,
    modularFeedbacks: apiModularFeedbacks,
    isLoading,
  } = useSubmitRecording();

  const { getNextQuestion, isNextQuestionAvailable } = useNextQuestion();

  const [currentQuestion, setCurrentQuestion] = useRecoilState(questionState);
  const setModularFeedbacks = useSetRecoilState(modularFeedbacksState);
  const setAnswerAnalysis =
    useSetRecoilState<AnswerAnalysisType>(answerAnalysisState);
  const [scores, setScores] = useRecoilState(scoresState);

  const questionType = removeGeneric(interviewQuestion.questionType);

  const threadId = useRecoilValue(threadState);

  const onDone = useCallback(() => {
    navigate(APP_PATHS.answerFeedback);
  }, [navigate]);

  const onTryAgain = useCallback(
    (tryAgainOnly: boolean) => {
      setCurrentQuestion(interviewQuestion);
      navigate(APP_PATHS.startAnswering, {
        state: { selectedJob, tryAgainOnly },
        replace: true,
      });
    },
    [navigate, selectedJob, setCurrentQuestion, interviewQuestion]
  );

  const onSelectNextQuestion = useCallback(() => {
    getNextQuestion({
      jobId: selectedJob?.id || '',
      questionType: interviewQuestion.questionType,
      willMonitorLoadingStatus: true,
      selectedCompany: selectedJob?.company || '',
    });
  }, [getNextQuestion, selectedJob, interviewQuestion]);

  useOnChange({
    value: isNextQuestionAvailable,
    defaultValue: false,
    onChange: () => {
      navigate(APP_PATHS.startAnswering, {
        state: { selectedJob },
        replace: true,
      });
    },
  });

  useOnChange({
    value: apiModularFeedbacks,
    defaultValue: null,
    onChange: () => {
      if (!!Object.keys(apiModularFeedbacks ?? {}).length) {
        setModularFeedbacks(apiModularFeedbacks);
      }
    },
  });

  useOnChange({
    value: apiScores,
    defaultValue: null,
    onChange: () => {
      setScores(apiScores);
    },
  });

  useOnChange({
    value: apiFeedback,
    defaultValue: null,
    onChange: () => {
      setAnswerAnalysis(prev => ({
        ...prev,
        feedback: apiFeedback,
      }));
    },
  });

  useOnChange({
    value: apiTranscription,
    defaultValue: null,
    onChange: () => {
      setAnswerAnalysis(prev => ({
        ...prev,
        transcription: apiTranscription,
      }));
    },
  });

  useOnChange({
    value: apiS3Url,
    defaultValue: null,
    onChange: () => {
      if (apiS3Url) {
        setAnswerAnalysis(prev => ({
          ...prev,
          s3Url: apiS3Url,
        }));
      }
    },
  });

  useOnInitialMount(() => {
    amplitude.track(screenType === 'feedback' ? 'Feedback' : 'Summary Detail');
    if (
      screenType === 'feedback' &&
      getGenericType(questionType) !== 'generic'
    ) {
      if ((!blob && !answer) || !interviewQuestion || !selectedJob) {
        navigate('/');
      }

      submitRecording({
        threadId,
        type: type,
        interviewAnswer: answer,
        file: blob,
        questionId: currentQuestion?.id ?? '',
        jobId: selectedJob?.id,
      });
    } else if (screenType === 'summary-detail') {
      getAnswerById(answerId);
    }
  });

  const totalScoreValue = interviewQuestion?.score ?? scores?.total ?? 0;
  const isCommon = questionType === 'common';

  const subHeader = (
    <Container component="main" maxWidth="xl" sx={styles.container}>
      <Grid container>
        <Grid item xs={10} sx={{ margin: 'auto' }}>
          <Typography sx={styles.questionTitle} fontWeight="bold">
            {interviewQuestion?.text}
          </Typography>
        </Grid>

        <HeaderGauge
          totalScoreValue={totalScoreValue}
          scoreLoading={!scores}
          isCommon={isCommon}
        />
      </Grid>
    </Container>
  );

  const footer = (
    <Box display="flex" justifyContent="flex-end" my={2}>
      {screenType === 'feedback' ? (
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={3}>
            <Button
              fullWidth
              variant="outlined"
              color="primary"
              onClick={onDone}
              startIcon={<CheckOutlinedIcon />}
              className="!rounded-full !normal-case"
            >
              I am done for now
            </Button>
          </Grid>
          <Grid item xs={12} sm={6} md={3} sx={{ ml: 'auto' }}>
            <Button
              variant="outlined"
              startIcon={<ReplayOutlinedIcon />}
              onClick={() => onTryAgain(false)}
              className="!rounded-full !normal-case"
              fullWidth
            >
              Try again
            </Button>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Button
              variant="contained"
              color="primary"
              className="!rounded-full !normal-case"
              startIcon={<ArrowRightAltOutlinedIcon />}
              onClick={onSelectNextQuestion}
              fullWidth
            >
              Next Question
            </Button>
          </Grid>
        </Grid>
      ) : (
        <Grid container spacing={2} className="mr-8">
          <Grid item xs={12} sm={6} md={3} lg={2} sx={{ ml: 'auto' }}>
            <Button
              variant="outlined"
              startIcon={<ReplayOutlinedIcon />}
              onClick={() => onTryAgain(true)}
              fullWidth
              className="!rounded-full !normal-case"
            >
              Try again
            </Button>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Button
              variant="outlined"
              color="primary"
              onClick={onDone}
              fullWidth
              startIcon={<CheckOutlinedIcon />}
              sx={styles.replyQuestionButton}
              className="!rounded-full !normal-case"
            >
              Go back to Summary
            </Button>
          </Grid>
        </Grid>
      )}
    </Box>
  );

  return (
    <MainLayout subHeader={subHeader} footer={footer}>
      <AnswerResult
        selectedQuestion={interviewQuestion}
        interviewQuestion={!subHeader ? interviewQuestion?.text : ''}
        isLoading={
          screenType === 'feedback' || screenType === 'summary-detail'
            ? isLoading
            : false
        }
        type={type}
      />
    </MainLayout>
  );
}

const styles: { [key: string]: any } = {
  questionTitle: {
    display: 'inline-block',
    padding: '1rem 0',
    fontSize: {
      md: '1rem',
      lg: '1.5rem',
    },
  },
  replyQuestionButton: {
    height: 40,
  },
};
