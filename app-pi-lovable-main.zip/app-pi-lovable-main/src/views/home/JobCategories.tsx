import { Box, Button, Grid, TextField, Typography } from '@mui/material';
import moment from 'moment';
import { Fragment, useCallback, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useRecoilState } from 'recoil';
import { CategoryButton } from '../../components/CategoryButton';
import { default as ChooseJobSelector } from '../../components/ChooseJobSelector';
import CreateJobForm from '../../components/CreateJobForm';
import CopyIcon from '../../components/icons/CopyIcon';
import SearchIcon from '../../components/icons/SearchIcon';
import { MainLayout } from '../../components/MainLayout';
import PIDialog from '../../components/PIDialog';
import StartPracticingButton from '../../components/StartPracticingButton';
import { Job } from '../../data/job';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useCreateJob } from '../../middleware/useCreateJob';
import { useJobs } from '../../middleware/useJobs';
import { useMe } from '../../middleware/useMe';
import { APP_PATHS } from '../../routes/paths';
import { questionState } from '../../states/recording';

export default function JobCategoriesPage() {
  const navigate = useNavigate();

  const createJob = useCreateJob();

  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');

  const setQuestion = useRecoilState(questionState)[1];
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  const [selectedJob, setSelectedJob] = useState<Job | null | undefined>(null);
  const [showDialog, setShowDialog] = useState<boolean>(false);
  const getJobs = useJobs();
  const { user } = useMe();
  const jobs = useMemo(() => {
    return (getJobs.data?.data?.data ?? []).filter(
      job => job.userId != null && job.userId === user?.id
    );
  }, [getJobs, user]);

  const {
    state: { step, stepsAry, selectedCompany },
  } = useLocation();

  const currentMenuStep = stepsAry[step];

  useOnInitialMount(() => {
    getJobs.mutate({});
  });

  // Job selection
  const handleConfirm = useCallback(() => {
    if (selectedJob) {
      setQuestion(undefined);
      navigate(stepsAry[step + 1].path, {
        state: {
          stepsAry,
          selectedJob,
          step: step + 1,
          selectedCompany,
        },
      });
    }
  }, [selectedJob, setQuestion, navigate, stepsAry, step, selectedCompany]);
  // Job selection

  // Job creation

  useOnChange({
    value: createJob.data?.data?.data,
    defaultValue: undefined,
    onChange: () => {
      if (createJob.data?.data?.data != null) {
        navigate(APP_PATHS.chooseCompany, {
          state: {
            stepsAry,
            selectedJob: createJob.data?.data?.data,
            step: step + 1,
          },
        });
      }
    },
  });

  const onJobCreation = useCallback(() => {
    if (title.trim().length > 0 && description.trim().length > 0) {
      createJob.mutate({ title, description });
    } else {
      toast.error('Job title or description can not be empty!');
    }
  }, [createJob, title, description]);

  const confirmAction = useCallback(() => {
    if (selectedJob && (selectedIndex === 0 || selectedIndex > 1)) {
      handleConfirm();
    } else if (selectedIndex === 1) {
      onJobCreation();
    }
  }, [selectedJob, selectedIndex, handleConfirm, onJobCreation]);

  const confirmDisabled =
    selectedIndex !== 1 ? selectedJob === null : !title && !description;

  // Job creation
  const footer = (
    <Box display="flex" justifyContent="flex-end" className="px-4 py-2 ">
      <Button
        variant="contained"
        color="primary"
        disabled={confirmDisabled}
        onClick={confirmAction}
        className="!rounded-full !normal-case"
      >
        Confirm
      </Button>
    </Box>
  );
  return (
    <MainLayout showBackButton footer={footer}>
      <Box className="flex flex-1 flex-row justify-between mt-10 mb-8 ">
        <Typography
          variant="body1"
          className="!font-bold !text-sm cursor-pointer hover:underline"
          onClick={() => {
            navigate(-1);
          }}
        >
          Back
        </Typography>
        {currentMenuStep?.canSkip && (
          <Typography
            variant="body1"
            className="!font-bold !text-sm cursor-pointer hover:underline"
            onClick={() => {
              navigate(stepsAry[step + 1].path, {
                state: {
                  step: step + 1,
                  stepsAry,
                  selectedJob,
                  selectedCompany,
                },
              });
            }}
          >
            Skip
          </Typography>
        )}
      </Box>
      <Grid item xs={12} className="pb-16">
        <Typography variant="h4" fontWeight="bold">
          {`Step ${step + 1}: Choose your position `}
        </Typography>
        <Typography variant="h6" fontWeight="bold" className="!text-lg !my-16">
          What job are you aiming for?
        </Typography>
        <Box
          display="flex"
          justifyContent="center"
          className={`md:flex-row flex-col`}
        >
          <span className="flex-1 mt-4 md:mt-0 md:mr-2 ml-0 ">
            <StartPracticingButton
              nowrap
              title="Choose from our job descriptions"
              icon={
                <SearchIcon
                  className="group-hover:!stroke-white"
                  color={selectedIndex === 0 ? '#FFFFFF' : '#000000'}
                />
              }
              isSelected={selectedIndex === 0}
              onClick={() => setSelectedIndex(0)}
            />
          </span>
          <span className="flex-1 mt-4 md:mt-0 md:ml-2 ml-0  ">
            <StartPracticingButton
              nowrap
              title="Insert your own job description"
              icon={
                <CopyIcon
                  className="group-hover:!stroke-white"
                  color={selectedIndex === 1 ? '#FFFFFF' : '#000000'}
                />
              }
              isSelected={selectedIndex === 1}
              onClick={() => setSelectedIndex(1)}
            />
          </span>
        </Box>
        {(selectedIndex === 0 || selectedIndex === 1) && (
          <Typography
            onClick={() => {
              setSelectedJob(null);
              setSelectedIndex(-1);
            }}
            variant="h4"
            fontWeight="thin"
            className="!my-16 cursor-pointer underline text-right !text-sm "
          >
            See previous job descriptions
          </Typography>
        )}

        {selectedIndex === 0 && (
          <ChooseJobSelector
            setSelectedJob={setSelectedJob}
            selectedJob={selectedJob}
          />
        )}

        {selectedIndex === 1 && (
          <CreateJobForm
            title={title}
            setTitle={setTitle}
            description={description}
            setDescription={setDescription}
          />
        )}

        {jobs.length > 0 && (selectedIndex >= 2 || selectedIndex < 0) && (
          <Fragment>
            <Typography
              variant="h4"
              fontWeight="bold"
              className="!text-lg !my-16"
            >
              Or select one of your previous custom job descriptions
            </Typography>
            {jobs
              .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
              .map((job, index) => (
                <CategoryButton
                  key={index}
                  title={job.title}
                  description={`Created on ${moment(job.createdAt).format(
                    'DD MMMM YYYY'
                  )}`}
                  selected={selectedIndex === index + 2} // 2 means default cateogry buttons count on top of screen
                  onClick={e => {
                    e.preventDefault();
                    setSelectedIndex(index + 2);
                    setSelectedJob(jobs[index]);
                  }}
                  onViewDetails={() => setShowDialog(true)}
                />
              ))}
          </Fragment>
        )}
      </Grid>

      <PIDialog
        open={showDialog}
        title={jobs[selectedIndex - 2]?.title}
        node={
          <>
            <TextField
              id="description"
              label="Job title"
              type="text"
              disabled
              fullWidth
              multiline
              rows={1}
              variant="outlined"
              InputLabelProps={{ shrink: true }}
              defaultValue={jobs[selectedIndex - 2]?.title}
              sx={{
                '& .MuiInputBase-input.Mui-disabled': {
                  WebkitTextFillColor: '#000000',
                },
                marginTop: 4,
              }}
            />
            <TextField
              id="description"
              label="Job Description"
              type="text"
              disabled
              fullWidth
              multiline
              rows={8}
              variant="outlined"
              InputLabelProps={{ shrink: true }}
              defaultValue={jobs[selectedIndex - 2]?.description}
              sx={{
                '& .MuiInputBase-input.Mui-disabled': {
                  WebkitTextFillColor: '#000000',
                },
                marginTop: 4,
              }}
            />
          </>
        }
        onClose={() => {
          setShowDialog(false);
        }}
        buttons={[
          {
            text: 'Ok',
            onPress: () => {
              setShowDialog(false);
            },
          },
        ]}
      />
    </MainLayout>
  );
}
