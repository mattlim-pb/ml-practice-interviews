import {
  Box,
  Button,
  Grid,
  SxProps,
  TextField,
  Theme,
  Typography,
} from '@mui/material';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useFeatureFlagVariantKey } from 'posthog-js/react';
import { useCallback, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CheckoutElement } from '../../components/CheckoutElement';
import { MainLayout } from '../../components/MainLayout';
import { SubscriptionCard } from '../../components/SubscriptionCard';
import { Constants } from '../../data/constants';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useChangeBillingInfo } from '../../middleware/useChangeBillingInfo';
import { useCurrentSubscription } from '../../middleware/useCurrentSubscription';
import { useGetPromoByCode } from '../../middleware/useGetPromoByCode';
import { usePosthogCapture } from '../../middleware/usePostHogCapture';
import { APP_PATHS } from '../../routes/paths';

const stripePromise = loadStripe(
  process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY || ''
);

export default function Checkout() {
  const { captureEvent } = usePosthogCapture();
  const trialDaysFlagValue = useFeatureFlagVariantKey(
    Constants.POSTHOG_FEATURE_FLAG.trialDays
  );
  const subscriptionPricingFlagValue = useFeatureFlagVariantKey(
    Constants.POSTHOG_FEATURE_FLAG.trialDays
  );
  const getCurSubscription = useCurrentSubscription();
  const changeBillingInfo = useChangeBillingInfo();
  const { mutate: verifyPromoCode, data: promoVerifyResult } =
    useGetPromoByCode();
  const navigate = useNavigate();
  const location = useLocation();
  const { user, price } = location.state;
  const [promoCode, setPromoCode] = useState<string>('');

  const appliedPromo = useMemo(
    () => promoVerifyResult?.data?.data,
    [promoVerifyResult?.data]
  );

  const getPriceAfterPromo = useCallback((): number | null => {
    const finalPrice = price.amount / 100.0;
    if (appliedPromo) {
      if (appliedPromo?.coupon?.percent_off) {
        return (finalPrice * (100 - appliedPromo?.coupon?.percent_off)) / 100;
      } else {
        return finalPrice - appliedPromo?.coupon?.amount_off / 100.0;
      }
    }
    return null;
  }, [price, appliedPromo]);

  const apply = useCallback(() => {
    verifyPromoCode({ code: promoCode });
  }, [verifyPromoCode, promoCode]);

  useOnChange({
    value: getCurSubscription.isSuccess,
    defaultValue: false,
    onChange: () => {
      navigate(APP_PATHS.account);
    },
  });

  useOnChange({
    value: changeBillingInfo.isSuccess,
    defaultValue: false,
    onChange: () => {
      navigate(APP_PATHS.account);
    },
  });

  useOnInitialMount(() => {
    captureEvent(
      {
        name: 'checkout-page-visited',
        params: {
          price,
          'trial-days-flag':
            trialDaysFlagValue === '3' ? 'enabled' : 'disabled',
          'subscription-pricing-flag':
            subscriptionPricingFlagValue === '27' ? 'enabled' : 'disabled',
        },
      },
      user
    );
  });

  return (
    <MainLayout>
      <Grid
        container
        justifyContent="center"
        alignItems="top"
        sx={styles.container}
      >
        <Elements stripe={stripePromise}>
          <Grid item xs={12} sm={8} md={6}>
            <Typography variant="h5" gutterBottom>
              <b>Checkout</b>
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6} md={4}>
                <Box sx={{ mt: 4 }}>
                  <SubscriptionCard plan={price} />
                </Box>
              </Grid>
              <Grid item xs={12} sm={6} md={8}>
                <Typography sx={styles.price} variant="h4" gutterBottom>
                  <span>
                    <Typography
                      fontWeight="bold"
                      variant="h5"
                      sx={{
                        mr: 1,
                        textDecoration:
                          getPriceAfterPromo() != null
                            ? 'line-through'
                            : 'none',
                      }}
                    >
                      ${price.amount / 100.0}
                    </Typography>
                  </span>
                  {getPriceAfterPromo() != null && (
                    <b>${getPriceAfterPromo()} </b>
                  )}
                </Typography>
                <Grid container spacing={2} direction="column">
                  <Grid item>
                    <TextField
                      id="promocode"
                      label="Promo code"
                      variant="outlined"
                      sx={{ width: '160px' }}
                      value={promoCode}
                      autoComplete="off"
                      onChange={e => setPromoCode(e.target.value)}
                    />
                  </Grid>
                  <Grid item>
                    <Button
                      variant="outlined"
                      sx={{ textTransform: 'none', minWidth: 160 }}
                      color="primary"
                      onClick={apply}
                    >
                      Apply
                    </Button>
                  </Grid>
                </Grid>
                <CheckoutElement
                  user={user}
                  price={price}
                  promo={appliedPromo}
                  onSucceeded={() => {
                    if (user.isFree) {
                      captureEvent(
                        {
                          name: 'subscription-completed',
                          params: {
                            price,
                            'trial-days-flag':
                              trialDaysFlagValue === '3'
                                ? 'enabled'
                                : 'disabled',
                            'subscription-pricing-flag':
                              subscriptionPricingFlagValue === '27'
                                ? 'enabled'
                                : 'disabled',
                          },
                        },
                        user
                      );
                    }
                    getCurSubscription.mutate({});
                  }}
                />
              </Grid>
            </Grid>
          </Grid>
        </Elements>
      </Grid>
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  container: {
    padding: 4,
  },
  price: {
    mt: 4,
    mb: 2,
    minWidth: '100%',
    display: 'flex',
    alignItems: 'center',
  },
};
