import { Container, SxProps, Theme } from '@mui/material';
import { MainLayout } from '../../components/MainLayout';
import Resources from './feedback/sections/Resources';

export default function Analytics() {
  return (
    <MainLayout>
      <Container component="main" maxWidth="xl" sx={styles.container}>
        <Resources />
      </Container>
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  container: {
    paddingTop: 4,
  },
};
