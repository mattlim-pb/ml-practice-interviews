import { Box, Button, Grid, SxProps, Theme, Typography } from '@mui/material';
import { useCallback, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useRecoilState, useRecoilValue, useSetRecoilState } from 'recoil';

import { toast } from 'react-toastify';
import ChooseQuestionButton from '../../components/ChooseQuestionButton';
import { MainLayout } from '../../components/MainLayout';
import { QuestionType } from '../../data/question';
import { useOnChange } from '../../hooks/useOnChange';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useCreateThread } from '../../middleware/useCreateThread';
import { useUploadResume } from '../../middleware/useUploadResume';
import { APP_PATHS } from '../../routes/paths';
import { userState } from '../../states/auth';
import { questionState, questionTypeState } from '../../states/recording';

export default function SelectQuestionType() {
  const navigate = useNavigate();
  const createThread = useCreateThread();
  const uploadResume = useUploadResume();
  const {
    state: { step, selectedJob, selectedCompany, stepsAry },
  } = useLocation();
  const currentMenuStep = stepsAry[step] ?? {};

  const [questionType, setQuestionType] = useRecoilState(questionTypeState);
  const setQuestion = useSetRecoilState(questionState);
  const user = useRecoilValue(userState);

  const hasResume = useMemo(() => {
    return user?.metadata?.resume?.url != null;
  }, [user]);

  const questions = [
    {
      type: 'common' as QuestionType,
      title: 'Common questions',
      description: 'Standard questions that will typically be asked first',
      hasResume,
      info: '',
    },
    {
      type: 'behavioral' as QuestionType,
      title: 'Behavioral questions',
      description:
        '“Tell me about a time...” questions. Answers these with the STAR method.',
      info: '',
    },
    {
      type: 'hypothetical' as QuestionType,
      title: 'Hypothetical questions',
      description:
        '“What would you do if...” questions. Answer these with the CFAS method.',
      info: '',
    },
    {
      type: 'both' as QuestionType,
      title: 'Mix of behavioral & hypothetical questions',
      description: 'Both types of interview questions at once!',
      info: '',
    },
  ];

  const selectQuestionType = useCallback(
    (newQuestionType: QuestionType) => {
      setQuestion(undefined);
      setQuestionType(newQuestionType);
    },
    [setQuestionType, setQuestion]
  );

  useOnInitialMount(() => {
    if (!selectedJob) {
      navigate('/');
    }
  });

  useOnChange({
    value: uploadResume.isSuccess,
    defaultValue: false,
    onChange: () => {
      if (uploadResume.isSuccess) {
        toast.success('Your Resume was uploaded successfully!');
      }
    },
  });

  const onSubmit = useCallback(() => {
    if (questionType === 'common') {
      setQuestion(undefined);
    }
    createThread.mutate({ title: selectedJob?.title ?? '' });
    navigate(APP_PATHS.confirmInterview, {
      state: {
        selectedJob,
        selectedCompany,
        step: step + 1,
        stepsAry,
      },
    });
  }, [
    questionType,
    createThread,
    selectedJob,
    navigate,
    selectedCompany,
    step,
    stepsAry,
    setQuestion,
  ]);

  const footer = (
    <Box display="flex" justifyContent="flex-end" className="px-4 py-2 ">
      <Button
        disabled={!questionType}
        variant="contained"
        color="primary"
        style={{ textTransform: 'none' }}
        onClick={onSubmit}
        className="!rounded-full !normal-case !ml-3"
      >
        Confirm
      </Button>
    </Box>
  );

  return (
    <MainLayout footer={footer}>
      <Grid justifyContent="center" alignItems="center">
        <Box className="flex flex-1 flex-row justify-between mt-10">
          <Typography
            variant="body1"
            className="!font-bold !text-sm cursor-pointer hover:underline"
            onClick={() => {
              navigate(-1);
            }}
          >
            Back
          </Typography>
          {currentMenuStep?.canSkip && (
            <Typography
              variant="body1"
              className="!font-bold !text-sm cursor-pointer hover:underline"
              onClick={() => {
                navigate(stepsAry[step + 1].path, {
                  state: {
                    step: step + 1,
                    stepsAry,
                    selectedJob,
                    selectedCompany,
                  },
                });
              }}
            >
              Skip
            </Typography>
          )}
        </Box>
        <Grid item xs={12} className="!mt-8 !mb-16">
          <Typography variant="h4" fontWeight="bold" sx={styles.title}>
            {`Step ${step + 1}: Choose your interview style`}
          </Typography>
        </Grid>
        <Grid
          item
          xs={12}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pb-20"
        >
          {questions.map(({ title, description, type, hasResume, info }, i) => {
            return (
              <ChooseQuestionButton
                key={i}
                title={title}
                description={description}
                isSelected={questionType === type}
                disabled={type === 'common' && !hasResume}
                type={type}
                info={info}
                hasResume={hasResume}
                onClick={() => {
                  selectQuestionType(type);
                }}
              />
            );
          })}
        </Grid>
      </Grid>
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  button: {
    marginTop: 2,
    marginBottom: 2,
  },
  buttons: {
    my: 2,
    overflowX: 'auto',
  },
  resumeButton: {
    borderRadius: 20,
    textTransform: 'none',
  },
};
