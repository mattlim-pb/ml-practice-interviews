import * as amplitude from '@amplitude/analytics-browser';
import BorderColorOutlinedIcon from '@mui/icons-material/BorderColorOutlined';
import InfoOutlined from '@mui/icons-material/InfoOutlined';
import MicNoneOutlinedIcon from '@mui/icons-material/MicNoneOutlined';
import VideocamIcon from '@mui/icons-material/Videocam';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import {
  Box,
  Button,
  Container,
  Grid,
  IconButton,
  SxProps,
  Theme,
  Tooltip,
  Typography,
} from '@mui/material';
import moment from 'moment';
import { useCallback, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useRecoilState, useRecoilValue } from 'recoil';
import { Loading } from '../../../components/Loading';
import { MainLayout } from '../../../components/MainLayout';
import { PlayQuestionButton } from '../../../components/PlayQuestionButton';
import ProgressBar from '../../../components/ProgressBar';
import { Job } from '../../../data/job';
import { Question } from '../../../data/question';
import { useNextQuestion } from '../../../hooks/useNextQuestion';
import { useOnChange } from '../../../hooks/useOnChange';
import useOnInitialMount from '../../../hooks/useOnInitialMount';
import { useTimeout } from '../../../hooks/useTimeout';
import { useSubmitRecording } from '../../../middleware/useSubmitRecording';
import { APP_PATHS } from '../../../routes/paths';
import { audioState } from '../../../states/audioState';
import { homeButtonClickedState } from '../../../states/header';
import {
  AudioChunksState,
  audioRecorderState,
  questionState,
  questionTypeState,
  selectedCompanyState,
  textAnswerState,
  threadState,
} from '../../../states/recording';
import { VideoRecorder } from './VideoRecorder';

export default function StartAnswering() {
  const navigate = useNavigate();
  const location = useLocation();
  const {
    selectedJob,
    tryAgainOnly = false,
  }: { selectedJob: Job | undefined; tryAgainOnly?: boolean } = location.state;

  const playerDataRef = useRef<{
    willSubmit: boolean;
    willDelete: boolean;
    willPlayNextQuestion: boolean;
    interviewQuestion: Question | undefined;
    cameraEnabled: boolean;
  }>({
    willSubmit: false,
    willDelete: false,
    willPlayNextQuestion: false,
    interviewQuestion: undefined,
    cameraEnabled: false,
  });

  const {
    getNextQuestion,
    question,
    isLoading: isLoadingQuestion,
  } = useNextQuestion();

  const playButtonRef = useRef<{ play: () => void; stop: () => void }>(null);

  const questionType = useRecoilValue(questionTypeState);
  const [homeButtonClicked, setHomeButtonClicked] = useRecoilState(
    homeButtonClickedState
  );

  const [recorderState, setRecorderState] =
    useRecoilState<AudioChunksState>(audioRecorderState);
  const selectedCompany = useRecoilValue(selectedCompanyState);

  const [textAnswer, setTextAnswer] = useRecoilState(textAnswerState);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [answeringStatus, setAnsweringStatus] = useState<
    'initial' | 'recording'
  >('initial');
  const [showQuestion, setShowQuestion] = useState<boolean>(false);
  const threadId = useRecoilValue(threadState);
  const { submitRecording } = useSubmitRecording();
  const currentQuestion = useRecoilValue(questionState);
  // dialog states

  const [selectedInput, setSelectedInput] = useState<
    'video' | 'audio' | 'text'
  >('video');
  const [cameraEnabled, setCameraEnabled] = useState<boolean>(false);
  const { currentTime, duration } = useRecoilValue(audioState);

  const durationInSeconds = isNaN(duration) ? 0 : duration;

  // dialog states

  useOnInitialMount(() => {
    if (!selectedJob) {
      navigate('/');
    }
    amplitude.track('Start Answering');
  });

  useTimeout({
    timeout: 1500,
    callback: () => {
      setIsLoading(false);
    },
  });

  useOnChange({
    value: question?.text,
    defaultValue: undefined,
    onChange: () => {
      playButtonRef.current?.play();
    },
  });

  const memoizedGetNextQuestion = useCallback(
    (stop?: () => void) =>
      getNextQuestion({
        jobId: selectedJob?.id ?? '',
        selectedCompany,
        questionType,
        willMonitorLoadingStatus: true,
        stop,
      }),
    [getNextQuestion, selectedJob, questionType, selectedCompany]
  );

  const onSkipQuestion = useCallback(() => {
    memoizedGetNextQuestion(playButtonRef.current?.stop);
    setAnsweringStatus('initial');
    setShowQuestion(false);
  }, [setShowQuestion, memoizedGetNextQuestion]);

  useOnInitialMount(() => {
    if (question?.text == null) {
      memoizedGetNextQuestion();
    }
  });

  useOnChange({
    value: homeButtonClicked,
    defaultValue: false,
    onChange: () => {
      if (homeButtonClicked && recorderState.state !== 'recording') {
        navigate('/');
        setHomeButtonClicked(false);
      }
    },
  });

  const onSubmitPastedAnswer = useCallback(
    (answer: string) => {
      navigate(APP_PATHS.feedback, {
        state: {
          answer,
          interviewQuestion: playerDataRef.current.interviewQuestion,
          selectedJob,
          type: 'text',
          screenType: 'feedback',
        },
      });
    },
    [navigate, selectedJob, playerDataRef]
  );

  const onSubmitAndNextPastedAnswer = useCallback(
    (answer: string) => {
      submitRecording({
        questionId: currentQuestion?.id ?? '',
        threadId,
        file: undefined,
        type: 'text',
        interviewAnswer: answer,
        jobId: selectedJob?.id ?? '',
      });

      memoizedGetNextQuestion();
      setShowQuestion(false);
      // clean the text answer
      setTextAnswer('');
    },
    [
      submitRecording,
      currentQuestion?.id,
      threadId,
      selectedJob?.id,
      memoizedGetNextQuestion,
      setTextAnswer,
    ]
  );

  const shouldSubmit =
    textAnswer.length > 0 ||
    recorderState.state === 'recording' ||
    recorderState.state === 'paused';

  type IconType = 'Play' | 'Record' | 'Edit' | 'Info';

  const MenuButton = useCallback(
    (props: { selected?: boolean; type: IconType; onClick?: () => void }) => {
      const { selected = false, type, onClick } = props;

      const selectedColor = selected ? 'info' : 'primary';

      const titles: { [key: string]: string } = {
        Play: 'Record video',
        Record: 'Record audio',
        Edit: 'Paste or type answer',
        Info: 'Info',
      };

      const selectedIcon: { [key: string]: JSX.Element } = {
        Play: <VideocamIcon sx={styles.stateIcon} color={selectedColor} />,
        Record: cameraEnabled ? (
          <MicNoneOutlinedIcon sx={styles.stateIcon} color={selectedColor} />
        ) : (
          <VideocamIcon sx={styles.stateIcon} color={selectedColor} />
        ),
        Edit: (
          <BorderColorOutlinedIcon
            sx={styles.stateIcon}
            color={selectedColor}
          />
        ),
        Info: <InfoOutlined sx={styles.stateIcon} color={selectedColor} />,
      };

      return (
        <IconButton
          color="primary"
          onClick={onClick}
          sx={{
            ...styles.iconButton,
            backgroundColor: selected ? 'primary.main' : 'transparent',
          }}
        >
          <Tooltip title={titles[type]}>{selectedIcon[type]}</Tooltip>
        </IconButton>
      );
    },
    [cameraEnabled]
  );

  const header = (
    <Container component="main" maxWidth="xl" sx={styles.container}>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        className="w-full flex-col sm:flex-row"
      >
        <div className="flex-none">
          <IconButton
            color="primary"
            onClick={() => setShowQuestion(prev => !prev)}
          >
            {showQuestion ? (
              <VisibilityOffOutlinedIcon />
            ) : (
              <VisibilityOutlinedIcon />
            )}
          </IconButton>
          <PlayQuestionButton
            ref={playButtonRef}
            interviewQuestion={question?.text ?? ''}
            autoPlay
          />
        </div>
        <div className="hidden sm:grow sm:flex ">
          <div className="flex w-full mx-2 items-center">
            {showQuestion ? (
              <Typography sx={styles.questionText} fontWeight="bold">
                {question?.text}
              </Typography>
            ) : (
              <>
                <div className="flex-none">
                  <Typography sx={styles.questionText} fontWeight="bold">
                    {`${moment
                      .utc(moment.duration(currentTime).asMilliseconds())
                      .seconds(Math.floor(currentTime))
                      .format('mm:ss')}`}
                  </Typography>
                </div>

                <ProgressBar
                  status="play|stop|pause"
                  totalDuration={durationInSeconds}
                  currentPosition={currentTime}
                />
                <div className="flex-none">
                  <Typography sx={styles.questionText} fontWeight="bold">
                    {`${moment
                      .utc(moment.duration(durationInSeconds).asMilliseconds())
                      .seconds(Math.floor(durationInSeconds))
                      .format('mm:ss')}`}
                  </Typography>
                </div>
              </>
            )}
          </div>
        </div>
        <div className="flex-none text-end">
          <Button
            className="!mx-2 inline-block !normal-case "
            color="primary"
            onClick={onSkipQuestion}
            disabled={isLoadingQuestion}
            disableRipple={isLoadingQuestion}
          >
            Skip question
          </Button>
        </div>
        <div className="flex-none text-end">
          <MenuButton
            selected={selectedInput === 'video'}
            type="Play"
            onClick={() => setSelectedInput('video')}
          />
          <MenuButton
            selected={selectedInput === 'audio'}
            type="Record"
            onClick={() => setSelectedInput('audio')}
          />
          <MenuButton
            selected={selectedInput === 'text'}
            type="Edit"
            onClick={() => setSelectedInput('text')}
          />
        </div>
      </Box>
      {showQuestion && (
        <Typography sx={styles.extraText} fontWeight="bold">
          {question?.text}
        </Typography>
      )}
    </Container>
  );

  const buttonBox = (
    <Box display="flex" justifyContent="flex-end" my={2}>
      <>
        {!tryAgainOnly && (
          <Button
            variant="outlined"
            disabled={!shouldSubmit}
            color="primary"
            onClick={() => {
              if (textAnswer.length > 0) {
                onSubmitAndNextPastedAnswer(textAnswer);
              } else {
                playerDataRef.current.willPlayNextQuestion = true;
                recorderState.mediaRecorder?.stop();
                setRecorderState({
                  mediaRecorder: null,
                  state: 'inactive',
                });
              }
            }}
            sx={{
              textTransform: 'none',
              marginLeft: 2,
            }}
            className="!rounded-full !normal-case"
          >
            Next question
          </Button>
        )}
        <Button
          disabled={!shouldSubmit}
          variant={shouldSubmit ? 'contained' : 'outlined'}
          color="primary"
          onClick={() => {
            if (textAnswer.length > 0) {
              onSubmitPastedAnswer(textAnswer);
            } else {
              playerDataRef.current.willSubmit = true;
              recorderState.mediaRecorder?.stop();
              setRecorderState({
                ...recorderState,
                state: 'inactive',
              });
            }
          }}
          className="!rounded-full !normal-case !ml-3"
        >
          View feedback
        </Button>
      </>
    </Box>
  );

  return isLoading || isLoadingQuestion ? (
    <Loading
      title="Generating your questions now... "
      description="To ensure your recording is processed, aim to keep your responses under 8 minutes."
    />
  ) : (
    <MainLayout footer={buttonBox} header={header}>
      <Container component="main" maxWidth="xl" sx={styles.container}>
        <Grid container>
          <Grid item xs={12} sm={12} sx={{ margin: 'auto' }}>
            <VideoRecorder
              setSelectedInput={setSelectedInput}
              selectedInput={selectedInput}
              setCameraEnabled={setCameraEnabled}
              cameraEnabled={cameraEnabled}
              playerDataRef={playerDataRef}
              selectedJob={selectedJob}
              answeringStatus={answeringStatus}
              setAnsweringStatus={setAnsweringStatus}
              questionType={questionType}
              setShowQuestion={setShowQuestion}
              selectedCompany={selectedCompany}
            />
          </Grid>
        </Grid>
      </Container>
    </MainLayout>
  );
}

const styles: { [key: string]: SxProps<Theme> } = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    justifyContent: 'top',
    px: 3,
    paddingTop: 4,
    mt: 1,
    backgroundColor: 'background.paper',
  },
  topBar: {
    borderRadius: 6,
    borderWidth: 1,
    p: 2,
    marginBottom: 2,
  },
  headerContainer: {
    margin: 'auto',
    paddingBottom: 2,
    borderBottom: '1px solid',
    borderColor: 'primary.main',
  },
  question: {
    margin: 'auto',
    paddingX: 2,
    display: {
      xs: 'none',
      sm: 'block',
    },
  },
  extraText: {
    borderTop: '1px solid #00000010',
    marginTop: 2,
    paddingTop: 2,
    display: {
      xs: 'block',
      sm: 'none',
    },
  },
  questionText: {
    display: {
      xs: 'none',
      sm: 'inline-block',
    },
    fontSize: {
      md: '1rem',
      lg: '1.2rem',
    },
  },
  audioBox: {
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 2,
    marginRight: 2,
    display: {
      xs: 'none',
      sm: 'flex',
    },
  },
  iconButton: {
    border: '1px solid',
    borderColor: 'primary.light',
    borderRadius: '5px',
    marginRight: 1,
  },
};
