import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import PauseIcon from '@mui/icons-material/Pause';
import {
  Box,
  IconButton,
  TextField,
  Typography,
  useTheme,
} from '@mui/material';
import moment from 'moment';
import { useNavigate } from 'react-router-dom';
import { useRecoilState, useRecoilValue } from 'recoil';

import { DeleteOutline } from '@mui/icons-material';
import { default as PlayArrowOutlinedIcon } from '@mui/icons-material/PlayArrowOutlined';
import { toast } from 'react-toastify';
import { AnimatedAudio } from '../../../components/AnimatedAudio';
import PIDialog from '../../../components/PIDialog';
import { VideoControlButton } from '../../../components/VideoControlButton';
import { CompanyType } from '../../../data/company';
import { Job } from '../../../data/job';
import { QuestionType } from '../../../data/question';
import { useNextQuestion } from '../../../hooks/useNextQuestion';
import { useOnChange } from '../../../hooks/useOnChange';
import { useSubmitRecording } from '../../../middleware/useSubmitRecording';
import { APP_PATHS } from '../../../routes/paths';
import { homeButtonClickedState } from '../../../states/header';
import {
  AudioChunksState,
  audioRecorderState,
  questionState,
  textAnswerState,
  threadState,
} from '../../../states/recording';
import { isFirefox, isSafari } from '../../../utils/env';

interface Props {
  selectedJob: Job | undefined;
  answeringStatus: 'initial' | 'recording';
  questionType: QuestionType;
  selectedCompany: CompanyType;

  setAnsweringStatus: (status: 'initial' | 'recording') => void;
  setShowQuestion: (visible: boolean) => void;
  selectedInput: 'video' | 'audio' | 'text';
  setCameraEnabled: (enabled: boolean) => void;
  setSelectedInput: (input: 'video' | 'audio' | 'text') => void;
  cameraEnabled: boolean;
  playerDataRef: any;
}

const mimeType = isFirefox()
  ? 'video/webm;codecs=vp8,opus'
  : !isSafari()
  ? 'video/webm;codecs=vp9'
  : 'video/mp4; codecs="avc1.42E01E, mp4a.40.2"';

export function VideoRecorder({
  selectedJob,
  questionType,
  setAnsweringStatus,
  setShowQuestion,
  selectedInput,
  setCameraEnabled,
  cameraEnabled,
  playerDataRef,
  selectedCompany,
}: Props) {
  const theme = useTheme();
  const navigate = useNavigate();
  const { submitRecording } = useSubmitRecording();
  const { question, getNextQuestion } = useNextQuestion();
  const videoPlayerRef = useRef<HTMLVideoElement>(null);
  const videoFileRef = useRef<Blob[]>([]);
  const timerHandlerRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | undefined>(undefined);

  const [recorderState, setRecorderState] =
    useRecoilState<AudioChunksState>(audioRecorderState);

  const [textAnswer, setTextAnswer] = useRecoilState(textAnswerState);

  const [homeButtonClicked, setHomeButtonClicked] = useRecoilState(
    homeButtonClickedState
  );
  const threadId = useRecoilValue(threadState);
  const currentQuestion = useRecoilValue(questionState);

  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [discardAnswerDialogDismissed, setDiscardAnswerDialogDismissed] =
    useState<boolean>(true);

  playerDataRef.current.interviewQuestion = question;

  const formattedTimerText = useMemo(() => {
    const duration = moment.duration(elapsedSeconds, 'seconds');
    const formattedTime = moment.utc(duration.asMilliseconds()).format('mm:ss');

    return formattedTime;
  }, [elapsedSeconds]);

  const onDeleteButtonClicked = useCallback(() => {
    playerDataRef.current.willDelete = true;
    recorderState.mediaRecorder?.stop();
    timerHandlerRef.current && clearInterval(timerHandlerRef.current);
    setElapsedSeconds(0);
    setRecorderState({
      mediaRecorder: null,
      state: 'inactive',
    });
    setAnsweringStatus('initial');

    if (homeButtonClicked) {
      setHomeButtonClicked(false);
      navigate('/');
    }
  }, [
    setAnsweringStatus,
    setElapsedSeconds,
    setRecorderState,
    recorderState,
    homeButtonClicked,
    navigate,
    setHomeButtonClicked,
    playerDataRef,
  ]);

  const startCamera = useCallback(async () => {
    try {
      streamRef.current = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });

      if (videoPlayerRef.current != null) {
        videoPlayerRef.current.srcObject = streamRef.current;
        setCameraEnabled(true);
      }
    } catch (e) {
      toast.error(
        "Practice Interviews needs access to your camera and microphone to use this feature. Should you have previously selected the 'Never for this website' option, please consider manually allowing permissions through your browser settings."
      );
    }
  }, [setCameraEnabled]);

  const startAudio = useCallback(async () => {
    try {
      streamRef.current = await navigator.mediaDevices.getUserMedia({
        audio: true,
      });

      if (videoPlayerRef.current != null) {
        videoPlayerRef.current.srcObject = streamRef.current;
        setCameraEnabled(false);
      }
    } catch (e) {
      toast.error(
        "Practice Interviews needs access to your microphone to use this feature. Should you have previously selected the 'Never for this website' option, please consider manually allowing permissions through your browser settings."
      );
    }
  }, [setCameraEnabled]);

  const startRecording = useCallback(() => {
    if (streamRef.current != null) {
      setAnsweringStatus('recording');
      const recorder = new MediaRecorder(streamRef.current, {
        mimeType: mimeType,
      });
      setRecorderState({
        mediaRecorder: recorder,
        state: 'recording',
      });
      recorder.start();

      timerHandlerRef.current = setInterval(() => {
        setElapsedSeconds(prev => prev + 1);
      }, 1000);
    }
  }, [setRecorderState, setAnsweringStatus, setElapsedSeconds]);

  const pauseRecording = useCallback(() => {
    setRecorderState(prevState => ({
      ...prevState,
      state: 'paused',
    }));
    recorderState.mediaRecorder?.pause();
    timerHandlerRef.current && clearInterval(timerHandlerRef.current);
  }, [recorderState, setRecorderState]);

  const resumeRecording = useCallback(() => {
    setRecorderState(prevState => ({
      ...prevState,
      state: 'recording',
    }));
    if (recorderState.state === 'inactive') {
      recorderState.mediaRecorder?.start();
    } else {
      recorderState.mediaRecorder?.resume();
    }
    timerHandlerRef.current = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
    }, 1000);
  }, [recorderState, setElapsedSeconds, setRecorderState]);

  const onStartPauseButtonClicked = useCallback(() => {
    playerDataRef.current.willDelete = false;

    if (recorderState.state === 'recording') {
      pauseRecording();
    } else if (recorderState.state === 'paused') {
      resumeRecording();
    } else {
      startRecording();
    }
  }, [
    recorderState,
    pauseRecording,
    resumeRecording,
    startRecording,
    playerDataRef,
  ]);

  const dismissDiscardDialog = useCallback(
    (willDismiss: boolean) => {
      setDiscardAnswerDialogDismissed(willDismiss);
      if (!willDismiss && recorderState.state === 'recording') {
        recorderState.mediaRecorder?.pause();
      }
    },
    [setDiscardAnswerDialogDismissed, recorderState]
  );

  useEffect(() => {
    if (recorderState.mediaRecorder === null) {
      timerHandlerRef.current && clearInterval(timerHandlerRef.current);
    }
  }, [recorderState.mediaRecorder]);

  useOnChange({
    value: recorderState.mediaRecorder,
    defaultValue: null,
    onChange: () => {
      if (recorderState.mediaRecorder) {
        recorderState.mediaRecorder.ondataavailable = event => {
          if (playerDataRef.current.willDelete === true) {
            videoFileRef.current = [];
          } else {
            videoFileRef.current.push(event.data);
          }
        };
        recorderState.mediaRecorder.onstop = async () => {
          const videoBlob = new Blob(videoFileRef.current, {
            type: 'audio/wav',
          });
          if (playerDataRef.current.willSubmit === true) {
            recorderState?.mediaRecorder?.stop();
            videoFileRef.current = [];
            navigate(APP_PATHS.feedback, {
              state: {
                blob: videoBlob,
                interviewQuestion: playerDataRef.current.interviewQuestion,
                selectedJob,
                type: playerDataRef.current.cameraEnabled ? 'video' : 'audio',
                screenType: 'feedback',
              },
            });
          } else if (playerDataRef.current.willPlayNextQuestion === true) {
            playerDataRef.current.willPlayNextQuestion = false;
            videoFileRef.current = [];
            submitRecording({
              threadId,
              file: videoBlob,
              type: playerDataRef.current.cameraEnabled ? 'video' : 'audio',
              questionId: currentQuestion?.id ?? '',
              jobId: selectedJob?.id ?? '',
            });
            getNextQuestion({
              jobId: selectedJob?.id ?? '',
              questionType,
              willMonitorLoadingStatus: false,
              selectedCompany: selectedCompany,
            });
            setShowQuestion(false);
            setElapsedSeconds(0);
          }
        };
      }
    },
  });

  useOnChange({
    value: cameraEnabled,
    defaultValue: false,
    onChange: () => {
      playerDataRef.current.cameraEnabled = cameraEnabled;
      if (videoPlayerRef.current != null && streamRef.current) {
        if (cameraEnabled) {
          videoPlayerRef.current.srcObject = streamRef.current;
        } else {
          videoPlayerRef.current.srcObject = null;
        }
      }
    },
  });

  useOnChange({
    value: { homeButtonClicked, recorderState: recorderState.state },
    defaultValue: null,
    onChange: () => {
      if (homeButtonClicked && recorderState.state === 'recording') {
        dismissDiscardDialog(false);
      }
    },
  });

  useEffect(() => {
    setRecorderState({ mediaRecorder: null, state: 'inactive' });
    setTextAnswer('');

    if (selectedInput === 'video') {
      startCamera();
    } else if (selectedInput === 'audio') {
      startAudio();
    }

    return () => {
      if (streamRef.current != null) {
        streamRef.current
          .getTracks() // get all tracks from the MediaStream
          .forEach(track => track.stop()); // stop each of them
      }
      if (recorderState.mediaRecorder != null) {
        recorderState.mediaRecorder.stop();
        recorderState.mediaRecorder.stream
          .getTracks() // get all tracks from the MediaStream
          .forEach(track => track.stop()); // stop each of them
      }

      setRecorderState({ mediaRecorder: null, state: 'inactive' });
      playerDataRef.current = {
        willSubmit: false,
        willDelete: false,
        willPlayNextQuestion: false,
        interviewQuestion: undefined,
        cameraEnabled: false,
      };
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedInput]);

  const isRecording = recorderState.state === 'recording';

  return (
    <Box>
      <Box
        sx={{
          ...styles.selectionContainer,
          backgroundSize: 'cover',
        }}
      >
        <Box
          sx={{
            className: '!z-40',
            backgroundColor: 'rgba(255, 255, 255, 1)',
            padding: 1,
            position: 'absolute',
            bottom: recorderState.mediaRecorder == null ? -100 : 0,
            opacity: recorderState.mediaRecorder == null ? 0 : 1,
            transition: 'all 0.5s',
            width: '100%',
            borderTop: '1px solid rgba(0, 0, 0, 0.1)',
          }}
        >
          <IconButton onClick={() => dismissDiscardDialog(false)}>
            <DeleteOutline color={'primary'} />
          </IconButton>
          <Typography
            sx={{
              display: 'inline-block',
              color: theme.palette.primary.dark,
            }}
          >
            {formattedTimerText}
          </Typography>
          <IconButton onClick={onStartPauseButtonClicked}>
            {isRecording ? (
              <PauseIcon color="primary" />
            ) : (
              <PlayArrowOutlinedIcon color="primary" />
            )}
          </IconButton>
        </Box>
        {selectedInput === 'video' && (
          <Box sx={styles.container}>
            <VideoControlButton
              onStart={onStartPauseButtonClicked}
              isVideo={cameraEnabled}
              text={
                isRecording
                  ? 'Stop recording your answer!'
                  : recorderState.state === 'inactive'
                  ? 'Start recording your answer!'
                  : 'Resume recording your answer!'
              }
              isRecording={isRecording}
            />

            <div
              className={`
                !bg-videoBg
                ${isRecording ? '!bg-opacity-0 z-0' : '!bg-opacity-70 z-10'}
                transition-all
                !w-full
                ${
                  recorderState.mediaRecorder
                    ? '!h-[calc(100%-55px)]'
                    : '!h-full'
                }
                top-0
                !absolute
              `}
            ></div>
            <video
              ref={videoPlayerRef}
              autoPlay
              muted
              playsInline
              style={styles.videoRecorder}
            />
            <Box
              sx={{
                className: '!z-40',
                backgroundColor: 'rgba(255, 255, 255, 1)',
                padding: 1,
                position: 'absolute',
                bottom: recorderState.mediaRecorder == null ? -100 : 0,
                opacity: recorderState.mediaRecorder == null ? 0 : 1,
                transition: 'all 0.5s',
                width: '100%',
              }}
            >
              <IconButton onClick={() => dismissDiscardDialog(false)}>
                <DeleteOutline color={'primary'} />
              </IconButton>
              <Typography
                sx={{
                  display: 'inline-block',
                  color: theme.palette.primary.dark,
                }}
              >
                {formattedTimerText}
              </Typography>
              <IconButton onClick={onStartPauseButtonClicked}>
                {isRecording ? (
                  <PauseIcon color="primary" />
                ) : (
                  <PlayArrowOutlinedIcon color="primary" />
                )}
              </IconButton>
            </Box>
          </Box>
        )}
        {selectedInput === 'audio' && (
          <Box
            sx={{
              ...styles.container,
              backgroundColor: 'rgba(255, 255, 255, 1)',
            }}
          >
            <VideoControlButton
              onStart={onStartPauseButtonClicked}
              isVideo={false}
              text={
                isRecording
                  ? 'Stop recording your answer!'
                  : recorderState.state === 'inactive'
                  ? 'Start recording your answer!'
                  : 'Resume recording your answer!'
              }
              isRecording={isRecording}
            />
            <Box
              sx={{
                paddingTop: 18,
              }}
            >
              <AnimatedAudio
                isPlaying={isRecording}
                maxHeight={40}
                length={40}
              />
            </Box>
          </Box>
        )}
        {selectedInput === 'text' && (
          <Box
            sx={{
              ...styles.container,
              justifyContent: 'flex-start',
              backgroundColor: 'rgba(255, 255, 255, 1)',
            }}
          >
            <TextField
              autoFocus
              id="name"
              label="Answer"
              type="text"
              multiline
              fullWidth
              variant="standard"
              value={textAnswer}
              onChange={e => setTextAnswer(e.target.value)}
              sx={styles.answerInput}
              InputProps={{
                disableUnderline: true, // <== added this
              }}
            />
          </Box>
        )}
      </Box>

      <PIDialog
        title="Discard"
        description="Are you sure you want to discard your answer?"
        open={!discardAnswerDialogDismissed}
        onClose={() => dismissDiscardDialog(true)}
        buttons={[
          {
            text: 'Cancel',
            onPress: () => {
              playerDataRef.current = {
                ...playerDataRef.current,
                willSubmit: false,
                willDelete: false,
                willPlayNextQuestion: false,
              };
              setHomeButtonClicked(false);
            },
          },
          { text: 'Discard and try again', onPress: onDeleteButtonClicked },
        ]}
      />
    </Box>
  );
}

const styles: { [key: string]: any } = {
  container: {
    display: 'flex',
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
    minHeight: `calc(100vh - 320px)`,
    backgroundColor: 'rgba(0, 0, 0, 1)',
  },

  stateIcon: {
    ':hover': {
      color: 'primary.main',
    },
  },
  selectionContainer: {
    borderRadius: 3,
    overflow: 'hidden',
    border: '1px solid',
    borderColor: 'primary.light',
    width: '100%',
    position: 'relative',
  },
  answerInput: {
    overflowY: 'auto',
    maxHeight: `calc(100vh - ${300}px)`,
    marginLeft: 3,
    marginTop: 1,
  },
  videoRecorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    objectFit: 'contain',
    objectPosition: '50% 50%',
    height: `100%`,
  },
};
