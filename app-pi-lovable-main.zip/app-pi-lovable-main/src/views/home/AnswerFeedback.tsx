import {
  DeleteOutline,
  InfoOutlined,
  MoreVertOutlined,
} from '@mui/icons-material';
import CallMadeIcon from '@mui/icons-material/CallMade';
import ReplayIcon from '@mui/icons-material/Replay';
import {
  Box,
  Button,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  TextField,
  Tooltip,
  Typography,
  useTheme,
} from '@mui/material';
import { orderBy } from 'lodash';
import moment from 'moment';
import { MouseEvent, useCallback, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useSetRecoilState } from 'recoil';
import { CircularProgressWithLabel } from '../../components/CircularProgressWithLabel';
import { Loading } from '../../components/Loading';
import { MainLayout } from '../../components/MainLayout';
import OptionMenu from '../../components/OptionMenu';
import PIDialog from '../../components/PIDialog';
import { AnswerFeedback } from '../../data/answerFeedback';
import { Job } from '../../data/job';
import { useOnChange } from '../../hooks/useOnChange';
import { useAnswerFeedback } from '../../middleware/useAnswerFeedback';
import { useDeleteAnswer } from '../../middleware/useDeleteAnswer';
import { useJobById } from '../../middleware/useJobById';
import { APP_PATHS } from '../../routes/paths';
import { questionState } from '../../states/recording';

interface Column {
  id:
    | 'no'
    | 'question'
    | 'type'
    | 'createdAt'
    | 'companyName'
    | 'length'
    | 'score'
    | 'jobTitle';
  label: string;
  minWidth?: number;
  align?: 'left' | 'center' | 'right';
  format?: (value: number) => string;
}

const columns: readonly Column[] = [
  { id: 'no', label: 'No', minWidth: 70, align: 'center' },
  { id: 'question', label: 'Question', minWidth: 270 },
  {
    id: 'type',
    label: 'Type',
    align: 'center',
  },
  {
    id: 'jobTitle',
    label: 'Job',
    align: 'center',
  },
  {
    id: 'companyName',
    label: 'Company',
    align: 'center',
  },
  {
    id: 'createdAt',
    label: 'Date',
    minWidth: 150,
  },
  {
    id: 'length',
    label: 'Length',
    align: 'center',
  },
  {
    id: 'score',
    label: 'Score',
    align: 'center',
    format: (value: number) => value.toLocaleString('en-US'),
  },
];

export default function AnswerFeedbackPage() {
  const navigate = useNavigate();

  let [searchParams, setSearchParams] = useSearchParams();
  const theme = useTheme();
  const setCurrentQuestion = useSetRecoilState(questionState);
  const {
    feedbacks,
    refetch: fetchFeedbackCount,
    isLoading: isFetchingAnswerFeedbacks,
  } = useAnswerFeedback(true);
  const deleteAnswer = useDeleteAnswer();
  const fetchJob = useJobById();
  const selectedFeedbackRef = useRef<AnswerFeedback>(null);

  const [deleteDialogInfo, setDeleteDialogInfo] = useState<{
    modalVisible: boolean;
    selectedAnswerId: string;
  }>();

  const deleteAnswerRow = useCallback(() => {
    deleteAnswer.mutate({ answerId: deleteDialogInfo?.selectedAnswerId ?? '' });
  }, [deleteAnswer, deleteDialogInfo]);

  const onStartPracticing = useCallback(() => {
    navigate(APP_PATHS.selectJobTitle);
  }, [navigate]);
  const showFeedback = useCallback(
    (selectedJob?: Job) => {
      if (selectedFeedbackRef.current != null) {
        const type =
          selectedFeedbackRef.current.videoUrl != null
            ? 'video'
            : selectedFeedbackRef.current.audioUrl != null
            ? 'audio'
            : 'text';
        navigate(APP_PATHS.feedback, {
          state: {
            answerId: selectedFeedbackRef.current.id,
            from: 'answerFeedback', // We need to know if the user is coming from the answer feedback page
            interviewQuestion: selectedFeedbackRef.current.question,
            transcription: selectedFeedbackRef.current.answer,
            feedback: selectedFeedbackRef.current.feedback ?? '',
            type: type,
            screenType: 'summary-detail',
            selectedJob,
            scoreResult: selectedFeedbackRef.current.scoreDetail,
            s3Url:
              type === 'video'
                ? selectedFeedbackRef.current.videoUrl
                : type === 'audio'
                ? selectedFeedbackRef.current.audioUrl
                : null,
          },
        });
      }
    },
    [navigate]
  );

  const showSummaryDetail = useCallback(
    (index: number) => {
      if (feedbacks.length > 0) {
        selectedFeedbackRef.current = feedbacks[index];
        if (selectedFeedbackRef.current.question.jobId == null) {
          showFeedback(undefined);
        } else {
          fetchJob.mutate({ id: selectedFeedbackRef.current.question.jobId });
        }
      }
    },
    [feedbacks, fetchJob, showFeedback]
  );

  const rows = useMemo(() => {
    return feedbacks.map((attempt, index) => {
      return {
        no: index + 1,
        question: attempt.question.text,
        type:
          attempt.question.questionType === 'hypothetical'
            ? 'Hypothetical'
            : attempt.question.questionType === 'common'
            ? 'Common'
            : 'Behavioral',
        jobTitle: attempt.question.job?.title ?? attempt.job?.title,
        jobDescription: attempt.question.job?.description,
        companyName: attempt.question.job?.companyName ?? '---',
        createdAt: attempt.createdAt,
        length: !attempt.recordingLength
          ? '---'
          : moment.utc(attempt.recordingLength * 1000).format('mm:ss'),
        score: { total: attempt.score, score: attempt.scoreDetail },
      };
    });
  }, [feedbacks]);

  useOnChange({
    value: deleteAnswer.isSuccess,
    defaultValue: false,
    onChange: fetchFeedbackCount,
  });

  useOnChange({
    value: fetchJob.data,
    defaultValue: undefined,
    onChange: () => {
      const selectedJob = fetchJob.data?.data.data;
      showFeedback(selectedJob);
    },
  });

  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const open = Boolean(anchorEl);
  const sortId = (searchParams.get('sortId') as Column['id']) ?? 'no';
  const sortDirection =
    (searchParams.get('sortDirection') as 'asc' | 'desc') ?? 'asc';
  const [openJobDescription, setOpenJobDescription] = useState(false);

  const handlePopoverOpen = (event: MouseEvent<HTMLElement>, index: number) => {
    setAnchorEl(event.currentTarget);
    setSelectedIndex(index);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const filteredRows = useMemo(() => {
    const sortConcept = sortId === 'score' ? 'score.total' : sortId;
    return orderBy(rows, [sortConcept], [sortDirection]);
  }, [rows, sortId, sortDirection]);

  //options components
  const optionCell = (
    <OptionMenu open={open} anchorEl={anchorEl} onClose={handlePopoverClose}>
      <List>
        <ListItem>
          <ListItemButton
            onClick={() => {
              handlePopoverClose();
              setCurrentQuestion(feedbacks[selectedIndex].question);
              showSummaryDetail(selectedIndex);
            }}
          >
            <ListItemText primary="Feedback" />
            <ListItemIcon
              sx={{
                '&, & .MuiListItemIcon-root': {
                  minWidth: 0,
                },
              }}
            >
              <CallMadeIcon color="action" />
            </ListItemIcon>
          </ListItemButton>
        </ListItem>
        <ListItem>
          <ListItemButton
            onClick={() => {
              handlePopoverClose();
              setCurrentQuestion(feedbacks[selectedIndex].question);
              navigate(APP_PATHS.startAnswering, {
                state: {
                  selectedJob: feedbacks[selectedIndex].question.jobId
                    ? {
                        id: feedbacks[selectedIndex].question.jobId,
                      }
                    : feedbacks[selectedIndex].job ?? { id: '' },
                },
              });
            }}
          >
            <ListItemText primary="Try again" />
            <ListItemIcon
              sx={{
                '&, & .MuiListItemIcon-root': {
                  minWidth: 0,
                },
              }}
            >
              <ReplayIcon color="action" />
            </ListItemIcon>
          </ListItemButton>
        </ListItem>

        <ListItem>
          <ListItemButton
            onClick={() => {
              handlePopoverClose();
              setOpenJobDescription(true);
            }}
          >
            <ListItemText primary="Job description" />
            <ListItemIcon
              sx={{
                '&, & .MuiListItemIcon-root': {
                  minWidth: 0,
                  marginLeft: 4,
                },
              }}
            >
              <InfoOutlined color="action" />
            </ListItemIcon>
          </ListItemButton>
        </ListItem>

        <ListItem>
          <ListItemButton
            onClick={() => {
              handlePopoverClose();
              setDeleteDialogInfo({
                modalVisible: true,
                selectedAnswerId: feedbacks[selectedIndex].id,
              });
            }}
            style={{
              alignItems: 'space-between',
            }}
          >
            <ListItemText primary="Delete" />
            <ListItemIcon
              sx={{
                '&, & .MuiListItemIcon-root': {
                  minWidth: 0,
                },
              }}
            >
              <DeleteOutline color="action" />
            </ListItemIcon>
          </ListItemButton>
        </ListItem>
      </List>
    </OptionMenu>
  );

  const jobDialog = (
    <PIDialog
      title={feedbacks[selectedIndex]?.question.job?.title || ''}
      node={
        <>
          <TextField
            id="description"
            label="Job title"
            type="text"
            disabled
            fullWidth
            multiline
            rows={1}
            variant="outlined"
            InputLabelProps={{ shrink: true }}
            defaultValue={feedbacks[selectedIndex]?.question.job?.title || ''}
            sx={{
              '& .MuiInputBase-input.Mui-disabled': {
                WebkitTextFillColor: '#000000',
              },
              marginTop: 4,
            }}
          />
          <TextField
            id="description"
            label="Job Description"
            type="text"
            disabled
            fullWidth
            multiline
            rows={8}
            variant="outlined"
            InputLabelProps={{ shrink: true }}
            defaultValue={
              feedbacks[selectedIndex]?.question.job?.description || ''
            }
            sx={{
              '& .MuiInputBase-input.Mui-disabled': {
                WebkitTextFillColor: '#000000',
              },
              marginTop: 4,
            }}
          />
        </>
      }
      open={openJobDescription}
      onClose={() => setOpenJobDescription(false)}
      buttons={[
        {
          text: 'Ok',
          onPress: () => setOpenJobDescription(false),
        },
      ]}
    />
  );

  const deleteDialog = (
    <PIDialog
      title="Delete answer"
      description="Are you sure you want to delete this answer and feedback? This action cannot be undone."
      open={!!deleteDialogInfo?.modalVisible}
      onClose={() => {
        setDeleteDialogInfo(undefined);
      }}
      buttons={[
        {
          text: 'Cancel',
          color: theme.palette.grey.A700,
        },
        {
          text: 'Delete',
          color: theme.palette.error.main,
          onPress: () => deleteAnswerRow(),
        },
      ]}
    />
  );

  return (
    <MainLayout>
      <div className="flex flex-col transition-all">
        {isFetchingAnswerFeedbacks ? (
          <Loading title="Loading..." className="h-96" />
        ) : (
          <div>
            <Typography variant="h4" gutterBottom className="!font-bold">
              Answer Feedback
            </Typography>

            {feedbacks.length === 0 ? (
              <Box>
                <Typography gutterBottom my={4}>
                  Looks like you haven’t completed any interview questions yet.
                  Start practicing now to get some feedback!
                </Typography>
                <Button
                  variant="contained"
                  onClick={onStartPracticing}
                  style={{ textTransform: 'none' }}
                >
                  Start practicing
                </Button>
              </Box>
            ) : (
              <Paper sx={styles.paper}>
                <TableContainer sx={styles.tableContainer}>
                  <Table stickyHeader aria-label="sticky table">
                    <TableHead>
                      <TableRow>
                        {columns.map(column => (
                          <TableCell
                            key={column.id}
                            align={column.align}
                            style={{ minWidth: column.minWidth }}
                            sortDirection={sortDirection}
                          >
                            <TableSortLabel
                              active={sortId === column.id}
                              direction={sortDirection}
                              onClick={() => {
                                setSearchParams({
                                  sortId: column.id,
                                  sortDirection:
                                    sortId === column.id
                                      ? sortDirection === 'asc'
                                        ? 'desc'
                                        : 'asc'
                                      : 'asc',
                                });
                              }}
                            >
                              {column.label}
                            </TableSortLabel>
                          </TableCell>
                        ))}

                        <TableCell key="nav" align="center">
                          {/* Empty label, used for options */}
                        </TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {filteredRows.map((row, index) => {
                        return (
                          <TableRow
                            hover
                            role="checkbox"
                            tabIndex={-1}
                            key={row.no}
                          >
                            {columns.map(column => {
                              const value = row[column.id as keyof typeof row];
                              const date = moment(
                                value as string | number
                              ).format('hh:mm A, DD MMM YYYY');
                              return (
                                <TableCell key={column.id} align={column.align}>
                                  {column.id === 'createdAt' ? (
                                    <Typography>{date}</Typography>
                                  ) : column.id === 'type' ? (
                                    <Tooltip title={value as string} arrow>
                                      <Typography sx={{ cursor: 'pointer' }}>
                                        {value as string}
                                      </Typography>
                                    </Tooltip>
                                  ) : column.id === 'score' ? (
                                    <CircularProgressWithLabel
                                      total={(value as any)?.total}
                                      score={(value as any)?.score}
                                      defaultValue={0}
                                    />
                                  ) : column.format &&
                                    typeof value === 'number' ? (
                                    column.format(value)
                                  ) : (
                                    <Typography>{value as any}</Typography>
                                  )}
                                </TableCell>
                              );
                            })}

                            <TableCell key="nav">
                              <IconButton
                                aria-owns={
                                  open ? 'mouse-over-popover' : undefined
                                }
                                onClick={e => handlePopoverOpen(e, index)}
                              >
                                <MoreVertOutlined color="action" />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Paper>
            )}
          </div>
        )}
        {optionCell}
        {jobDialog}
        {deleteDialog}
      </div>
    </MainLayout>
  );
}

const styles: { [key: string]: any } = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'top',
    px: 3,
    paddingTop: 4,
    mb: 2,
  },
  doneButton: {
    height: 40,
  },
  paper: {
    borderWidth: 20,
    borderColor: '#F5F5F5',
    borderRadius: 5,
    overflow: 'hidden',
  },
  tableContainer: {
    mb: 2,
  },
};
