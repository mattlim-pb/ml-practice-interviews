import { Box, Container, Grid, Typography } from '@mui/material';
import moment from 'moment';
import { useMemo } from 'react';
import AverageChart from '../../components/Charts/AverageChart';
import QuestionChart from '../../components/Charts/QuestionChart';
import TopPerformers from '../../components/Charts/TopPerformers';
import { Loading } from '../../components/Loading';
import { MainLayout } from '../../components/MainLayout';
import { ScoreBarChart } from '../../components/ScoreBarChart';
import useOnInitialMount from '../../hooks/useOnInitialMount';
import { useAnalytics } from '../../middleware/useAnalytics';

const transformResponse = (resData: Array<any>) => {
  return resData.map(rd => {
    return {
      label: Object.keys(rd)?.[0],
      value: Math.floor(rd?.[Object.keys(rd)?.[0]]),
    };
  });
};

export default function Analytics() {
  const {
    mutate: getAnalytics,
    data: ananlyticsResponse,
    isLoading,
  } = useAnalytics();

  const scores = useMemo(() => {
    const overallAnalytics = transformResponse(
      ananlyticsResponse?.data.data.overall ?? []
    );
    const behavioralAnalytics = transformResponse(
      ananlyticsResponse?.data.data.behavioral ?? []
    );
    const hypotheticalAnalytics = transformResponse(
      ananlyticsResponse?.data.data.hypothetical ?? []
    );
    return {
      overall: overallAnalytics,
      behavioral: behavioralAnalytics,
      hypothetical: hypotheticalAnalytics,
    };
  }, [ananlyticsResponse]);

  useOnInitialMount(() => {
    getAnalytics({
      filter: {
        dateRange: [moment().subtract(4, 'weeks').toDate(), moment().toDate()],
      },
    });
  });

  const {
    questionsAttempted = {},
    leaderboard = [],
    averageScore = {
      behavioral: { everyone: 0, you: 0 },
      hypothetical: { everyone: 0, you: 0 },
    },
  } = ananlyticsResponse?.data.data ?? {};
  return (
    <MainLayout>
      <Container component="main" maxWidth="xl">
        <Grid item xs={10} sm={8} md={6}>
          <Typography variant="h5" gutterBottom className="!mb-8 !mt-5">
            <b>Dashboard</b>
          </Typography>

          {isLoading ? (
            <Loading title="Loading analytics data..." />
          ) : (
            <>
              <Box
                className={` mb-16 flex flex-col content-center items-left bg-slate-200 rounded-2xl`}
              >
                <div className="flex flex-col lg:flex-row  content-center items-left">
                  <div className="lg:w-1/2 w-full">
                    <div className=" bg-white rounded-xl m-2 mt-2 mr-1">
                      <AverageChart data={averageScore} />
                    </div>
                  </div>
                  <div className="lg:w-1/2 w-full">
                    <div className=" bg-white rounded-xl m-2 ml-1">
                      <TopPerformers data={leaderboard} />
                    </div>
                  </div>
                </div>

                {/* ROW */}
                <div className="flex flex-row content-center items-left">
                  <div className="w-full">
                    <div className=" bg-white rounded-xl m-2 mt-2 mr-2">
                      <QuestionChart data={questionsAttempted} />
                    </div>
                  </div>
                </div>
                {/* ROW */}
                {/*

                Will be used in future releases

                <div className="flex flex-row content-center items-left">
                  <div className="w-full">
                    <div className=" bg-white rounded-xl m-2 mt-2 mr-2">
                      <div className="bg-fit bg-no-repeat bg-center w-full p-2 rounded-xl">
                        <Typography
                          variant="h6"
                          className="!font-bold !m-0 !ml-4 !inline-block"
                        >
                          Select your date range
                        </Typography>
                        <DateRangePicker
                          value={dateRange}
                          onChange={newValue => {
                            setDateRange(newValue);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div> */}
                {/* ROW */}
                <div className="flex flex-row content-center items-left">
                  <div className="w-full">
                    <div className=" bg-white rounded-xl m-2 mt-2 mr-2">
                      <div className="bg-fit bg-no-repeat bg-center w-full h-96 rounded-xl p-4">
                        <Typography
                          variant="h6"
                          className="!font-bold !m-0 !ml-2 !inline-block"
                        >
                          Average Behavioral Interview Score
                        </Typography>
                        {scores?.behavioral.length > 0 && (
                          <ScoreBarChart
                            dataset={scores?.behavioral}
                            legendLabel=""
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                {/* ROW */}

                {/* ROW */}
                <div className="flex flex-row content-center items-left">
                  <div className="w-full">
                    <div className=" bg-white rounded-xl m-2 mt-2 mr-2">
                      <div className="bg-fit bg-no-repeat bg-center w-full h-96 rounded-xl p-4">
                        <Typography
                          variant="h6"
                          className="!font-bold !m-0 !ml-2 !inline-block"
                        >
                          Average Hypothetical Interview Score
                        </Typography>
                        {scores?.hypothetical.length > 0 && (
                          <ScoreBarChart
                            dataset={scores?.hypothetical}
                            legendLabel=""
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </Box>
            </>
          )}
        </Grid>
      </Container>
    </MainLayout>
  );
}
