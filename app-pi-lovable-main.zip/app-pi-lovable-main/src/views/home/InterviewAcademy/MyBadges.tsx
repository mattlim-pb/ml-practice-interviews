import { Box, Typography, useMediaQuery, useTheme } from '@mui/material';
import emptyBadgeImage from '../../../assets/images/badge-empty.png';

interface Badge {
  title: string;
  description: string;
  imageUrl: string | null;
}

interface MyBadgesProps {
  showWaitlist: boolean;
}

export function MyBadges({ showWaitlist }: MyBadgesProps) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));
  // Use waitlistBadges if showWaitlist is true, otherwise use the regular badges
  const displayedBadges = showWaitlist ? waitlistBadges : badges;

  // Calculate the number of unlocked badges (i.e. badges with a non-null imageUrl)
  const unlockedCount = displayedBadges.filter(
    badge => badge.imageUrl !== null
  ).length;

  // Determine grid columns based on screen size
  const gridColumns = isMobile ? 2 : isTablet ? 3 : 3;
  // Adjust image size based on screen size
  const imageSize = isMobile ? 56 : isTablet ? 70 : 80;

  return (
    <Box
      sx={{
        backgroundColor: theme.interviewAcademy.secondaryLight,
        borderRadius: '12px',
        pt: { xs: 2, sm: 3, md: 4 },
        pb: { xs: 1, sm: 2, md: 3 },
        px: { xs: 1, sm: 2, md: 2 },
        display: 'flex',
        flexDirection: 'column',
        gap: { xs: 1, sm: 1.5, md: 2 },
        height: '100%',
      }}
    >
      {/* Header with Title and Badge Count */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'flex-start',
          alignItems: 'center',
          gap: { xs: 1, sm: 1.5 },
          px: { xs: 1, sm: 2, md: 3 },
        }}
      >
        <Typography
          variant="h6"
          sx={{
            fontWeight: 700,
            fontSize: { xs: '15px', sm: '16px', md: '18px' },
            color: '#4D4D4F',
          }}
        >
          My Badges
        </Typography>
        <Typography
          variant="body1"
          sx={{
            fontSize: { xs: '13px', sm: '14px', md: '16px' },
            lineHeight: '24px',
            color: '#9d9ca3',
          }}
        >
          ({unlockedCount}/{displayedBadges.length})
        </Typography>
      </Box>

      {/* Scrollable Badge Grid */}
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: `repeat(${gridColumns}, 1fr)`,
          gap: { xs: 1, sm: 1.5, md: 2 },
          overflowY: 'auto',
          pb: 2,
          px: 'auto',
          mb: 2,
          flexGrow: 1,
          height: '100px',
          scrollbarWidth: 'thin',
          '&::-webkit-scrollbar': {
            width: '6px',
          },
          '&::-webkit-scrollbar-thumb': {
            backgroundColor: '#c1c1c1',
            borderRadius: '3px',
          }
        }}
      >
        {displayedBadges.map((badge, index) => (
          <Box
            key={index}
            sx={{
              py: { xs: 1, sm: 1.5 },
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
            }}
          >
            <img
              src={badge.imageUrl || emptyBadgeImage}
              alt={badge.title}
              style={{
                width: `${imageSize}px`,
                height: `${imageSize}px`,
                marginBottom: '4px',
              }}
            />
            <Typography
              variant="subtitle1"
              sx={{
                fontWeight: 600,
                fontSize: { xs: '11px', sm: '12px', md: '14px' },
                color: theme.interviewAcademy.black,
                textAlign: 'center',
                mb: 0.5,
                px: 0.5,
              }}
            >
              {badge.title}
            </Typography>
            <Typography
              variant="body2"
              sx={{
                fontWeight: 600,
                fontSize: { xs: '9px', sm: '10px', md: '12px' },
                color: '#9198a3',
                textAlign: 'center',
                display: '-webkit-box',
                WebkitLineClamp: 2,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden',
                px: 0.5,
              }}
            >
              {badge.description}
            </Typography>
          </Box>
        ))}
      </Box>
    </Box>
  );
}

const waitlistBadges: Badge[] = [
  {
    title: 'Ahead of the Pack',
    description: '???',
    imageUrl: null,
  },
  {
    title: 'Interview Apprentice',
    description: '???',
    imageUrl: null,
  },
  {
    title: 'Interview Explorer',
    description: '???',
    imageUrl: null,
  },
  {
    title: 'Behavioral Apprentice',
    description: '???',
    imageUrl: null,
  },
  {
    title: 'Strategic Apprentice',
    description: '???',
    imageUrl: null,
  },
  {
    title: 'Interview Challenger',
    description: '???',
    imageUrl: null,
  },
];

// TODO: Replace this with data from API
const badges: Badge[] = [
  {
    title: 'Bronze',
    description: 'Place top 3 in the leaderboard',
    imageUrl:
      'https://res.cloudinary.com/oblaka/image/upload/v1740603914/badge-01_uvfjqq.png',
  },
  {
    title: 'Almost Perfect',
    description: 'Score 90% or above',
    imageUrl:
      'https://res.cloudinary.com/oblaka/image/upload/v1740603914/badge-02_vskyqq.png',
  },
  {
    title: 'Badge 3',
    description: 'Sed do eiusmod',
    imageUrl: null,
  },
  {
    title: 'Badge 4',
    description: 'Tempor incididunt ut',
    imageUrl: null,
  },
  {
    title: 'Badge 5',
    description: 'Labore et dolore',
    imageUrl: null,
  },
  {
    title: 'Badge 6',
    description: 'Magna aliqua ut',
    imageUrl: null,
  },
  {
    title: 'Badge 7',
    description: 'Enim ad minim',
    imageUrl: null,
  },
  {
    title: 'Badge 8',
    description: 'Veniam quis nostrud',
    imageUrl: null,
  },
  {
    title: 'Badge 9',
    description: 'Exercitation ullamco laboris',
    imageUrl: null,
  },
  {
    title: 'Badge 10',
    description: 'Nisi ut aliquip',
    imageUrl: null,
  },
  {
    title: 'Badge 11',
    description: 'Ex ea commodo',
    imageUrl: null,
  },
  {
    title: 'Badge 12',
    description: 'Consequat duis aute',
    imageUrl: null,
  },
  {
    title: 'Badge 13',
    description: 'Irure dolor in',
    imageUrl: null,
  },
  {
    title: 'Badge 14',
    description: 'Reprehenderit in voluptate',
    imageUrl: null,
  },
  {
    title: 'Badge 15',
    description: 'Velit esse cillum',
    imageUrl: null,
  },
  {
    title: 'Badge 16',
    description: 'Dolore eu fugiat',
    imageUrl: null,
  },
  {
    title: 'Badge 17',
    description: 'Nulla pariatur excepteur',
    imageUrl: null,
  },
  {
    title: 'Badge 18',
    description: 'Sint occaecat cupidatat',
    imageUrl: null,
  },
  {
    title: 'Badge 19',
    description: 'Non proident sunt',
    imageUrl: null,
  },
  {
    title: 'Badge 20',
    description: 'In culpa officia',
    imageUrl: null,
  },
  {
    title: 'Badge 21',
    description: 'Deserunt mollit anim',
    imageUrl: null,
  },
  {
    title: 'Badge 22',
    description: 'Id est laborum',
    imageUrl: null,
  },
  {
    title: 'Badge 23',
    description: 'Curabitur pretium tincidunt',
    imageUrl: null,
  },
  {
    title: 'Badge 24',
    description: 'Nullam porttitor lacus',
    imageUrl: null,
  },
  {
    title: 'Badge 25',
    description: 'Aenean vehicula urna',
    imageUrl: null,
  },
  {
    title: 'Badge 26',
    description: 'In tempus sapien',
    imageUrl: null,
  },
  {
    title: 'Badge 27',
    description: 'Vestibulum ante ipsum',
    imageUrl: null,
  },
  {
    title: 'Badge 28',
    description: 'Primis in faucibus',
    imageUrl: null,
  },
  {
    title: 'Badge 29',
    description: 'Orci luctus et',
    imageUrl: null,
  },
  {
    title: 'Badge 30',
    description: 'Ultrices posuere cubilia',
    imageUrl: null,
  },
  {
    title: 'Badge 31',
    description: 'Curae pellentesque habitant',
    imageUrl: null,
  },
  {
    title: 'Badge 32',
    description: 'Morbi tristique senectus',
    imageUrl: null,
  },
  {
    title: 'Badge 33',
    description: 'Et netus et',
    imageUrl: null,
  },
  {
    title: 'Badge 34',
    description: 'Malesuada fames ac',
    imageUrl: null,
  },
  {
    title: 'Badge 35',
    description: 'Turpis egestas integer',
    imageUrl: null,
  },
  {
    title: 'Badge 36',
    description: 'Accumsan sit amet',
    imageUrl: null,
  },
  {
    title: 'Badge 37',
    description: 'Justo laoreet sit',
    imageUrl: null,
  },
  {
    title: 'Badge 38',
    description: 'Donec ullamcorper nulla',
    imageUrl: null,
  },
  {
    title: 'Badge 39',
    description: 'Velit euismod in',
    imageUrl: null,
  },
  {
    title: 'Badge 40',
    description: 'Bibendum augue quam',
    imageUrl: null,
  },
  {
    title: 'Badge 41',
    description: 'Sed fringilla mauris',
    imageUrl: null,
  },
  {
    title: 'Badge 42',
    description: 'Quisque rutrum a',
    imageUrl: null,
  },
];
