export interface Step {
  id: number;
  title: string;
  description: string;
  objective: string;
  instructions: string;
  componentType: 'VideoStep' | 'RateMySetupStep' | string;
}

// The steps data for the academy level
export const levelSteps: Step[] = [
  {
    id: 1,
    title: 'Instructional Videos',
    description:
      'Interview preparation basics, such as research, stress management, and professional setup.',
    objective:
      'Build a strong foundation for interviews by learning best practices.',
    instructions: 'Watch the following videos to learn interview basics.',
    componentType: 'VideoStep',
  },
  {
    id: 2,
    title: 'Rate My Setup',
    description:
      'AI evaluates camera, audio, and environment, providing real-time feedback.',
    objective:
      'You’re a product of your environment! Make sure yours is optimized for your interviews.',
    instructions:
      'Smile! Take a picture of you in your interview set up to get immediate feedback and tips!',
    componentType: 'RateMySetupStep',
  },
];
