import { Box } from '@mui/material';
import { useState } from 'react';
import { StepFooter } from '../../../components/StepFooter';
import { TwoColumnLayout } from '../../../components/TwoColumnLayout';
import { YouTubeThumbnail } from '../../../components/YoutubeThumbnail';
import { videoContent } from '../../../data/constants';

interface VideoStepProps {
  onSkipStep?: () => void;
}

export default function VideoStep({ onSkipStep }: VideoStepProps) {
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const currentVideo = videoContent[currentVideoIndex];
  const isFirstVideo = currentVideoIndex === 0;
  const isLastVideo = currentVideoIndex === videoContent.length - 1;

  const handlePreviousVideo = () => {
    if (!isFirstVideo) {
      setCurrentVideoIndex(currentVideoIndex - 1);
    }
  };

  const handleNextVideo = () => {
    if (!isLastVideo) {
      setCurrentVideoIndex(currentVideoIndex + 1);
    }
  };

  const handleSkipStep = () => {
    if (onSkipStep) {
      onSkipStep();
    }
  };

  return (
    <>
      {/* Step Content */}
      <Box
        sx={{
          flex: 1,
          marginY: 2,
        }}
      >
        <TwoColumnLayout
          title={`Video ${currentVideoIndex + 1} of ${videoContent.length}: ${
            currentVideo.title
          }`}
          duration="(2 minutes)"
          leftContent={
            <YouTubeThumbnail videoUrl={currentVideo.url} plain={true} />
          }
          texts={[
            { Summary: currentVideo.summary },
            { Transcript: currentVideo.transcript },
          ]}
        />
      </Box>

      <StepFooter
        leftButton={{
          text: 'Skip Step',
          onClick: handleSkipStep,
        }}
        rightButtons={[
          {
            text: '< Previous Video',
            onClick: handlePreviousVideo,
            disabled: isFirstVideo,
          },
          {
            text: 'Next Video >',
            onClick: handleNextVideo,
            disabled: isLastVideo,
          },
        ]}
      />
    </>
  );
}
