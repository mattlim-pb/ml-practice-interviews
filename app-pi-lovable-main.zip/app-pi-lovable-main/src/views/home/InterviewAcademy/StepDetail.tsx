import { Box, Divider, Typography } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import moduleCompleted from '../../../assets/images/moduleCompleted.png';
import moduleInProgress from '../../../assets/images/moduleInProgress.png';
import moduleNotStarted from '../../../assets/images/moduleNotStarted.png';
import RateMySetupStep from './RateMySetupStep';
import { Step } from './stepData';
import VideoStep from './VideoStep';

interface StepDetailProps {
  currentStepIndex: number;
  onNextStep?: () => void;
  steps: Step[];
  status?: 'Not Started' | 'In Progress' | 'Completed';
}

export default function StepDetail({
  currentStepIndex,
  onNextStep,
  steps,
  status = 'Not Started',
}: StepDetailProps) {
  const theme = useTheme();
  const currentStep = steps[currentStepIndex];

  // Determine the step status dynamically if not explicitly provided
  const determineStepStatus = () => {
    if (status !== 'Not Started') {
      return status;
    }
    // Otherwise determine based on the current index
    if (currentStepIndex === 0) {
      return 'In Progress';
    }
    return 'Not Started';
  };

  const currentStatus = determineStepStatus();

  const getStatusImage = () => {
    switch (currentStatus) {
      case 'Completed':
        return moduleCompleted;
      case 'In Progress':
        return moduleInProgress;
      default:
        return moduleNotStarted;
    }
  };

  const renderStepContent = () => {
    // Render the appropriate component based on the component type in step data
    switch (currentStep.componentType) {
      case 'VideoStep':
        return <VideoStep onSkipStep={onNextStep} />;
      case 'RateMySetupStep':
        return (
          <RateMySetupStep
            onSkipStep={onNextStep}
            onCompleteStep={onNextStep}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        backgroundColor: 'white',
        borderRadius: '12px',
        padding: 3,
        flexBasis: '70%',
      }}
    >
      {/* Title with Status Image */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 2,
        }}
      >
        <Typography
          variant="h5"
          sx={{
            fontWeight: 700,
            fontSize: '18px',
          }}
        >
          Step {currentStep.id}: {currentStep.title}
        </Typography>
        <img
          src={getStatusImage()}
          alt={currentStatus}
          style={{ width: '74px', height: '74px' }}
        />
      </Box>

      {/* Divider */}
      <Divider />

      {/* Objective */}
      <Box
        sx={{
          mt: 2,
          mb: 2,
          bgcolor: theme.interviewAcademy.secondaryLight,
          borderRadius: '20px',
          padding: '24px',
        }}
      >
        <Typography>
          <Box component="span" sx={{ fontWeight: 600, fontSize: '18px' }}>
            Objective:
          </Box>
          <Box component="span" sx={{ fontWeight: 400, fontSize: '16px' }}>
            {' '}
            {currentStep.objective}
          </Box>
        </Typography>
      </Box>

      {/* Divider */}
      <Divider />

      {/* Instructions */}
      <Typography mt={2} mb={2}>
        <Box component="span" sx={{ fontWeight: 600, fontSize: '18px' }}>
          Instructions:
        </Box>
        <Box component="span" sx={{ fontWeight: 400, fontSize: '16px' }}>
          {' '}
          {currentStep.instructions}
        </Box>
      </Typography>

      {/* Step Content */}
      {renderStepContent()}
    </Box>
  );
}
