import { Box, Typography } from '@mui/material';
import { useCallback, useState } from 'react';
import { ImageCapture } from '../../../components/ImageCapture';
import { StepFooter } from '../../../components/StepFooter';
import StreamingTextField from '../../../components/StreamingTextField';
import { TwoColumnLayout } from '../../../components/TwoColumnLayout';
import { useImageFeedback } from '../../../middleware/useImageFeedback';

interface RateMySetupStepProps {
  onCompleteStep?: () => void;
  onSkipStep?: () => void;
  title?: string;
  imageUrl?: string;
  feedback?: string;
}

export default function RateMySetupStep({
  onCompleteStep,
  onSkipStep,
  title = 'Rate My Setup',
  feedback = 'No feedback available yet.',
}: RateMySetupStepProps) {
  const [showCamera, setShowCamera] = useState(true);
  const [capturedImageUrl, setCapturedImageUrl] = useState<string | undefined>(
    undefined
  );
  const {
    getImageFeedback,
    feedback: imageFeedback,
    cancelFeedbackGeneration,
  } = useImageFeedback();

  const handleCapture = useCallback(
    async (file: File) => {
      // Create a URL for the captured image
      const imageUrl = URL.createObjectURL(file);
      setCapturedImageUrl(imageUrl);
      setShowCamera(false);

      // Process the image for feedback
      await getImageFeedback(file);
    },
    [getImageFeedback]
  );

  const handleResetCapture = useCallback(() => {
    // Cancel any ongoing feedback generation
    cancelFeedbackGeneration();

    // Reset captured image
    if (capturedImageUrl) {
      URL.revokeObjectURL(capturedImageUrl);
      setCapturedImageUrl(undefined);
    }

    // Show camera again
    setShowCamera(true);
  }, [capturedImageUrl, cancelFeedbackGeneration]);

  const handleComplete = () => {
    if (onCompleteStep) {
      onCompleteStep();
    }
  };

  const handleSkip = () => {
    if (onSkipStep) {
      onSkipStep();
    }
  };

  return (
    <>
      {/* Step Content */}
      <Box
        sx={{
          flex: 1,
          marginY: 2,
        }}
      >
        {showCamera ? (
          <Box sx={{ width: '100%' }}>
            <Typography
              variant="subtitle1"
              sx={{ fontWeight: 600, fontSize: '16px', mb: 1 }}
            >
              {title}
            </Typography>
            <ImageCapture
              onCapture={handleCapture}
              showCamera={true}
              capturedImageUrl={undefined}
            />
          </Box>
        ) : (
          <TwoColumnLayout
            title={title}
            leftContent={
              <Box sx={{ position: 'relative' }}>
                <ImageCapture
                  onCapture={handleCapture}
                  showCamera={false}
                  capturedImageUrl={capturedImageUrl}
                />
              </Box>
            }
            rightContent={
              <StreamingTextField
                value={imageFeedback || feedback}
                isLoading={imageFeedback === '' && !showCamera}
              />
            }
          />
        )}
      </Box>

      <StepFooter
        leftButton={{
          text: 'Skip Step',
          onClick: handleSkip,
        }}
        rightButtons={[
          {
            text: 'Try Again',
            disabled: !capturedImageUrl,
            onClick: handleResetCapture,
          },
          {
            text: 'Next Level >',
            onClick: handleComplete,
            variant: 'contained',
            color: 'primary',
          },
        ]}
      />
    </>
  );
}
