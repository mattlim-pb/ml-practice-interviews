import { Box, useTheme } from '@mui/material';
import { useRecoilValue } from 'recoil';
import { APP_PATHS } from '../../../routes/paths';
import { uiState } from '../../../states/uiState';
import { ModuleOverview } from './ModuleOverview';
import { MyBadges } from './MyBadges';
import { ResumeTraining } from './ResumeTraining';
import { Waitlist } from './Waitlist';

// TODO: Responsive mobile design for this component and children
export function InterviewAcademyOverview() {
  const { iaWaitlist } = useRecoilValue(uiState);
  const displayedModules = iaWaitlist ? waitlistModules : modules;
  const theme = useTheme();

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: { xs: 'column', md: 'row' },
        gap: { xs: 3, sm: 3.5, md: 4 },
        width: '100%',
      }}
    >
      {/* First Column */}
      <Box sx={{
        flex: 2,
        width: '100%',
      }}>
        <Box
          sx={{
            mb: { xs: 2, sm: 2.5, md: 3 },
            borderRadius: '12px',
            p: { xs: 2, sm: 3, md: 4 },
            backgroundColor: theme.interviewAcademy.secondaryDark,
          }}
        >
          {iaWaitlist ? (
            <Waitlist />
          ) : (
            <ResumeTraining
              level={1}
              lessonsRemaining={2}
              completionPercentage={35}
              buttonText="Resume Training"
              buttonDestination={APP_PATHS.interviewAcademyHome}
            />
          )}
        </Box>
        <Box sx={{
          display: 'grid',
          gridTemplateColumns: {
            xs: '1fr',
            sm: 'repeat(2, 1fr)',
            md: 'repeat(3, 1fr)'
          },
          gap: { xs: 2, sm: 2.5, md: 3 },
          width: '100%',
        }}>
          {displayedModules.map(module => (
            <Box key={module.title} sx={{ width: '100%' }}>
              <ModuleOverview module={module} />
            </Box>
          ))}
        </Box>
      </Box>

      {/* Second Column */}
      <Box sx={{
        flex: 1,
        width: '100%',
      }}>
        <MyBadges showWaitlist={iaWaitlist} />
      </Box>
    </Box>
  );
}

const waitlistModules = [
  {
    title: 'Easy video tutorials',
    description:
      'Quick tutorials to learn the most important aspects of interviewing.',
    status: 'waitlist1' as const,
  },
  {
    title: 'Practice real questions',
    description:
      'Practice answering common questions and get real time feedback.',
    status: 'waitlist2' as const,
  },
  {
    title: 'Master key techniques',
    description: 'Learn the best interview techniques from experts.',
    status: 'waitlist3' as const,
  },
] as const;

const modules = [
  {
    title: 'Communication Basics',
    description: 'Prepare yourself for optimal video and audio performance',
    status: 'Completed' as const,
  },
  {
    title: 'Interview Basics',
    description: 'Prepare yourself for optimal video and audio performance',
    status: 'In Progress' as const,
  },
  {
    title: 'Body Language',
    description: 'Prepare yourself for optimal video and audio performance',
    status: 'Not Started' as const,
  },
] as const;
