import { Box } from '@mui/material';
import { useState } from 'react';
import { MainLayout } from '../../../components/MainLayout';
import { APP_PATHS } from '../../../routes/paths';
import LevelOverview from './LevelOverview';
import StepDetail from './StepDetail';
import { levelSteps } from './stepData';

export default function InterviewAcademyLevel() {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const handleNextStep = () => {
    if (currentStepIndex < levelSteps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    }
  };

  const handleStepClick = (index: number) => {
    setCurrentStepIndex(index);
  };

  // Calculate completion percentage based on current step
  const getCompletionPercentage = () => {
    // Each step contributes equally to completion
    const stepContribution = 100 / levelSteps.length;
    // Current step is in progress, so count all completed steps + partial credit for current
    return Math.min(
      100,
      stepContribution * currentStepIndex + stepContribution / 2
    );
  };

  return (
    <MainLayout
      backgroundColor="#f5f5f5"
      breadcrumb={[
        { title: 'Academy', destination: APP_PATHS.interviewAcademyHome },
        {
          title: 'Level 1: Interview Foundations',
          destination: APP_PATHS.interviewAcademyLevel,
        },
      ]}
    >
      <div className="flex flex-col min-h-0 h-[calc(100vh-48px)] transition-all">
        <Box
          sx={{
            borderRadius: '12px',
            width: '100%',
            flex: '1 1 auto',
            display: 'flex',
            flexDirection: 'column',
            mb: 4,
            minHeight: '400px',
            paddingTop: '24px',
            paddingHorizontal: '0px',
            overflow: 'auto',
          }}
        >
          <Box sx={{ display: 'flex', gap: 3, flex: 1 }}>
            <LevelOverview
              level={1}
              title="Interview Foundations"
              completionPercentage={getCompletionPercentage()}
              currentStepIndex={currentStepIndex}
              steps={levelSteps}
              onStepClick={handleStepClick}
            />
            <StepDetail
              currentStepIndex={currentStepIndex}
              onNextStep={handleNextStep}
              steps={levelSteps}
              status="In Progress"
            />
          </Box>
        </Box>
      </div>
    </MainLayout>
  );
}
