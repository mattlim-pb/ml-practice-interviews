import { Box, LinearProgress, Typography, useMediaQuery, useTheme } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import badge from '../../../assets/images/badge.png';
import { APP_PATHS } from '../../../routes/paths';

interface ResumeTrainingProps {
  level: number;
  lessonsRemaining: number;
  completionPercentage: number;
  buttonText?: string;
  buttonDestination?: string;
}

export function ResumeTraining({
  level,
  lessonsRemaining,
  completionPercentage,
  buttonText = 'Resume Training',
  buttonDestination = APP_PATHS.interviewAcademyLevel,
}: ResumeTrainingProps) {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  return (
    <Box
      sx={{
        borderRadius: '12px',
        padding: { xs: '12px', sm: '14px', md: '16px' },
        display: 'flex',
        flexDirection: { xs: 'column', sm: 'row' },
        gap: { xs: 2, sm: 2.5, md: 3 },
        width: '100%',
        alignItems: { xs: 'center', sm: 'flex-start' },
      }}
    >
      {/* Left Column: Badge Image */}
      <Box sx={{
        flexShrink: 0,
        display: 'flex',
        justifyContent: { xs: 'center', sm: 'flex-start' }
      }}>
        <img
          src={badge}
          alt="Progress Badge"
          style={{
            width: isMobile ? '85px' : isTablet ? '95px' : '105px',
          }}
        />
      </Box>

      {/* Right Column: Content */}
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          px: { xs: 0, sm: 1, md: 2 },
          flex: 1,
          gap: { xs: 1.5, sm: 2 },
          justifyContent: 'space-between',
          width: '100%',
        }}
      >
        {/* Top Row */}
        <Box
          sx={{
            display: 'flex',
            flexDirection: { xs: 'column', sm: 'row' },
            justifyContent: 'space-between',
            alignItems: { xs: 'center', sm: 'flex-start' },
            gap: { xs: 1.5, sm: 2 },
            width: '100%',
          }}
        >
          {/* Level and Lessons Info */}
          <Box sx={{
            textAlign: { xs: 'center', sm: 'left' },
            mb: { xs: 1, sm: 0 },
          }}>
            <Typography
              variant="h5"
              sx={{
                color: theme.interviewAcademy.white,
                fontWeight: 700,
                fontSize: { xs: '16px', sm: '17px', md: '18px' },
                paddingBottom: '6px',
              }}
            >
              Level {level}
            </Typography>
            <Typography
              variant="body1"
              sx={{
                color: theme.interviewAcademy.white,
                fontWeight: 600,
                fontSize: { xs: '13px', sm: '13px', md: '14px' },
              }}
            >
              Only {lessonsRemaining} lessons to go!
            </Typography>
          </Box>

          {/* Resume Training Button */}
          <Box
            onClick={() => navigate(buttonDestination)}
            sx={{
              backgroundColor: theme.interviewAcademy.primaryDark,
              borderRadius: '8px',
              padding: { xs: '6px 16px', sm: '8px 20px', md: '8px 24px' },
              flexShrink: 0,
              width: { xs: '100%', sm: 'auto' },
              minWidth: { xs: '150px', sm: '170px', md: '180px' },
              height: { xs: '34px', sm: '36px', md: '38px' },
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'background-color 0.3s ease',
              '&:hover': {
                backgroundColor: theme.interviewAcademy.secondaryLight,
                '& .buttonText': {
                  color: theme.interviewAcademy.secondaryDark,
                },
              },
            }}
          >
            <Typography
              className="buttonText"
              variant="h6"
              sx={{
                color: theme.interviewAcademy.white,
                fontWeight: 700,
                fontSize: { xs: '13px', sm: '13px', md: '14px' },
                textAlign: 'center',
                transition: 'color 0.3s ease',
              }}
            >
              {buttonText}
            </Typography>
          </Box>
        </Box>

        {/* Bottom Row: Progress Bar */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            width: '100%',
            mt: { xs: 0.5, sm: 1 },
            mb: { xs: 0, sm: 1 },
          }}
        >
          <Box sx={{ flexGrow: 1, position: 'relative', width: '100%' }}>
            <LinearProgress
              variant="determinate"
              value={completionPercentage}
              sx={{
                height: { xs: '22px', sm: '24px', md: '26px' },
                borderRadius: { xs: '11px', sm: '12px', md: '13px' },
                backgroundColor: theme.interviewAcademy.white,
                '& .MuiLinearProgress-bar': {
                  backgroundColor: theme.interviewAcademy.primaryDark,
                },
              }}
            />
            <Typography
              sx={{
                position: 'absolute',
                right: { xs: '10px', sm: '15px', md: '20px' },
                top: '50%',
                transform: 'translateY(-50%)',
                color: theme.interviewAcademy.secondaryDark,
                fontWeight: 600,
                fontSize: { xs: '10px', sm: '11px', md: '12px' },
              }}
            >
              {completionPercentage}% Completed
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
