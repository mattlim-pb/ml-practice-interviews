import { Box, Typography, useTheme } from '@mui/material';
import { MainLayout } from '../../../components/MainLayout';
import { APP_PATHS } from '../../../routes/paths';
import { ResumeTraining } from './ResumeTraining';

export default function InterviewAcademyHome() {
  const theme = useTheme();

  return (
    <MainLayout
      backgroundColor="#f5f5f5"
      breadcrumb={[
        { title: 'Academy', destination: APP_PATHS.interviewAcademyHome },
      ]}
    >
      <div className="flex flex-col min-h-0 h-[calc(100vh-48px)] transition-all">
        <Box className="flex flex-row content-center items-left">
          <div className="flex-1 flex-row content-center mb-6 mt-4 ">
            <Typography
              variant="h5"
              className="!text-base sm:!text-xl md:!text-xl lg:!text-2xl inline-block !mr-4"
            >
              <b>Academy</b>
            </Typography>
          </div>
        </Box>

        <Box sx={{ mb: 4 }}>
          <ResumeTraining
            level={1}
            lessonsRemaining={2}
            completionPercentage={25}
            buttonText="Resume: Interview Foundations"
            buttonDestination={APP_PATHS.interviewAcademyLevel}
          />
        </Box>

        <Box
          sx={{
            borderRadius: '12px',
            bgcolor: theme.interviewAcademy.white,
            width: '100%',
            flex: '1 1 auto',
            display: 'flex',
            flexDirection: 'column',
            mb: 4,
            minHeight: '400px',
            padding: '24px',
            overflow: 'auto',
          }}
        >
          <Typography sx={{ fontWeight: 700, fontSize: '24px', mb: 2 }}>
            Course Modules
          </Typography>
          <Box sx={{ display: 'flex', gap: 3, flex: 1 }}>
            <Box
              sx={{
                flexBasis: '40%',
                bgcolor: theme.interviewAcademy.white,
                borderRadius: '12px',
                border: '1px solid #CBD1E3',
                height: '100%',
              }}
            />
            <Box
              sx={{
                flexBasis: '60%',
                bgcolor: theme.interviewAcademy.white,
                borderRadius: '12px',
                border: '1px solid #CBD1E3',
                height: '100%',
              }}
            />
          </Box>
        </Box>
      </div>
    </MainLayout>
  );
}
