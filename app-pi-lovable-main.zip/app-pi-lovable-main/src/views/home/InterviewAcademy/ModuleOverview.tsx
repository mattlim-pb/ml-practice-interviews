import { Box, Typography, useMediaQuery, useTheme } from '@mui/material';
import moduleCompleted from '../../../assets/images/moduleCompleted.png';
import moduleInProgress from '../../../assets/images/moduleInProgress.png';
import moduleNotStarted from '../../../assets/images/moduleNotStarted.png';
import waitlist1 from '../../../assets/images/waitlist1.png';
import waitlist2 from '../../../assets/images/waitlist2.png';
import waitlist3 from '../../../assets/images/waitlist3.png';

export interface Module {
  title: string;
  description: string;
  status:
    | 'Not Started'
    | 'In Progress'
    | 'Completed'
    | 'waitlist1'
    | 'waitlist2'
    | 'waitlist3';
}

interface ModuleOverviewProps {
  module: Module;
}

export function ModuleOverview({ module }: ModuleOverviewProps) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  const getStatusImage = () => {
    switch (module.status) {
      case 'waitlist1':
        return waitlist1;
      case 'waitlist2':
        return waitlist2;
      case 'waitlist3':
        return waitlist3;
      case 'Completed':
        return moduleCompleted;
      case 'In Progress':
        return moduleInProgress;
      default:
        return moduleNotStarted;
    }
  };

  const imageSize = isMobile ? '60px' : isTablet ? '68px' : '74px';

  return (
    <Box
      sx={{
        backgroundColor: theme.interviewAcademy.secondaryLight,
        borderRadius: '12px',
        px: { xs: 2, sm: 3, md: 4 },
        pt: { xs: 2, sm: 3, md: 4 },
        pb: { xs: 3, sm: 4, md: 5 },
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <Typography
        variant="h6"
        sx={{
          fontSize: { xs: '13px', sm: '14px', md: '16px' },
          fontWeight: 600,
          color: '#656565',
          marginBottom: { xs: '12px', sm: '16px', md: '24px' },
          textAlign: { xs: 'center', sm: 'left' },
        }}
      >
        {module.title}
      </Typography>

      <Box
        sx={{
          display: 'flex',
          flexDirection: { xs: 'column', sm: 'row' },
          flexGrow: 1,
          alignItems: { xs: 'center', sm: 'flex-start' },
          justifyContent: { xs: 'center', sm: 'flex-start' },
        }}
      >
        <Box
          sx={{
            flexShrink: 0,
            mb: { xs: 2, sm: 0 },
            display: 'flex',
            justifyContent: { xs: 'center', sm: 'flex-start' },
          }}
        >
          <img
            src={getStatusImage()}
            alt={module.status}
            style={{
              width: imageSize,
              height: imageSize,
            }}
          />
        </Box>

        <Box
          sx={{
            ml: { xs: 0, sm: 2, md: 3 },
            flexGrow: 1,
            textAlign: { xs: 'center', sm: 'left' },
          }}
        >
          <Typography
            variant="body2"
            sx={{
              fontSize: { xs: '11px', sm: '11px', md: '12px' },
              fontWeight: 500,
              color: '#595D62',
              lineHeight: 1.5,
            }}
          >
            {module.description}
          </Typography>
        </Box>
      </Box>
    </Box>
  );
}
