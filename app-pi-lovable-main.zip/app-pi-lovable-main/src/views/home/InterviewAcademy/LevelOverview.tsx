import { Box, LinearProgress, Typography, useTheme } from '@mui/material';
import checkmark from '../../../assets/images/checkmark.png';
import { Step } from './stepData';

interface LevelOverviewProps {
  level: number;
  title: string;
  completionPercentage: number;
  currentStepIndex: number;
  steps: Step[];
  onStepClick?: (index: number) => void;
}

export default function LevelOverview({
  level,
  title,
  completionPercentage,
  currentStepIndex,
  steps,
  onStepClick,
}: LevelOverviewProps) {
  const theme = useTheme();

  // Function to get background color based on status
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return '#53b96a';
      case 'In Progress':
        return '#5d6df3';
      case 'Not Started':
      default:
        return '#7a7d80';
    }
  };

  // Dynamically update step statuses based on currentStepIndex
  const stepsWithStatus = steps.map((step, index) => {
    let status: 'Completed' | 'In Progress' | 'Not Started';

    if (index < currentStepIndex) {
      status = 'Completed';
    } else if (index === currentStepIndex) {
      status = 'In Progress';
    } else {
      status = 'Not Started';
    }

    return { ...step, status };
  });

  return (
    <Box
      sx={{
        flexBasis: '30%',
        bgcolor: theme.interviewAcademy.white,
        borderRadius: '12px',
        height: '100%',
        padding: 2,
      }}
    >
      <Typography sx={{ fontWeight: 700, fontSize: '20px', mb: 2 }}>
        Level {level}:<br />
        {title}
      </Typography>
      <Box sx={{ flexGrow: 1, position: 'relative', mb: 3 }}>
        <LinearProgress
          variant="determinate"
          value={completionPercentage}
          sx={{
            height: '12px',
            borderRadius: '6px',
            backgroundColor: '#e7eaf1',
            '& .MuiLinearProgress-bar': {
              backgroundColor: theme.interviewAcademy.primaryDark,
            },
          }}
        />
      </Box>
      {stepsWithStatus.map((step, index) => (
        <Box
          key={step.id}
          sx={{
            position: 'relative',
            display: 'flex',
            flexDirection: 'row',
            cursor: onStepClick ? 'pointer' : 'default',
          }}
          onClick={() => onStepClick && onStepClick(index)}
        >
          {/* Circle for the step number */}
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              backgroundColor:
                step.status === 'Completed'
                  ? theme.interviewAcademy.primaryDark
                  : step.status === 'Not Started'
                  ? '#cac7e9'
                  : theme.interviewAcademy.secondaryDark,
              flexShrink: 0,
            }}
          >
            {step.status === 'Completed' ? (
              <Box
                component="img"
                src={checkmark}
                alt="Completed"
                sx={{
                  width: '22px',
                  height: 'auto',
                  display: 'block',
                }}
              />
            ) : (
              <Typography
                sx={{
                  fontWeight: 700,
                  fontSize: '16px',
                  color: theme.interviewAcademy.white,
                }}
              >
                {step.id}
              </Typography>
            )}
          </Box>

          {/* Step details */}
          <Box sx={{ ml: '16px' }}>
            <Typography
              sx={{
                fontWeight: 500,
                fontSize: '16px',
                color: '#333333',
                mb: '2px',
              }}
            >
              {step.title}
            </Typography>
            <Box
              sx={{
                display: 'inline-block',
                borderRadius: '6px',
                backgroundColor: getStatusColor(step.status),
                padding: '3px 10px',
                mb: '6px',
              }}
            >
              <Typography
                variant="body2"
                sx={{
                  fontWeight: 500,
                  fontSize: '12px',
                  color: theme.interviewAcademy.white,
                }}
              >
                {step.status}
              </Typography>
            </Box>
            <Typography
              variant="body2"
              sx={{
                fontWeight: 400,
                fontSize: '13px',
                color: '#888888',
                mb: '28px',
              }}
            >
              {step.description}
            </Typography>
          </Box>

          {/* Line segment connecting to the next circle */}
          {index < stepsWithStatus.length - 1 && (
            <Box
              sx={{
                position: 'absolute',
                left: '15px',
                top: '32px',
                width: '2px',
                height: 'calc(100% - 32px)',
                backgroundColor:
                  step.status === 'Completed'
                    ? theme.interviewAcademy.secondaryDark
                    : '#cac7e9',
              }}
            />
          )}
        </Box>
      ))}
    </Box>
  );
}
