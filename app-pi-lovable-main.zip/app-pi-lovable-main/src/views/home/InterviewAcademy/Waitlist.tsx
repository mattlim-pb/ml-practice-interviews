import { Box, Typography, useMediaQuery, useTheme } from '@mui/material';
import { useCallback, useState } from 'react';
import { useRecoilValue } from 'recoil';
import badge from '../../../assets/images/badge.png';
import { useMe } from '../../../middleware/useMe';
import { clientState } from '../../../states/auth';

export function Waitlist() {
  const [isJoining, setIsJoining] = useState(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  const client = useRecoilValue(
    clientState({ contentType: 'application/json' })
  );

  const { user, refetchMe } = useMe();
  const joinedWaitlist = user?.metadata?.joinedWaitlist ?? false;

  const joinWaitlist = useCallback(async () => {
    if (!user || isJoining) return;
    setIsJoining(true);
    try {
      await client.patch(`/users/${user.id}`, {
        metadata: {
          joinedWaitlist: true,
        },
      });
      await refetchMe();
    } catch (error) {
      console.error('Failed to join waitlist:', error);
    } finally {
      setIsJoining(false);
    }
  }, [client, isJoining, refetchMe, user]);

  return (
    <Box
      sx={{
        borderRadius: '12px',
        padding: { xs: '12px', sm: '14px', md: '16px' },
        display: 'flex',
        flexDirection: { xs: 'column', sm: 'row' },
        gap: { xs: 2, sm: 2.5, md: 3 },
        width: '100%',
        alignItems: { xs: 'center', sm: 'flex-start' },
      }}
    >
      {/* Left Column: Badge Image */}
      <Box sx={{
        flexShrink: 0,
        display: 'flex',
        justifyContent: 'center'
      }}>
        <img
          src={badge}
          alt="Progress Badge"
          style={{
            width: isMobile ? '85px' : isTablet ? '95px' : '105px',
          }}
        />
      </Box>

      {/* Right Column: Content */}
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          px: { xs: 0, sm: 1, md: 2 },
          flex: 1,
          gap: { xs: 1.5, sm: 2 },
          justifyContent: 'space-between',
          width: '100%',
        }}
      >
        {/* Top Row */}
        <Box
          sx={{
            display: 'flex',
            flexDirection: { xs: 'column', sm: 'row' },
            justifyContent: 'space-between',
            alignItems: { xs: 'center', sm: 'flex-start' },
            gap: { xs: 1.5, sm: 2 },
            width: '100%',
          }}
        >
          {/* Level and Lessons Info */}
          <Box sx={{
            textAlign: { xs: 'center', sm: 'left' },
            mb: { xs: 1, sm: 0 },
          }}>
            <Typography
              variant="h5"
              sx={{
                color: theme.interviewAcademy.white,
                fontWeight: 700,
                fontSize: { xs: '16px', sm: '17px', md: '18px' },
                paddingBottom: '6px',
              }}
            >
              Join the Interview Academy
            </Typography>
            <Typography
              variant="body1"
              sx={{
                color: theme.interviewAcademy.white,
                fontWeight: 600,
                fontSize: { xs: '12px', sm: '13px', md: '14px' },
                lineHeight: 1.5,
              }}
            >
              {joinedWaitlist
                ? "Coming soon... we'll let you know when it's available!"
                : 'Coming soon... join the waitlist for early access.'}
            </Typography>
          </Box>

          {/* Join Waitlist Button */}
          {!joinedWaitlist && (
            <Box
              onClick={joinWaitlist}
              sx={{
                backgroundColor: theme.interviewAcademy.primaryDark,
                borderRadius: '8px',
                padding: { xs: '6px 14px', sm: '8px 16px', md: '8px 16px' },
                flexShrink: 0,
                width: { xs: '100%', sm: '190px', md: '220px' },
                height: { xs: '34px', sm: '36px', md: '38px' },
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'background-color 0.3s ease',
                pointerEvents: isJoining ? 'none' : 'auto',
                opacity: isJoining ? 0.7 : 1,
                '&:hover': {
                  backgroundColor: theme.interviewAcademy.secondaryLight,
                  '& .buttonText': {
                    color: theme.interviewAcademy.secondaryDark,
                  },
                },
              }}
            >
              <Typography
                className="buttonText"
                variant="h6"
                sx={{
                  color: theme.interviewAcademy.white,
                  fontWeight: 700,
                  fontSize: { xs: '13px', sm: '13px', md: '14px' },
                  textAlign: 'center',
                  transition: 'color 0.3s ease',
                }}
              >
                {isJoining ? 'Joining...' : 'Join the Waitlist'}
              </Typography>
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
}
