import { useCallback, useEffect, useRef, useState } from 'react';
import { useRecoilState, useRecoilValue } from 'recoil';

import { useLocation, useNavigate } from 'react-router-dom';
import { CompanyType } from '../data/company';
import { QuestionType } from '../data/question';

import { useQuestions } from '../middleware/useQuestions';
import { APP_PATHS } from '../routes/paths';
import { commonQuestionsState, questionState } from '../states/recording';

export function useNextQuestion() {
  const navigate = useNavigate();
  const { state } = useLocation();

  const [question, setQuestion] = useRecoilState(questionState);
  const commonQuestions = useRecoilValue(commonQuestionsState);
  const {
    mutate: getQuestion,
    data: response,
    error,
    isSuccess,
  } = useQuestions();
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const params = useRef<{
    jobId: string;
    questionType: QuestionType;
    selectedCompany: CompanyType;
    willMonitorLoadingStatus: boolean;
  }>({
    jobId: '',
    questionType: 'common',
    selectedCompany: {} as CompanyType,
    willMonitorLoadingStatus: false,
  });

  const getNextQuestion = useCallback(
    ({
      jobId,
      questionType,
      willMonitorLoadingStatus,
      selectedCompany,
      stop,
    }: {
      jobId: string;
      questionType: QuestionType;
      willMonitorLoadingStatus: boolean;
      selectedCompany: CompanyType;
      stop?: () => void;
    }) => {
      if (questionType === 'common') {
        if (question == null && commonQuestions.length > 0) {
          setQuestion(commonQuestions[0]);
        } else {
          const index = commonQuestions.findIndex(q => q.id === question?.id);
          if (index + 1 < commonQuestions.length) {
            setQuestion(commonQuestions[index + 1]);
          } else {
            setQuestion(commonQuestions[0]);
          }
          navigate(APP_PATHS.startAnswering, {
            state: { selectedJob: state.selectedJob },
          });
        }
      } else {
        params.current = {
          jobId,
          questionType,
          selectedCompany,
          willMonitorLoadingStatus,
        };
        if (willMonitorLoadingStatus) {
          setIsLoading(true);
        }
        getQuestion({
          jobId,
          questionType,
          currentQuestionId: question?.id,
          selectedCompany,
        });
        stop && stop();
      }
    },
    [
      question,
      getQuestion,
      setIsLoading,
      commonQuestions,
      setQuestion,
      navigate,
      state.selectedJob,
    ]
  );

  useEffect(() => {
    if (response?.data.success) {
      if (response.data.data == null && params.current != null) {
        // WORKAROUND: sometimes API returns {success:true} without data, so in this case fetch again manually
        // maybe, we can use isLoading of useQuestions directly in the future after API stabilized
        getNextQuestion({
          jobId: params.current.jobId,
          questionType: params.current.questionType,
          willMonitorLoadingStatus: true,
          selectedCompany: params.current.selectedCompany,
        });
      } else {
        setQuestion(response?.data?.data);
        setIsLoading(false);
      }
    } else if (error != null) {
      setIsLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [response, error]);

  return {
    getNextQuestion,
    question,
    isLoading,
    isNextQuestionAvailable: isSuccess,
  };
}
