import moment from 'moment';
import { useCallback, useEffect, useRef, useState } from 'react';

export function useExpirationTimer({
  key,
  limit = 30,
}: {
  key: string;
  limit?: number;
}) {
  const intervalId = useRef<any>(null);
  const [isExpired, setIsExpired] = useState<boolean>(true);
  const [secondsLeft, setSecondsLeft] = useState<number>(limit);

  const checkExpirationStatus = useCallback(() => {
    const timerStartedAt = localStorage.getItem(key);
    if (timerStartedAt != null) {
      const diff = moment.duration(
        moment(new Date().toISOString()).diff(moment(timerStartedAt))
      );
      if (diff.asSeconds() > 30 || secondsLeft <= 0) {
        if (intervalId.current != null) {
          clearInterval(intervalId.current);
        }

        setIsExpired(true);
        setSecondsLeft(30);
        localStorage.removeItem(key);
      } else {
        setIsExpired(false);
        setSecondsLeft(prev => prev - 1);
      }
    }
  }, [setIsExpired, secondsLeft, key]);

  const start = useCallback(() => {
    const startedAt = new Date().toString();
    localStorage.setItem(key, startedAt);

    intervalId.current = setInterval(() => {
      checkExpirationStatus();
    }, 1000);
  }, [key, checkExpirationStatus]);

  useEffect(() => {
    return () => {
      if (intervalId.current != null) {
        clearInterval(intervalId.current);
      }
    };
  }, []);

  return { start, isExpired, secondsLeft };
}
