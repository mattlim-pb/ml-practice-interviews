import { useEffect } from 'react';

interface Props {
  callback: () => void;
  timeout: number;
}

export function useTimeout({ callback, timeout }: Props) {
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      callback();
    }, timeout);

    return () => {
      timeoutId != null && clearTimeout(timeoutId);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
