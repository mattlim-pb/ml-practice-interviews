import { useCallback } from 'react';

export function useFormattedText() {
  const formattedText = useCallback((value: string | undefined | null) => {
    if (value == null) {
      return null;
    }
    const parts = value.split(/\*\*(.*?)\*\*/);

    const formattedText = parts.map((part, index) => {
      if (index % 2 === 1) {
        return (
          <div key={index}>
            {index !== 1 || parts[0].trim().length > 0 ? <br /> : ''}
            <strong>{part}</strong>
            <br />
          </div>
        );
      }
      return part
        .split('\n')
        .map((node, index) => <div key={index}>{node}</div>);
    });

    return formattedText;
  }, []);

  return formattedText;
}
